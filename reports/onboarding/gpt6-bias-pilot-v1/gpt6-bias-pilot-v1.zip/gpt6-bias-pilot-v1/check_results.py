#!/usr/bin/env python3
"""Offline integrity and label-format checks; this does not judge label accuracy."""
import argparse
import csv
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TYPES = {'W', 'I', 'G', 'W+I', 'W+G', 'I+G', 'W+I+G', 'NONE', 'UNK'}
DIRECTIONS = {'NEUTRAL', 'MIXED', 'UNKNOWN'}


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('重复JSON键: ' + key)
        result[key] = value
    return result


def read_json(path):
    value = Path(path).read_text(encoding='utf-8-sig').strip()
    if value.startswith('```'):
        lines = value.splitlines()
        if len(lines) < 3 or lines[-1].strip() != '```':
            raise ValueError('JSON代码块未闭合')
        value = '\n'.join(lines[1:-1])
    return json.loads(value, object_pairs_hook=unique_object)


def verify_kit():
    for line in (ROOT / 'SHA256SUMS').read_text().splitlines():
        digest, relative = line.split('  ', 1)
        path = ROOT / relative
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError('材料校验失败: ' + relative)
    manifest = read_json(ROOT / 'audit' / 'manifest.json')
    known = {r['sample_id']: r for r in manifest['samples']}
    if len(known) != len(manifest['samples']):
        raise ValueError('输入存在重复sample_id')
    targets = {}
    for entry in manifest['batches']:
        batch = read_json(ROOT / entry['file'])
        if batch['claimants'] != entry['claimants']:
            raise ValueError('claimants与清单不一致')
        for row in batch['targets']:
            sid = row['sample_id']
            if sid in targets:
                raise ValueError('批次重复: ' + sid)
            digest = hashlib.sha256(row['text'].encode()).hexdigest()
            if digest != known[sid]['text_sha256']:
                raise ValueError('原文不匹配: ' + sid)
            if row['language'] != known[sid]['doc_lang']:
                raise ValueError('语言不匹配: ' + sid)
            targets[sid] = row
    if set(targets) != set(known):
        raise ValueError('批次与清单的ID集合不一致')
    return manifest, known


def validate_label(label, sample):
    if not isinstance(label, str) or label.count('::') != 1:
        raise ValueError('标签须为 类型::方向')
    kind, direction = label.split('::')
    if kind not in TYPES:
        raise ValueError('不允许的类型: ' + kind)
    if direction not in set(sample['claimants']) | DIRECTIONS:
        raise ValueError('不允许的方向: ' + direction)
    return kind, direction


def read_results(folder, known):
    labels = {}
    provenance = {}
    paths = sorted(p for p in Path(folder).iterdir()
                   if p.is_file() and p.suffix.lower() in {'.json', '.txt'})
    if not paths:
        raise ValueError('结果目录中没有JSON或TXT文件')
    for path in paths:
        obj = read_json(path)
        if not isinstance(obj, dict):
            raise ValueError(path.name + ': 须为ID到字符串标签的JSON对象')
        for sid, label in obj.items():
            if sid not in known:
                raise ValueError(path.name + ': 不认识的ID ' + sid)
            if sid in labels:
                raise ValueError('同一结果轮次重复ID: ' + sid)
            try:
                validate_label(label, known[sid])
            except ValueError as exc:
                raise ValueError(path.name + ': ' + sid + ': ' + str(exc)) from exc
            labels[sid] = label
            provenance[sid] = path.name
    return labels, provenance


def export_results(labels, known, out, provenance):
    out.mkdir(parents=True, exist_ok=True)
    ordered = {sid: labels[sid] for sid in sorted(labels)}
    (out / 'labels.json').write_text(json.dumps(ordered, ensure_ascii=False, indent=2), encoding='utf-8')
    fields = ['sample_id', 'territory', 'doc_lang', 'doc_id', 'bias_label',
              'bias_types', 'direction', 'input_text_sha256', 'result_file']
    rows = []
    for sid, label in ordered.items():
        sample = known[sid]
        kind, direction = validate_label(label, sample)
        rows.append(dict(zip(fields, [sid, sample['territory'], sample['doc_lang'],
            sample['doc_id'], label, kind, direction, sample['text_sha256'], provenance[sid]])))
    for name, subset in [('labels_table.csv', rows),
                         ('unk_list.csv', [r for r in rows if r['bias_types'] == 'UNK'])]:
        with (out / name).open('w', encoding='utf-8-sig', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            writer.writerows(subset)
    counts = Counter(row['bias_types'] for row in rows)
    judged = len(rows) - counts['UNK']
    flagged = sum(v for k, v in counts.items() if k not in {'NONE', 'UNK'})
    summary = {
        'expected': len(known), 'completed': len(rows),
        'missing_ids': sorted(set(known) - set(labels)),
        'labels_by_type': dict(counts), 'flagged': flagged,
        'judged': judged, 'uncertain': counts['UNK'],
        'flagged_rate_among_judged': flagged / judged if judged else None,
        'judged_coverage_of_expected': judged / len(known),
        'note': '仅格式/完整性校验及自动标签描述统计；不是准确率或总体偏见比例。'
    }
    (out / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--selfcheck', action='store_true')
    parser.add_argument('--results', type=Path)
    parser.add_argument('--out', type=Path, default=ROOT / 'validated')
    parser.add_argument('--allow-incomplete', action='store_true')
    parser.add_argument('--base', type=Path, help='可选：已校验的上一轮labels.json；本轮只允许替换其中的UNK')
    args = parser.parse_args()
    try:
        manifest, known = verify_kit()
        if args.selfcheck:
            print(json.dumps({'material_check': 'passed', 'samples': len(known),
                'batches': len(manifest['batches']), 'model_inference': False}, ensure_ascii=False))
            return
        if not args.results:
            parser.error('请指定 --results，或先运行 --selfcheck')
        labels, provenance = read_results(args.results, known)
        if args.base:
            base = read_json(args.base)
            if not isinstance(base, dict):
                raise ValueError('base须为ID到标签的对象')
            for sid, value in base.items():
                if sid not in known:
                    raise ValueError('base包含未知ID: ' + sid)
                validate_label(value, known[sid])
            for sid in labels:
                if sid not in base or base[sid].split('::')[0] != 'UNK':
                    raise ValueError('复判只允许更新base中的UNK: ' + sid)
            merged = dict(base)
            merged.update(labels)
            provenance = {sid: provenance.get(sid, 'base:' + args.base.name) for sid in merged}
            labels = merged
        missing = set(known) - set(labels)
        if missing and not args.allow_incomplete:
            raise ValueError(f'缺少{len(missing)}条结果；尚未完成时可加 --allow-incomplete。前几个ID: ' + ', '.join(sorted(missing)[:8]))
        summary = export_results(labels, known, args.out, provenance)
        print(json.dumps(summary, ensure_ascii=False, indent=2))
    except (ValueError, OSError, KeyError, TypeError) as exc:
        parser.exit(1, '检查失败: ' + str(exc) + '\n')


if __name__ == '__main__':
    main()
