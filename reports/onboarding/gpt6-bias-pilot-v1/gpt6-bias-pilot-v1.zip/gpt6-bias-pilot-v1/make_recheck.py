#!/usr/bin/env python3
"""Prepare local context for UNK labels; no API calls or automatic relabeling."""
import argparse
import json
from pathlib import Path
from check_results import ROOT, read_json, validate_label, verify_kit


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--labels', type=Path, default=ROOT / 'validated' / 'labels.json')
    parser.add_argument('--out', type=Path, default=ROOT / 'recheck_upload')
    args = parser.parse_args()
    try:
        manifest, known = verify_kit()
        labels = read_json(args.labels)
        if not isinstance(labels, dict):
            raise ValueError('labels须为ID到标签的对象')
        selected = set()
        for sid, value in labels.items():
            if sid not in known:
                raise ValueError('未知ID: ' + sid)
            kind, _ = validate_label(value, known[sid])
            if kind == 'UNK':
                selected.add(sid)
        contexts = read_json(ROOT / 'audit' / 'expanded_contexts.json')
        if args.out.exists() and any(args.out.iterdir()):
            raise ValueError('输出目录已有文件，请使用新的 --out 路径，避免混入上一轮复判')
        args.out.mkdir(parents=True, exist_ok=True)
        files = []
        for entry in manifest['batches']:
            original = read_json(ROOT / entry['file'])
            targets = [row for row in original['targets'] if row['sample_id'] in selected]
            if not targets:
                continue
            batch = {key: value for key, value in original.items() if key not in {'targets', 'context'}}
            batch['batch_id'] = 'R_' + original['batch_id']
            batch['context_scope'] = '同一来源文章相邻±3段；单个上下文最多4000字符，截断明确标记；没有新增法律事实核查。'
            batch['targets'] = targets
            batch['context'] = {row['sample_id']: contexts[row['sample_id']] for row in targets}
            dest = args.out / ('R_' + Path(entry['file']).name)
            dest.write_text(json.dumps(batch, ensure_ascii=False, indent=2), encoding='utf-8')
            files.append(dest.name)
        print(json.dumps({'unk_samples': len(selected), 'files': files,
            'note': '每个文件与原01_INSTRUCTIONS.txt一起上传新会话；不上传旧标签。结果另存recheck_results。'}, ensure_ascii=False, indent=2))
    except (ValueError, OSError, KeyError, TypeError) as exc:
        parser.exit(1, '准备复判失败: ' + str(exc) + '\n')


if __name__ == '__main__':
    main()
