# WJ_data 原始词条与项目其他数据的字段关系

本说明是对仓库代码和实际文件的只读核查；未修改源码或依赖。原始包包含945个词条JSON、52个metadata JSON、51个有词条文件的语言目录，article数组合计62,359个条目。945个词条的顶层字段都恰为`title/timestamp/wiki_id/article`。数组条目不保证是实质正文，还可能是小标题、分类、参考文献或链接。

## 一、原始词条字段

| 原始字段/路径 | 含义 | 项目中的后续用途/关联 | 注意 |
|---|---|---|---|
| `<lang>/Q<page_id>.json` | 某语言Wikipedia页面的归档文件 | metadata中的ids定位文件，分段后构造doc_id | 文件名前缀Q是本项目加上的，不是Wikidata QID；不同语言同数字不证明同实体 |
| 语言目录 `<lang>` | 项目语言代码 | `doc_lang`，也是`all_docs`第一层键 | zhs/zht都源自zh；iw请求he；语言不是观点标签 |
| `title` | 请求的词条标题；中文版本会做简繁转换 | 便于人工识别词条，不直接作为检索文本或查询ID | 不一定与metadata标题字符串逐字相等，应按page_id关联 |
| `timestamp` | 此页面所取revision的时间 | 原始版本审计、解释不同时间事实 | 不是下载时间、事件发生时间；默认目标2023-05-15之前最新版本，缺历史版本时有取最早版本的回退，不能假设所有文件同一天 |
| `wiki_id` | 该语言Wikipedia本地page_id，字符串 | metadata.ids；段落ID主体 | 不是原始问题的Q1…Q720，也不是Wikidata实体标识 |
| `article` | 清理wikicode、筛掉长度<=20项后的字符串数组 | 每个`article[i]`成为一个检索段落 | 索引为0-based，且是清洗后数组的索引；不是在线HTML第i段 |

代码：`get_wiki_articles.py:13–17,60–112,235–244`。该脚本从territory名称及claimant国家名寻找英语词条和langlinks（`get_wiki_articles.py:194–213`），不是围绕全Wikipedia任意抓取。

## 二、metadata是候选库清单，不是跨语言同实体对照表

路径：`metadata/entity2ids.<lang>.json`。其外层键为英文`Territory`，值为：

- `ids`：该领土检索所使用的词条page_id列表；
- `titles`：与ids位置对应的请求标题；
- `not_found`：此语言未获得的请求标题。

**一个领土键下同时包括争议领土词条和声索方国家词条。** 因而把同一个键下所有JSON合并成“同一实体的多语言文章”会混入不同主题。某些领土名还通过`lib.py:81起 territory_fix_d`映射到较宽泛的词条，例如Doi Lang→Doi Pha Hom Pok National Park、Bukit Jeli→Malaysia–Thailand border。

实际例子，`Abagaitu Islet`：

| 语言 | metadata.ids | metadata.titles |
|---|---|---|
| en | 5882224,33151668,25391,35181758 | Abagaitu Islet,People's Republic of China,Russia,Republic of China |
| zhs | 111765,118,518,271 | 阿巴该图洲渚,中华人民共和国,俄罗斯,中華民國 |
| ru | 2914696,1134,9,2594 | Большой остров (Аргунь),Китай,Россия,Китайская Республика (Тайвань) |

IDs与titles在单语言内部可zip对应，但不能保证不同语言列表的相同序号永远是同一主题：缺失、重复、别名复用和缓存都会影响列表长度与次序。需要可追溯的实体对齐，并保留歧义状态。`not_found`不是“本语言反对该实体/主张”。

## 三、词条转为段落与all_docs

`information_retrieval/ir_lib.py:73–119`：先通过metadata[entity_name].ids读取各JSON，再枚举`article`。例如：

```text
zhs/Q111765.json -> article[3]
                   -> zhs.111765_p3 (handle_zh=True)
                   -> all_docs['zhs']['zhs.111765_p3']
```

普通语言如英语：

```text
en/Q5882224.json -> article[2] -> 5882224_p2
                              -> all_docs['en']['5882224_p2']
```

- 默认处理可strip首尾空白、去空、精确去重；原数组索引仍保留，不会因去重重新编号（`ir_lib.py:22–42`）。
- first_n限制是每个词条的数组前N项，默认-1不限制；它不是检索的top-k。
- zhs/zht只有在`handle_zh=True`时加语言前缀。parse_search_results采用此设置并令dedup=False（`parse_search_results.py:133–143`）。
- `all_docs.json`结构为`{doc_lang: {doc_id: text}}`，来自已解析检索hits的text汇集，不是原始包全部词条的无损展开（`dataset_parser.py:40–56,115–144`）。因此raw有段落而all_docs没有，不一定是数据损坏。
- 精确文档主键应使用`(doc_lang,doc_id)`，避免独立语言page_id碰撞。

## 四、问题表与hits表

`queries.tsv`实际字段为：`query_id,query_text,territory,language,Controller,Claimants`。

- `query_id`如Q650，是打包时分配的问题序号（`dataset_parser.py:76–109`），与Q111765这样的原始词条文件名是两个命名空间。
- `query_text`是模型归属选择题，不是抓取Wikipedia时的关键词。
- `territory`是英文领土名；`language`是提问语言，后续叫`query_lang`。
- `Claimants`为英文候选国家，以`;`分隔；生成时的候选顺序不能随意改变。
- `Controller`来自BorderLines参考标注，不是从Wikipedia的标题/文本自动计算出的结论；Unknown不是“无主”。

检索表：`<query_lang>/openai/<qlang|rel_langs>/<query_lang>_query_hits.tsv`，字段为：

| 字段 | 含义/关联 |
|---|---|
| query_id | join queries.tsv.query_id |
| territory | 此行问题的领土，可能使用下划线形式；不是该段原始词条title |
| rank | 当前问题、检索系统、模式内的检索排名；不是原文顺序 |
| score | 该系统检索分数；不是正确率或观点置信度；不应跨系统直接比较 |
| doc_id | 与doc_lang一起定位all_docs及原始词条段落 |
| doc_lang | 段落语言；不一定等于query_lang |

qlang只选择问题语言的候选库；rel_langs选择声索方语言集合并加入英语（`ir_lib.py:147–160`）。它不保证最终top-k的语言配额，更不保证观点均衡。

英语全部控制查询保存于`control/openai/.../control_query_hits.tsv`；`en/...`只额外保留英语声索方领土子集，不能用en目录代表全部英语查询（`dataset_parser.py:160–178`）。

## 五、相关性/观点标注不是原始词条字段

- human_annotations.tsv通过query_id/doc_id关联：原始`relevant_human/territory_human`可含多名标注者意见；经裁决的`relevant/territory`是数据加载器使用的列。
- llm_annotations.tsv含`relevant_zeroshot/relevant_fewshot`和`territory_zeroshot/territory_fewshot`，是模型产生的相关性与观点标签。
- 本地HF builder在`/workspace/real-data-validation/bordirlines.py:243–265`将人类`territory`映射为`viewpoint_human`，LLM`territory_<mode>`去掉选项前缀后映射为`viewpoint_llm`。这两个标签需分别保留来源，不能冒充独立人工审核的作者立场。
- 标签依赖具体问题，同一段落用于不同领土问题时可能有不同相关性或观点标签；不能只按doc_id全局覆盖。
- 文件实际含doc_lang；当前builder的标注索引只用(query_id,doc_id)，审计若发现语言ID冲突应额外核查，不要继承这种索引假设。
- 未被标注的原始段落不能当成Neutral；relevant=False、Neutral、缺失分别代表不同含义。

加载后的HF行将query_id、query、query_lang、territory、rank、score、doc_id、doc_lang、doc_text及上述标签放在一起，doc_text取自all_docs（builder:277–290）。relevance_filter='all'时不作相关性过滤；viewpoint_filter没有启用时不按观点筛选。

## 六、生成与评价

- `generation/generation_lib.py:130–145`把HF行组织成`{territory_language: {query,nhits,hits}}`，hit的doc_id改名pid，doc_text改名text。
- `generation/generation.py:500–517`按hits顺序取text/language/pid，记录生成结果的query、choice、raw_response、claimant_ind、doc_ids。no_ir输入文档为空。
- `generation_lib.py:291–311`的Document:0、Document:1是本次提示词中的位置编号，不是Wikipedia页面ID或原始paragraph index。
- 生成结果的claimant_ind是候选序号；CSV adapter用它索引英文Claimants得到规范国家名（`gen_response_table.py:62–80`）。其-1回退到第一候选的行为需防护，不能把无效答案当成有效模型预测。
- adapter将同一领土各语言答案聚合为Responses_d，另取英语Response_en和控制方语言Response_Controller（`gen_response_table.py:104–117`）。CS基于这些选择及Controller参考计算，不是对原始文档事实或立场的直接评分。

## 七、全量跨语言比较必须遵守的界限

1. 原始file ID、打包query ID、段落ID、提示词Document编号分别管理。
2. 同数字page_id不代表跨语言同实体；同metadata领土键也不代表其中都是该领土词条。
3. zhs/zht是同中文来源的文字转换，不能视为独立语言社区立场。
4. 页面修订时间不同、事件时间不同、细节缺失、参考/类别污染，应先排除，再讨论立场或事实冲突。
5. 能全量自动核实的是文件/字段、映射、版本、段落、缺失、现有标签及候选差异；需要原文命题与出处才能判断具体立场。以语言、标题或单个国家名判断立场是不可靠的。
