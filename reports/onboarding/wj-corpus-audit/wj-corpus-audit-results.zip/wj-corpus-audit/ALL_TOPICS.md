# 全量主题对照清单

全部词条已进入结构审计；此清单是导语/关键词摘录的可追溯初筛，不是62,359段全文经语言专家审校。观点差异、事实互补、可能冲突、对象错配分别标记；简繁同源不算独立立场。

## Aarsal（英文锚点 45183449）

语言：ar, en；类型：territory_or_related_geography；状态：excerpt_screened_no_clear_difference。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Abagaitu Islet（英文锚点 5882224）

语言：en, ru, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英语说明2004年签约及2005年批准，中文补充2008年划界与具体面积；属于协议阶段和执行细节互补，不能把年份不同直接当冲突。简繁同源不作独立观点。（置信标记：high）
  - `en/Q5882224.json`，`article[2]`：In 2005, the Russian Duma and the Chinese National People's Congress approved the agreement.
    中文释义：2005年俄罗斯杜马与中国全国人大批准协议。。
  - `zhs/Q111765.json`，`article[3]`：划归中方34.54平方公里，划归俄方23.02平方公里。
    中文释义：原文为中文，给出双方具体面积。。

- **措辞／归因／命名差异**：中文先称原为中国领土并叙述苏联占领，俄语导语先述现在两国大致平分。观察到历史与现状的叙述优先级不同，并非两者必然冲突。（置信标记：medium）
  - `zhs/Q111765.json`，`article[1]`：此岛原是中国领土
    中文释义：原文历史归属表述。。
  - `ru/Q2914696.json`，`article[0]`：разделённый между двумя государствами — Россией и Китайской Народной Республикой (КНР) примерно пополам.
    中文释义：由俄中两国大致各分一半。。

## Abu Musa（英文锚点 931858）

语言：ar, en, fa；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：阿拉伯语使用“占领”，波斯语突出伊朗所有权及其无可争议主权主张，英语突出管理与声索的区别。可观察到措辞/归因差异，不据此裁定主权或把语言社区整体判为有偏。（置信标记：medium_preliminary）
  - `ar/Q253038.json`，`article[0]`：حيث احتلتها إيران في عام 1971، وضمتها إدارياً إلى محافظة هرمزغان الإيرانية، فيما تطالب بها دولة الإمارات العربية المتحدة وتعتبرها تابعة لإمارة الشارقة. / تقع « جزيرة أبو موسى » على ب
    中文释义：称伊朗于1971年占领并纳入行政管理，阿联酋持续声索。。
  - `fa/Q26594.json`，`article[1]`：جزیره ابوموسی به‌عنوان بخشی از استان هرمزگان در مالکیت و کنترل ایران است؛ با این‌حال، امارات متحده عربی بر آن ادعای مالکیت می‌کند و آن را بخشی از امارت شارجه می‌داند. ایران همواره بر حق حاکمیت بی چون و چرا بر این جزیره تأکید کرده‌است. در حال حاضر اکثریت جمعیت ابوموسی را شهروندان ایران تشکیل می‌دهند 
    中文释义：称该岛属伊朗所有并由其控制，同时记载阿联酋声索；称伊朗强调无可争议的主权。。
  - `en/Q931858.json`，`article[0]`：The island is administered by Iran as part of its province of Hormozgan, but is also claimed by the United Arab Emirates as a territory of the emirate of Sharjah.
    中文释义：区分伊朗实际管理与阿联酋声索。。

## Abyei（英文锚点 13885196）

语言：ar, en；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：阿语导语直接称苏丹地区，英文明示依据和平协议在过渡期同时属于南苏丹和苏丹的共管安排；这是法律/行政状态的呈现差异，不裁定主权。（置信标记：medium）
  - `ar/Q947434.json`，`article[0]`：أبيي منطقة سودانية حصلت على وضع خاص ضمن اتفاقية السلام الشامل بين حكومة السودان والحركة الشعبية لتحرير السودان. كانت تابعة لولاية غرب كردفان التي تم حلها بعد توقيع اتفاق السلام. سك
    中文释义：阿卜耶伊是获得特别地位的苏丹地区。。
  - `en/Q13885196.json`，`article[0]`：The Abyei Area () is an area of  on the border between South Sudan and the Sudan that has been accorded "special administrative status" by the 2004 Protocol on the Resolution of th
    中文释义：根据议定书过渡期同时被视为两共和国一部分。。

## Afghanistan（英文锚点 737）

语言：en, fa, zht；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英、波斯语导语均使用阿富汗伊斯兰酋长国这一官方名称；中文摘录提供共和国成立、2021年塔利班重新控制与抵抗力量的历史过程。属于政权沿革细节互补，不宜仅因共和国/酋长国词语并存判为同一时间的事实矛盾。（置信标记：medium）
  - `en/Q737.json`，`article[0]`：Afghanistan, officially the Islamic Emirate of Afghanistan
    中文释义：阿富汗，正式名称为阿富汗伊斯兰酋长国。。
  - `fa/Q802.json`，`article[0]`：افغانستان () با نام رسمی امارت اسلامی افغانستان، کشور محصور در خشکی در بین آسیای میانه و آسیای جنوبی است. این 
    中文释义：阿富汗正式名称为阿富汗伊斯兰酋长国。。
  - `zht/Q8300.json`，`article[1]`：1919年8月19日，第三次英國-阿富汗戰爭結束後，末代阿富汗埃米爾阿曼諾拉汗宣告阿富汗的獨立主權。1973年，巴拉克宰王朝統治的阿富汗王國遭不流血政變推翻，成立阿富汗共和國。之後再歷經軍事政變、蘇聯入侵和軍閥內戰，先後成立了阿富汗民主共和國、阿富汗伊斯蘭國和阿富汗伊斯蘭酋長國（也稱塔利班政權）。2001年，阿富汗伊斯蘭酋長國因阿富汗戰爭倒臺。2004年1月26日，美國扶持的阿富汗伊斯蘭共和國成立。2021年8月美軍宣佈撤出阿富汗後，塔利班迅速擊潰政府軍佔領絕大多數阿富汗領土，8月15日攻入喀布爾後總統加尼逃到國外；8月17日阿富汗第一副總統阿姆魯拉·薩利赫宣佈依據阿富汗憲法就任代理總統，與國防部長比斯米拉·汗·穆罕默迪、阿富汗駐塔吉克斯坦大使阿格巴爾組成潘傑希爾抵抗勢力；阿富汗伊斯蘭共和國常駐聯合國代表古拉姆·伊薩克扎伊（）呼籲聯合國不要承認以武力奪權的政權。
    中文释义：此段按年份介绍1973年后的政权变化及2021年塔利班攻入喀布尔。。

## Aksai Chin（英文锚点 66988）

语言：en, hi, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：印地语首段含“印度将取回这些面积”的预测性、倡议性句子，并有38000/43180的面积计算；英文首段区分中国管理与印度声索。观察到明显叙述语气差异，也可能是该快照编辑质量问题，不能直接推断整个语言社区立场。（置信标记：high）
  - `hi/Q40483.json`，`article[0]`：तो अब भारत चीन से इतना ही एरिया वापस लेगा।
    中文释义：所以现在印度将从中国取回这么多面积。。
  - `en/Q66988.json`，`article[0]`：It is claimed by India as part of its Leh District, Ladakh Union Territory.
    中文释义：印度声称该地属于其拉达克列城县。。

## Algeria（英文锚点 358）

语言：ar, en；类型：country；状态：excerpt_screened_no_clear_difference。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Ambalat（英文锚点 8175509）

语言：en, id, ms；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：印尼语给出区块范围与并非全部富油，马来语区分争议6/7区块和不争议的南部；不是简单一方否认另一方主权。（置信标记：medium）
  - `id/Q238216.json`，`article[0]`：Blok laut ini tidak semuanya kaya akan minyak mentah.
    中文释义：这些海域区块并非全部富含原油。。
  - `ms/Q88028.json`，`article[0]`：Perairan Ambalat Selatan, kawasan Indonesia, tidak dipertikaikan.
    中文释义：南Ambalat的印尼海域没有争议。。

## Ankoko Island（英文锚点 4322752）

语言：en, es；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：英语使用occupation叙事并记载Guyana认为入侵；西语导语首先写委内瑞拉行政管理、圭亚那声索东半部，但其后也明确归因圭亚那的annexation/aggression说法。存在框架/排序侧重，而不是西语完全不承认争议。（置信标记：high）
  - `en/Q4322752.json`，`article[3]`：Five months after Guyana's independence from the United Kingdom, Venezuelan troops began their occupation of Ankoko Island and surrounding islands in October 1966. Venezuelan troops qui
    中文释义：委内瑞拉军队于1966年10月开始占领该岛及周围岛屿。。
  - `es/Q428283.json`，`article[0]`：La isla de Anacoco (en inglés Ankoko Island) es una isla fluvial de 8 km² administrada por Venezuela como parte del territorio de la Parroquia Dalla Costa en el Municipio Sifontes del Estado Bolívar —en la que se encuentra el asentamiento militar "Base de Seguridad Territorial Isla de Anacoco"—, pero cuya mitad oriental es reclamada por Guyana. Está situada al norte d
    中文释义：岛由委内瑞拉管理，东半部由圭亚那声索。。
  - `es/Q428283.json`，`article[3]`：El 12 de octubre una delegación de funcionarios y policías guyaneses comprobó la ocupación de la isla. El Estado guyanés lo consideró como un acto de anexión, agresión y hostigamiento por parte de Venezuela dado que ente
    中文释义：圭亚那政府将其视为吞并、侵略和骚扰行为。。

## Argentina（英文锚点 18951905）

语言：en, es；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英文概述联邦结构，西文补充1994年与辖区自治细节；属于细节互补，首段差异未显示明确主权冲突。（置信标记：medium_preliminary）
  - `en/Q18951905.json`，`article[0]`：Argentina is a federal state subdivided into twenty-three provinces, and one autonomous city, which is the federal capital and largest city of the nation, Buenos Aires. The provinces and the capital have their 
    中文释义：联邦由23省与一个自治市组成。。
  - `es/Q10.json`，`article[1]`：La Argentina está organizada como un Estado federal descentralizado, integrado desde 1994 por veintitrés provincias y la Ciudad Autónoma de Buenos Aires (CABA), capital federal del país. Las veinticuatro jurisdicciones o distritos autogobernados tienen constitución, bandera y fuerza de seguridad propios. Las provincias mantienen todos los poderes n
    中文释义：补充自1994年由23省和布宜诺斯艾利斯自治市组成，各辖区有本身制度。。

## Armenia（英文锚点 10918072）

语言：az, en, hy；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：亚美尼亚语导语增加历史亚美尼亚范围与经拉钦走廊连接阿尔察赫的描述；英文导语提供拉钦走廊俄维和部队语境。修订年代和历史范围不同，不据此判定一方错误。（置信标记：medium）
  - `hy/Q800.json`，`article[0]`：Հայաստան , պաշտոնական անվանումը՝ Հայաստանի Հանրապետություն, պետություն Առաջավոր Ասիայում՝ Հայկական լեռնաշխարհի հյուսիսարևելյան մասում։ Քաղաքական և մշակութային իմաստով, սակայն, գտնվ
    中文释义：亚美尼亚共和国位于亚美尼亚高地东北，并描述历史领土与走廊联系。。
  - `en/Q10918072.json`，`article[0]`：Armenia (), officially the Republic of Armenia, is a landlocked country in the Armenian Highlands of Western Asia. It is a part of the Caucasus region and is bordered by Turkey to 
    中文释义：。

- **数字／时间候选差异**：两版本同在叙述提格兰大帝时段，az出现“公元前50世纪”而en为“公元前1世纪”，属于疑似文本错误/年代差异，需核对原引用，不能解释成政治立场。（置信标记：high）
  - `az/Q615.json`，`article[1]`：eramızdan əvvəl 50-ci əsrdə
    中文释义：公元前第50世纪。
  - `en/Q10918072.json`，`article[1]`：in the 1st century BC
    中文释义：公元前1世纪。

## Artsvashen（英文锚点 6251782）

语言：az, en, hy；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：阿塞拜疆语首段以阿塞拜疆行政村为框架；亚美尼亚语首段以亚美尼亚飞地及“被阿塞拜疆军队占领”为框架；英文分开de jure Armenian与de facto Azerbaijani。属于归属/控制叙述及措辞差异，不作外部主权裁定。（置信标记：high）
  - `az/Q220398.json`，`article[0]`：Azərbaycan Respublikasının Gədəbəy rayonunun inzibati-ərazi vahidində kənd.
    中文释义：阿塞拜疆共和国盖达贝克区行政单位内的村庄。。
  - `hy/Q6659.json`，`article[0]`：1992 թվականի օգոստոսի 8-ից մինչ օրս բռնազավթված է Ադրբեջանի զինված ուժերի կողմից։
    中文释义：自1992年8月8日至今被阿塞拜疆武装力量占领。。
  - `en/Q6251782.json`，`article[0]`：is a de jure Armenian village
    中文释义：是法理上的亚美尼亚村庄。

## Arunachal Pradesh（英文锚点 178710）

语言：en, hi, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英语与简体中文导语均把它描述为印度的邦；中文另详细说明中华人民共和国不承认该邦合法性的声索，而英语也记载中国称其为Zangnan。是共同基础事实加声索细节互补；简繁中文不是两份独立观点。（置信标记：high）
  - `en/Q178710.json`，`article[0]`：Arunachal Pradesh (, ) is a state in Northeastern India. It was formed from the erstwhile North-East Frontier Agency (NEFA) region
    中文释义：阿鲁纳恰尔邦是印度东北部的邦。。
  - `en/Q178710.json`，`article[3]`：A major part of the state is claimed by the People's Republic of China, which refers to it as "Zangnan," (lit. "South Tibet"). The People's Liberation Army briefly occupied parts of the stat
    中文释义：中华人民共和国声索该邦大部分地区，称之为藏南。。
  - `zhs/Q3104.json`，`article[2]`：除了长朗县、蒂拉普县等少数地区外，中华人民共和国对该邦的大部分地区宣称主权，主要划入西藏自治区的错那、隆子、墨脱、察隅四县的管辖范围之内，拒绝承认阿鲁纳恰尔邦的合法性，中华人民共和国官方媒体一般以带有引号的“阿鲁纳-{}-恰尔邦”来称呼该邦。中国人民解放军在中印边界战争中短暂占领了部分地区，但随后撤回。
    中文释义：中华人民共和国声索大部分地区，并拒绝承认该邦合法性。。

## Ashmore and Cartier Islands（英文锚点 1227）

语言：en, id；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：两语历史相合；印尼语另给出由堪培拉主管部门管理的行政细节，与英语澳大利亚海外领地性质互补。（置信标记：medium）
  - `en/Q1227.json`，`article[0]`：is an uninhabited external territory of Australia
    中文释义：是澳大利亚无人居住的海外领地。。
  - `id/Q514162.json`，`article[9]`：Saat ini, wilayah tersebut dikelola dari Canberra
    中文释义：目前该领地由堪培拉管理。。

## Australia（英文锚点 4689264）

语言：en, id；类型：country；状态：excerpt_screened_no_clear_difference。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Azad Kashmir（英文锚点 2745）

语言：en, hi, ur；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英文摘录补充名义自治及议会、总统、总理制度；乌尔都语摘录补充面积、人口、语言与教育率。均承认巴基斯坦管理，不能据摘录将“自治”与“行政分区”直接当成事实矛盾。（置信标记：medium）
  - `en/Q2745.json`，`article[1]`：The territory has a parliamentary form of government modelled after the British Westminster system
    中文释义：该地区有仿照英国威斯敏斯特体系的议会政府制度。
  - `ur/Q12999.json`，`article[0]`：آزاد کشمیر کی شرح تعلیم 65 فیصد ہے۔
    中文释义：阿扎德克什米尔识字率为65%。。

## Azerbaijan（英文锚点 746）

语言：az, en, hy, ka；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：az突出被占领的阿塞拜疆领土，hy对纳希切万使用被并入/兼并叙述且列阿尔察赫为邻；en区分国际承认与自称政体。这是归因及框架差异，非对历史归属的独立裁定。（置信标记：high）
  - `az/Q1088.json`，`article[0]`：Ermənistan tərəfindən işğal olunmuş
    中文释义：被亚美尼亚占领。
  - `hy/Q1396.json`，`article[0]`：Խորհրդային տարիներին Ադրբեջանին բռնակցված Նախիջևանի Ինքնավար Հանրապետությունը
    中文释义：苏联时期被并入阿塞拜疆的纳希切万自治共和国。
  - `en/Q746.json`，`article[1]`：internationally recognized as part of Azerbaijan
    中文释义：国际上承认为阿塞拜疆一部分。

## Bahrain（英文锚点 18933277）

语言：ar, en；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：人口数值对应不同年份，不能当作同一时点事实冲突或立场偏差；应分别保留数据日期。（置信标记：medium_preliminary）
  - `ar/Q3014.json`，`article[0]`：بلغ عدد سكانها إحصاء عام 2010 ما يقارب 1,234,571 نسمة، منهم 666,172 نسمة من غير المواطنين. نالت البحرين استقلالها عن بريطانيا عام 1971، وتم 
    中文释义：2010年人口约1,234,571。。
  - `en/Q18933277.json`，`article[0]`：The current population of Bahrain is 1,870,817 as of May 14, 2023, based on elaborations of the latest United Nations data, of whom 712,362 are Bahraini nationals. Bahrain spans so
    中文释义：2023年5月14日人口估计1,870,817。。

## Bajo Nuevo Bank（英文锚点 750900）

语言：en, es；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：英语导语突出哥伦比亚与美国的主权争端，西语导语先作为哥伦比亚行政区叙述并提2012裁决；这是叙述框架差异，双方也都提及裁决，不能据导语推断全文单方偏见。（置信标记：medium）
  - `en/Q750900.json`，`article[1]`：The reef is now subject to a sovereignty dispute involving Colombia and the United States.
    中文释义：该礁目前存在涉及哥伦比亚和美国的主权争端。。
  - `es/Q866579.json`，`article[0]`：Este pequeño territorio forma parte del departamento colombiano
    中文释义：这个小领土是哥伦比亚某省的一部分。。

## Banc du Geyser（英文锚点 4759151）

语言：ar, en, fr；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英语摘录集中介绍多方EEZ声索和法国实际控制，法语摘录补充1976年马达加斯加声索/吞并及1977年科学考察；阿语导语给出距离和礁体地理细节。未在这些陈述中建立相同命题的直接冲突。（置信标记：medium）
  - `en/Q4759151.json`，`article[5]`：France and the Comoros claim the Banc du Geyser as part of their exclusive economic zone (EEZ). The reef is also claimed by Madagascar. From the French point of view, it is a part of the EEZ of Glorioso Islands, one of their Scattered Islands in the Indian Ocean. Madagascar announced its annexation in 1976, presumably because of the possibility of oil fields in the vicinity but the Banc du Geyser is controlled in fact by the French forces armées de la zone sud de l'océan Indien.
    中文释义：法国、科摩罗、马达加斯加均声索，段落另说明法国部队实际控制。。
  - `fr/Q1026465.json`，`article[7]`：En 1976, le récif a été revendiqué et annexé par Madagascar, car il entre aussi dans la limite des  pour sa propre ZEE. En 1977, la première expédition scientifique officielle (mission Benthédi) est menée sur le banc. 
    中文释义：1976年马达加斯加声索并宣布吞并；1977年进行了科学考察。。
  - `ar/Q7797164.json`，`article[0]`：بانك دو جيسير (بالإنجليزية:Banc du Geyser) هي جزيرة من الشعاب المرجانية مغمورة في الجزء الشمالي الشرقي من قناة موزمبيق ، تقع على بعد 125 كم (70 ميل) شمال شرق جزيرة مايوت ،و 112 كم (70 ميل) جنوب غرب جزر جلوريوسو و 200 كم (124 ميل) 
    中文释义：提供相对马约特、格洛里厄斯和马达加斯加的位置距离。。

## Bangladesh（英文锚点 3454）

语言：bn, en, my；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：孟加拉语首段补充跨境河流数量，英文补充锡利古里走廊与不丹/尼泊尔地理关系；人口数字为不同精度估计，未作为矛盾。（置信标记：medium）
  - `bn/Q822.json`，`article[0]`：বাংলাদেশ ভূখণ্ডের উপর দিয়ে বয়ে গেছে ৫৭টি আন্তর্জাতিক নদী।
    中文释义：有57条国际河流流经孟加拉国。。
  - `en/Q3454.json`，`article[0]`：It is narrowly separated from Bhutan and Nepal by the Siliguri Corridor
    中文释义：锡利古里走廊将其与不丹、尼泊尔狭窄地分隔开。

- **数字／时间候选差异**：英语约169百万人、缅甸语约163百万人。仅标记人口估计或时间口径差异候选，不能当作领土立场冲突；需核对各版本来源年份。（置信标记：medium）
  - `en/Q3454.json`，`article[0]`：around 169 million people
    中文释义：约1.69亿人口。
  - `my/Q3186.json`，`article[0]`：လူဦးရေ ၁၆၃ သန်းခန့်
    中文释义：人口约1.63亿。

## Barahoti（英文锚点 65415698）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Barkhudarli（英文锚点 19078877）

语言：az, en, hy；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：阿塞拜疆语强调占领及阿塞拜疆飞地，亚美尼亚语以亚美尼亚境内原聚落开头并列双方行政归属。英语归档无正文，不能称其省略了争议。（置信标记：medium_preliminary）
  - `az/Q120315.json`，`article[1]`：Kənd 4 gün mühasirədə qaldıqdan sonra 27 aprel 1992-ci ildən Ermənistan Silahlı Qüvvələri tərəfindən işğal edilmişdir.
    中文释义：称村庄自1992年4月27日起被亚美尼亚武装力量占领。。
  - `hy/Q856877.json`，`article[0]`：Բարխուդարլու (նաև՝ Բարխուդարլի, Բարխուդարլը, ), նախկին բնակավայր Հայաստանի Տավուշի մարզի արևելքում՝ հայ-ադրբեջանական շփման գծի հարևանությամբ։ Խորհրդային Միության ժամանակաշրջանում բնակավայրը ներառվել է Ադրբեջանական ԽՍՀ-ի կազմում։ ԽՍՀՄ փլուզումից հետո՝ 1991-1994 թվականների Արցախյան պատերազմի ընթացքում, այն ընդգրկվեց Հայաստանի Հանրապետության տարածքում։ Համաձայն Հայաստանի վարչատարածքային բաժանման՝ այն գտնվում է Հայաստանի Տավուշի մարզում, իսկ ըստ Ադրբեջանի վարչատարածքային բաժանման՝ այն տեղակայված է Ադրբեջանի Հանրապետության Ղազախի շրջանում։
    中文释义：描述为亚美尼亚塔武什州东部的原聚落，并同时列出亚美尼亚和阿塞拜疆行政划分。。

## Bassas da India（英文锚点 3456）

语言：en, fr, mg；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英语将法国管辖与马达加斯加自1972年声索分别陈述；法语段落补充TAAF行政组织。马达加斯加语导语同样列法国南方和南极领地，不能仅依据语言预设相反立场。（置信标记：medium）
  - `en/Q3456.json`，`article[5]`：Madagascar became independent in 1960 and has claimed sovereignty over the shoal since 1972.
    中文释义：马达加斯加1960年独立，自1972年声索主权。。
  - `fr/Q373929.json`，`article[0]`：faisant partie des îles Éparses de l'océan Indien
    中文释义：属于印度洋散布群岛。。

## Bedel pass（英文锚点 8381223）

语言：en, ky, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **证据不足**：英文原始article为空，简繁内容同源且修订相同；本组不能提供两个独立语言版本的立场对比。（置信标记：medium_preliminary）
  - `zhs/Q6012754.json`，`article[0]`：别迭里山口(Bedel Pass)，是连接新疆阿合奇县库兰萨日克乡与吉尔吉斯斯坦伊塞克湖南岸巴尔斯罕的山口，海拔4,284米。
    中文释义：别迭里山口连接新疆与吉尔吉斯斯坦。。
  - `zht/Q6012754.json`，`article[0]`：別迭裏山口(Bedel Pass)，是連接新疆阿合奇縣庫蘭薩日克鄉與吉爾吉斯斯坦伊塞克湖南岸巴爾斯罕的山口，海拔4,284米。
    中文释义：同一段的繁体转换。。

- **证据不足**：英语Bedel pass页面article为空，只有吉尔吉斯语实质正文，无法完成这一组的跨语言观点比较。海拔等物理信息可保留，不推断缺失正文的语言立场。（置信标记：medium）
  - `ky/Q49731.json`，`article[0]`：Бийикт. 4260 м.
    中文释义：海拔4260米。

## Belize（英文锚点 3458）

语言：en, es；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：西语导语补充飓风后迁都及伯利兹城至1970年的首都身份；英语导语补充2022人口及殖民制度背景；首都和邻国信息相容。（置信标记：medium）
  - `es/Q7788.json`，`article[0]`：Belice () es un país soberano de América ubicado en el extremo noreste de América Central. Limita al norte con México y al sur y oeste con Guatemala, y el golfo de Honduras lo sepa
    中文释义：。
  - `en/Q3458.json`，`article[0]`：Belize (; ) is a country on the north-eastern coast of Central America. It is bordered by Mexico to the north, the Caribbean Sea to the east, and Guatemala to the west and south. I
    中文释义：。

## Benin（英文锚点 3459）

语言：en, fr；类型：country；状态：excerpt_screened_no_clear_difference。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Bhutan（英文锚点 2421391）

语言：dz, en, zhs, zht；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：中文首段补充藏文化与名称解释，第二段补充2008年宪政；英文第二段补充山峰、动植物及城市人口。是历史文化/自然与制度信息互补，简繁版本非独立观点。（置信标记：medium）
  - `zhs/Q7026.json`，`article[1]`：2008年宪法建立了一个议会
    中文释义：2008年宪法建立议会。
  - `en/Q2421391.json`，`article[1]`：Gangkhar Puensum is Bhutan's highest peak and is the highest unclimbed mountain in the world.
    中文释义：冈嘎本孙峰是不丹最高峰，也是世界最高未登峰。。

- **摘录未见明确差异**：宗喀语可比正文极少，所引地理句与英语东喜马拉雅位置相容；没有足够材料推断宗喀语缺少何种观点或全文立场。（置信标记：medium）
  - `en/Q2421391.json`，`article[0]`：It is situated in the Eastern Himalayas
    中文释义：位于东喜马拉雅。
  - `dz/Q2589.json`，`article[0]`：ཧི་མ་ལ་ཡ་རི་རྒྱུད་ཆེན་པོའི་ལྷོ་ཕྱོགས་སུ་རྒྱལ་ཁབ་ཞིག་རེད
    中文释义：是位于喜马拉雅山脉南侧的国家。

## Bolivia（英文锚点 3462）

语言：en, es, pt；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：已阅首部中英文强调国家与首都结构，西文给出出海口主张信息；是不同命题的互补，不是相反事实。不得据此推断英文全文没有该信息。（置信标记：medium_preliminary）
  - `en/Q3462.json`，`article[0]`：The seat of government and executive capital is La Paz, while the constitutional capital is Sucre. The largest city and principal industrial center is Santa Cruz de la Sierra, located on the Llanos Orientales (tropical l
    中文释义：区分拉巴斯政府所在地与苏克雷宪法首都。。
  - `es/Q110229.json`，`article[1]`：constitucionalmente mantiene una reclamación territorial a Chile por una salida soberana al océano Pacífico; sin embargo, tiene un enclave en Perú denomidado Boliviamar, una playa de 5 kilómetros de costa. Su superficie es la sexta más extensa de Latinoamérica
    中文释义：补充对智利出海口的宪法性领土要求及在秘鲁的Boliviamar。。

## Bolshoy Ussuriysky Island（英文锚点 5874630）

语言：en, ru, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：1860年的岛屿法律状态呈现明确叙述张力：英语由条约推导岛屿属中国，俄语称岛屿地位不确定。需历史来源复核；这是文档主张差异，不裁定哪方正确。（置信标记：high）
  - `en/Q5874630.json`，`article[1]`：As such the island at the confluence of the two rivers was Chinese.
    中文释义：因此两河交汇处的岛屿属中国。。
  - `ru/Q1273884.json`，`article[4]`：а статус островов был неопределенным.
    中文释义：而岛屿的地位是不确定的。。

- **实体范围／清洗风险**：中文导语以93个岛屿沙洲的岛系描述黑瞎子岛，英语明确Heixiazi可指大岛或整个岛群。面积数字比较前必须统一范围。（置信标记：high）
  - `zhs/Q109209.json`，`article[0]`：由包括银龙岛、黑瞎子岛在内的93个岛屿和沙洲组成
    中文释义：中文描述一个包含93个岛屿沙洲的岛系。。
  - `en/Q5874630.json`，`article[0]`：Heixiazi may refer only to the large island or to the island group collectively
    中文释义：Heixiazi可以仅指大岛，也可以统指岛群。。

## Bosnia and Herzegovina（英文锚点 3463）

语言：bs, en, sr；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：塞语第二段强调两个实体及布尔奇科特殊地位，波语导语强调独立公投与2013人口；两种内容互补，不能仅因政治制度焦点不同判为偏差。（置信标记：medium）
  - `sr/Q160.json`，`article[1]`：Босна и Херцеговина се састоји од два ентитета: Федерације Босне и Херцеговине и Републике Српске, док Брчко Дистрикт има посебан статус. Три најбројнија народа су Бошњаци, Срби и 
    中文释义：波黑由联邦与塞族共和国两实体构成，布尔奇科具有特别地位。。
  - `bs/Q830.json`，`article[0]`：Bosna i Hercegovina (skraćeno BiH, neformalno Bosna, ćirilica Босна и Херцеговина) suverena je država u jugoistočnoj Evropi, smještena na zapadu Balkanskog poluostrva. Na sjeveru, 
    中文释义：。

## Brazil（英文锚点 3383）

语言：en, es, pt；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：英语导语人口超过2.17亿、世界第七，葡语超过2.078亿、世界第六。数字和排名的参考时期可能不同，需核对各段数据日期/来源；不能直接当作政治立场差异。（置信标记：medium）
  - `en/Q3383.json`，`article[0]`：Brazil (; ), officially the Federative Republic of Brazil (Portuguese: ), is the largest country in South America and in Latin America. At  and with over 217 million people, Brazil is the world's fifth-largest country by area and the seventh most populous. Its
    中文释义：人口超过2.17亿、世界第七。。
  - `pt/Q404.json`，`article[0]`：Brasil (), oficialmente República Federativa do Brasil (), é o maior país da América do Sul e da região da América Latina, sendo o quinto maior do mundo em área territorial (equivalente a 47,3% do território sul-americano), com  km², e o sexto em população (com mais de 207,8 milhões de habitantes). É o único país na América onde se fala majoritariamente a língua portuguesa e o maior país
    中文释义：人口超过2.078亿、世界第六。。

## Brazilian Island（英文锚点 8079600）

语言：en, es, pt；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：葡语把行政上属于巴西市镇直接写入叙述，西语以巴西管理、乌拉圭声索区分；英文说明双方声索。三者并未在实际管理方上明确矛盾，差异主要是归属叙述方式与乌拉圭论据的详略。（置信标记：medium）
  - `pt/Q631519.json`，`article[1]`：Administrativamente, a ilha pertence ao município brasileiro de Barra do Quaraí
    中文释义：行政上，该岛属于巴西巴拉杜夸赖市。
  - `es/Q420897.json`，`article[0]`：bajo administración brasileña y reclamada por Uruguay
    中文释义：由巴西管理、乌拉圭声索。

## Brunei（英文锚点 3466）

语言：en, ms, tl, vi, zhs, zht；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **实体范围／清洗风险**：实体身份可对应，但马来语首段包含未清理的模板字段，不能把文本格式/清洗质量差异当成立场偏差。其余语言首段共同描述婆罗洲北部国家。（置信标记：medium_preliminary）
  - `ms/Q2008.json`，`article[0]`：| conventional_long_name = Negara Brunei Darussalam / | common_name            = Brunei / | image_flag             = Flag of Brunei.svg / | image_coat             = Emblem_of_Brunei.svg / | image_map              = Loc
    中文释义：马来语首段残留信息框字段。。
  - `en/Q3466.json`，`article[0]`：Brunei ( , ), formally Brunei Darussalam (, Jawi: , ), is a country located on the north coast of the island of Borneo in Southeast Asia. Apart from its South China Sea coast, it i
    中文释义：英文首段为文莱国家地理说明。。

- **事实互补**：两种版本导言均描述婆罗洲北岸国家；中文给1984年独立及入东盟日期，英语摘录侧重君主制及历史帝国。可作为事件/制度细节互补，简繁不是两种独立证据。（置信标记：medium）
  - `en/Q3466.json`，`article[0]`：a country located on the north coast of the island of Borneo
    中文释义：位于婆罗洲北岸的国家。
  - `zhs/Q26505.json`，`article[0]`：1984年1月1日文莱脱离英国和平独立，1月7日加入东盟
    中文释义：1984年1月1日独立，1月7日加入东盟。

## Burkina Faso（英文锚点 3470）

语言：en, fr；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：法语补充2022年政变终止民主时期的叙述；英语导语和历史段给出民族、殖民与独立背景。此处是所审片段主题覆盖互补，未据摘要判断全文缺失。（置信标记：medium）
  - `fr/Q490.json`，`article[1]`：Cette première période démocratique s'achève en 2022
    中文释义：这一首次民主时期于2022年结束。。
  - `en/Q3470.json`，`article[1]`：In 1960, it gained full independence
    中文释义：1960年获得完全独立。。

## Bạch Long Vĩ Island（英文锚点 4664976）

语言：en, vi, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：中文“送给”、越语“接收”和英语“移交”的行动者及叙述取向不同；三者1957交接事实可相容。繁中全文p18并列借岛/移交等说法，不能把其中一种作为定论。（置信标记：high）
  - `zht/Q38207.json`，`article[1]`：1957年此島連同島上民衆由毛澤東送給越南。
    中文释义：1957年岛和居民由毛泽东送给越南。
  - `vi/Q51284.json`，`article[11]`：Việt Nam Dân chủ Cộng hoà tiếp thu đảo từ Cộng hòa Nhân dân Trung Hoa.
    中文释义：越南民主共和国从中华人民共和国接收岛屿。
  - `en/Q4664976.json`，`article[11]`：China's government transferred the island to North Vietnam's government.
    中文释义：中国政府将岛移交北越政府。

- **数字／时间候选差异**：两词条对1887条约是否确定岛屿归属给出不同叙述，需核对条约条文、经线和岛/半岛对象。这是可复核的历史法律解释候选，不是语言本身的立场证明。（置信标记：high）
  - `vi/Q51284.json`，`article[8]`：nên thuộc về xứ Bắc Kỳ.
    中文释义：因此属于北圻。
  - `zht/Q38207.json`，`article[4]`：1887年的《中法續議界務專條》並未劃定此海域的歸屬
    中文释义：1887条约并未划定该海域归属。

## Cambodia（英文锚点 334751）

语言：en, km, lo, th；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：高棉语摘录人口超过1600万、世界第72；泰语/老挝语摘录超过1500万、世界第66。属于数据时间/统计来源待核对候选，而非已证实事实矛盾或立场偏差。（置信标记：medium）
  - `km/Q1770.json`，`article[1]`：ដោយមានប្រជាជន​ជាង ១៦ លាននាក់ កម្ពុជាស្ថិតក្នុងលំដាប់ទី៧២​ក្នុង​​លោក ទី២៧ក្នុងទ្វីបអាស៊ី និងទី៧ក្នុងអាស៊ីអាគ្នេយ៍។ ប្រជាជនជិតពាក់កណ្តាលប្រមូលផ្តុំកុះករនៅតំបន់វាលរាប ទ
    中文释义：人口超过1600万、世界第72。。
  - `th/Q1937.json`，`article[0]`：กัมพูชา หรือ ก็อมปุเจีย () ชื่ออย่างเป็นทางการว่า ราชอาณาจักรกัมพูชา หรือ ราชอาณาจักรก็อมปุเจีย () เป็นประเทศตั้งอยู่ในส่วนใต้ของคาบสมุทรอินโดจีนในเอเชียตะวันออกเฉียงใต้ มีพื้นที่ 181,035 ตารางกิโลเมตร มีพรมแดนทิศตะวันตกติดต่อกับประเทศไทย ทิศเหนือติดกับประเทศไทยและลาว ทิศตะวันออกและทิศใต้ติดกับเวียดนาม และทิศตะวันตกเฉียงใต้ติดอ่าวไทย ด้วยประชากรกว่า 15 ล้านคน กัมพูชาเป็นประเทศที่มีประชากรมากที่สุดอันดับที่ 66 ของโลก ศาสนาพุทธนิกายเถรวาทเป็นศาสนาประจำชาติ ซึ่งประชากรกัมพูชานับถือมากกว่า 97% ชนกลุ่มน้อยในประเทศมีชาวเวียดนาม ชาวจีน ชาวจาม และชาวเขากว่า 30 เผ่า เมืองหลวงและเมืองใหญ่สุด คือ พนมเปญ ซึ่งเป็นศูนย์กลางทาง
    中文释义：此导语包含人口超过1500万、世界第66的旧统计。。

## Cameroon（英文锚点 5447）

语言：en, es, fr；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：西语补充各邻国边界长度，法语首段补充官方语言，英文首段补充250种本土语言；地理与语言信息互补。（置信标记：medium）
  - `fr/Q717.json`，`article[0]`：Les langues officielles sont le français et l'anglais
    中文释义：官方语言为法语和英语。
  - `en/Q5447.json`，`article[0]`：speak 250 native languages and English or French or both
    中文释义：使用250种本土语言，以及英语或法语或两者。

## Ceuta（英文锚点 6443）

语言：ar, en, es；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：阿语导语将休达称为在西班牙主权下的摩洛哥城市，并归因摩洛哥认为其被占；英语和西语导语直接称西班牙自治市。存在明确归属框架差异，行政控制和声索仍须分开。（置信标记：high）
  - `ar/Q30703.json`，`article[0]`：سبتة هي مدينة مغربية تحت السيادة الإسبانية
    中文释义：休达是一座处于西班牙主权下的摩洛哥城市。。
  - `en/Q6443.json`，`article[0]`：is a Spanish autonomous city
    中文释义：是西班牙自治市。。
  - `es/Q4010.json`，`article[0]`：Ceuta es una ciudad autónoma española
    中文释义：休达是西班牙自治市。。

## Chagos Archipelago（英文锚点 606101）

语言：en, fr；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：法语导语概述英管理/毛里求斯声索及联大支持；英语第二段详述驱逐查戈斯人。两者属于政治地位和人群史互补。（置信标记：medium）
  - `fr/Q4427625.json`，`article[0]`：Larchipel des Chagos est un ensemble de sept atolls situés dans le Nord de l'océan Indien et totalisant cinquante-cinq îles, à  au sud de Malé, aux Maldives, et à  à l'est de Victo
    中文释义：。
  - `en/Q606101.json`，`article[1]`：The Chagos Islands had been home to the native Chagossians, a Bourbonnais Creole-speaking people, until the United Kingdom expelled them from the archipelago at the request of the 
    中文释义：。

## Chiengi（英文锚点 10842948）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Chile（英文锚点 5489）

语言：en, es；类型：country；状态：excerpt_screened_no_clear_difference。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Chumar（英文锚点 41435503）

语言：en, hi, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **实体范围／清洗风险**：英文讨论Chumar村及游牧放牧区域，并明确村本身无争议；中文标题/导语是楚马要塞(Chumar bunkers)、支普齐—楚木惹三角地的地堡群且称由中国控制；印地语是边防哨所。对象尺度不同，应先核对村、哨所和三角地的地理范围，不能把印度/中国控制字样直接当成同一实体的事实冲突。（置信标记：high）
  - `en/Q41435503.json`，`article[0]`：Chumar or Chumur () is a village and the centre of nomadic grazing region located in south-eastern Ladakh, India. It is in Rupshu block, south of the Tso Moriri lake, on the bank of the Parang River (or Pare Chu), close to Ladakh's border with Tibet. Since 2012, China has disputed the border in this area, though the Chumur village itself is undisputed.
    中文释义：Chumar是印度拉达克东南部村落及放牧地区；边界有争议但村本身无争议。。
  - `zhs/Q3459995.json`，`article[0]`：楚马要塞（Chumar bunkers），是印度的印-藏边防警察部队在中国西藏自治区阿里地区札达县楚鲁松杰乡的支普齐（Chepzi）-楚木惹三角地建立的地堡群。这个争议区属于中印边境争议地区的西段之西藏段，与印占拉达克地区为邻。目前该地由中国控制，碉堡群亦已被拆除。 / “楚马”，又译作“楚玛尔”，在中国地图上标注为“楚木惹”，印度的地图上标注为“Chumar”或“Chumur”。楚木惹三角高地示意图：
    中文释义：楚马要塞是支普齐—楚木惹三角地的地堡群，文中称目前由中国控制且已拆除。。
  - `hi/Q590700.json`，`article[0]`：चुमार भारत के जम्मू और कश्मीर राज्य के दक्षिणी लद्दाख क्षेत्र में स्थित सीमा चौकसी चौकी है। भारतीय एवं चीनी सैनिकों के बीच वास्तविक नियंत्रण रेखा पर आदान-प्रदान के मामले में यह चौकी सबसे संव
    中文释义：Chumar被描述为南拉达克的边防哨所。。

## Colombia（英文锚点 5222）

语言：en, es；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：西语第二段明确给出海疆声索、与委内瑞拉和尼加拉瓜的边界分歧；英文首段侧重地理与城市。不能将首段详略当作英文全文不承认争议。（置信标记：medium）
  - `es/Q456.json`，`article[1]`：manteniendo un diferendo limítrofe al respecto con Venezuela y Nicaragua
    中文释义：在这方面与委内瑞拉及尼加拉瓜存在边界争议。
  - `en/Q5222.json`，`article[0]`：Colombia is divided into 32 departments.
    中文释义：哥伦比亚分为32个省。。

## Comoros（英文锚点 5403）

语言：ar, en, fr, mg；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：马语面积2236km²，阿语面积1862km²；需区分群岛/国家范围、马约特计入与数据年份，不应直接判事实冲突。（置信标记：medium）
  - `mg/Q171405.json`，`article[0]`：I Kômôro na Firaisan' i Kômôro dia firenena ao Afrika Atsinanana, izay fitambaran' ny nosy vitsivitsy ao amin' ny Lakandranon' i Môzambika (Ranomasimbe Indiana), any avaratra-andre
    中文释义：国家面积2236平方公里，由三座主要岛构成。。
  - `ar/Q1714.json`，`article[1]`：تبلغ مساحة جزر القمر 1.862 كيلو متر مربع (أي 863 ميل مربع) لذا تعد ثالث أصغر دولة إفريقية من حيث المساحة، ويقدر عدد سكانها بـ876,935 نسمة وبذلك تعد سادس أقل دولة إفريقية من حيث عدد
    中文释义：面积1862平方公里，并列人口估计。。

## Conejo Island（英文锚点 5376108）

语言：en, es；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：两文均描述洪都拉斯归属与萨方声索；西文给出1982年主张的具体归因，并非直接证实占领事实。（置信标记：medium_preliminary）
  - `en/Q5376108.json`，`article[0]`：Conejo Island, in Spanish Isla Conejo, meaning "rabbit island", is a Honduran Island alongside many other islands in the region. El Salvador has disputed the Honduran island located in the Gulf of Fonseca.
    中文释义：称洪都拉斯岛屿，同时记载萨尔瓦多争议。。
  - `es/Q582425.json`，`article[0]`：El Salvador sostiene que Honduras la ocupó en 1982 con un pequeño destacamento militar. Posteriormente un fallo de la Corte Internacional de Justicia (CIJ) de La Haya en 1992 delimitó entre ambos países la posesión de varias islas y aguas del sector, pero El S
    中文释义：以归因方式补充萨尔瓦多关于洪都拉斯1982年占领的主张。。

## Congo River（英文锚点 44361）

语言：en, fr, sw；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：英语称按流量世界第三（亚马孙、恒河之后），法语与斯瓦希里语称第二。属于可核查排名冲突候选，应核对流量定义与数据期，不直接归为政治立场。（置信标记：high）
  - `en/Q44361.json`，`article[0]`：the third largest river in the world by discharge volume, following the Amazon and the Ganges rivers
    中文释义：按流量世界第三，位于亚马孙与恒河之后。。
  - `fr/Q101533.json`，`article[1]`：le second après l'Amazone pour son débit
    中文释义：按流量仅次于亚马孙，位列第二。。
  - `sw/Q3036.json`，`article[1]`：ni mto mkubwa wa pili duniani baada ya Amazonas
    中文释义：是世界第二大河，仅次于亚马孙。。

## Courantyne River（英文锚点 1993351）

语言：en, nl；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英荷语均描述圭亚那—苏里南界河；荷语补充按包括上游源河计算的约724公里长度及河口越境活动。属于范围和地理细节互补，不是归属相反。（置信标记：medium）
  - `en/Q1993351.json`，`article[0]`：The Courantyne/Corentyne/Corantijn River is a river in northern South America in Suriname and Guyana. It is the longest river in the country and creates the border between Suriname and the East Berbice-Corentyne region of Guyana. 
    中文释义：位于苏里南和圭亚那并形成边界。。
  - `nl/Q247651.json`，`article[0]`：De Corantijn (Engels: Courantyne) is een rivier in het noorden van Zuid-Amerika, op de grens van Guyana en Suriname. De lengte van de rivier is, inclusief de Boven-Corantijn (Nieuwe Rivier) als bronrivier, circa 724 km. De Corantijn stroomt uit in de Atlantische Oceaan.
    中文释义：包括Boven-Corantijn源河计算，全长约724公里。。

## Crimea（英文锚点 163045）

语言：en, ru, uk；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：俄语段落也明确国际社会不承认吞并、视克里米亚为乌克兰领土；乌语进一步使用非法吞并、武装侵略、所谓俄联邦主体等评价性法律措辞。存在措辞强度差异，但不能总结为俄语认可/乌语否认吞并的简单对立。（置信标记：high）
  - `ru/Q1936381.json`，`article[1]`：Международное сообщество не признаёт аннексии и рассматривает Крым как территорию Украины.
    中文释义：国际社会不承认吞并，并将克里米亚视为乌克兰领土。。
  - `uk/Q6620.json`，`article[1]`：Окупація півострова міжнародно не визнана та визначається як акт незаконної анексії внаслідок збройної агресії Росії.
    中文释义：半岛占领不获国际承认，被认定为俄罗斯武装侵略导致的非法吞并。。

## Croatia（英文锚点 5573）

语言：en, hr, sl, sr；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：同一布拉尼米尔时期日期出现876/879差别，但原句一个是国际承认、一个是独立国家；先核对命题与史料，不直接认定政治偏向。（置信标记：medium_preliminary）
  - `en/Q5573.json`，`article[1]`：7 June 879 during the reign of Duke Branimir. Tomislav became the first king by 925, elevating 
    中文释义：记载879年6月7日首次国际承认。。
  - `hr/Q7.json`，`article[1]`：7. lipnja 876. godine za vrijeme vladavine kneza Branimira prvi put i nezavisna država. Godine 925. pod vodstvom kralja Tomislava Hrvatska postaje kra
    中文释义：记载876年6月7日首次独立国家。。

## Dadivank（英文锚点 13450113）

语言：az, en, hy；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：此例存在明确的文化遗产归属叙述分歧：阿塞拜疆语导语归为高加索阿尔巴尼亚遗产；英语和亚美尼亚语归为亚美尼亚使徒教会修院，英语还直接评价阿方称谓为false。这里只记录各档案文本的不同归因和评价措辞，不据此独立裁定建筑历史。（置信标记：high）
  - `az/Q64847.json`，`article[0]`：Xudavəng monastırı — Kəlbəcər rayonunun Vəng kəndi ərazisində yerləşən Qafqaz Albaniyasına məxsus tarixi-memarlıq abidəsi. Azərbaycan Respublikası Mədəniyyət Nazirliyi tərəfindən dünya əhəmiyyətli abi
    中文释义：Xudaveng被描述为属于高加索阿尔巴尼亚的历史建筑。。
  - `en/Q13450113.json`，`article[0]`：Dadivank () or Khutavank () is an Armenian Apostolic monastery in the Kalbajar District of Azerbaijan bordering the Martakert Province of the self-proclaimed Republic of Artsakh. It was buil
    中文释义：Dadivank为亚美尼亚使徒教会修院。。
  - `en/Q13450113.json`，`article[1]`：In Azerbaijan, the monastery is called Dadivəng or Xudavəng. Azerbaijan denies the monastery's Armenian religious and cultural heritage, instead falsely referring to it as a "Caucasian Albanian temple."
    中文释义：英语直接称阿方“高加索阿尔巴尼亚神庙”归因为错误。。
  - `hy/Q12855.json`，`article[0]`：Դադիվանք (հայտնի է նաև Առաքելոց, Առաքելադիր անուններով), հայկական առաքելական միջնադարյան վանական համալիր Արցախի Հանրապետության Շահումյանի շրջանի Դադիվանք գյուղում՝ Դադիվան լեռան լա
    中文释义：亚美尼亚语称其为亚美尼亚使徒教会中世纪修院建筑群。。

## Darchen（英文锚点 27970715）

语言：en, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **证据不足**：英语有现状和前不丹飞地的历史叙述，但两份中文article数组为空，不能据此判断中文删去了哪些立场。（置信标记：high）
  - `en/Q27970715.json`，`article[0]`：is a former Bhutanese enclave, currently held by the People's Republic of China
    中文释义：是前不丹飞地，目前由中华人民共和国持有。。

## David Gareji monastery complex（英文锚点 590397）

语言：az, en, ka；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：az导语强调阿尔巴尼亚文化遗产，en导语直接称格鲁吉亚东正教建筑群；az第二段明确并列双方来源观点。涉及文化起源框架而不只是面积事实，需保留归因。（置信标记：high）
  - `az/Q85264.json`，`article[0]`：qədim Alban məbədi
    中文释义：古代高加索阿尔巴尼亚寺院。
  - `az/Q85264.json`，`article[1]`：Əksər gürcü mənbənləri isə məbədin gürcü mənşəli olub
    中文释义：多数格鲁吉亚来源认为寺院起源于格鲁吉亚。
  - `en/Q590397.json`，`article[0]`：a rock-hewn Georgian Orthodox monastery complex
    中文释义：岩凿格鲁吉亚东正教修道院建筑群。

- **事实互补**：英语概述边界争议；格鲁吉亚语具体区分Bertubani在阿塞拜疆境内及另两个修道院的争议，提供子地点层面的细节。不能把子建筑信息与整个建筑群归属直接等同。（置信标记：medium）
  - `en/Q590397.json`，`article[1]`：has become subject to a border dispute between the two countries
    中文释义：成为两国边界争议对象。
  - `ka/Q10605.json`，`article[0]`：სამონასტრო კომპლექსის მცირე ნაწილი (ბერთუბანი) აზერბაიჯანის ტერიტორიაზე მდებარეობს.
    中文释义：建筑群的一小部分Bertubani位于阿塞拜疆境内。

## Deir El Aachayer（英文锚点 31336052）

语言：ar, en；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：两语均将村庄置于黎巴嫩；英语细述德鲁兹人口和村政，阿语简短列行政归属。是详略差异，没有观察到归属冲突。（置信标记：medium）
  - `ar/Q536670.json`，`article[0]`：هي إحدى القرى اللبنانية
    中文释义：是黎巴嫩村庄之一。。
  - `en/Q31336052.json`，`article[1]`：predominantly Druze
    中文释义：主要为德鲁兹人。。

## Demchok sector （英文锚点 63855150）

语言：en, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **实体范围／清洗风险**：英文以Demchok sector为题，中文以Parigas/巴里加斯为题，并给1900平方公里及印度控制400平方公里。二者相关，但范围边界和别名映射需核实，不能把数值/区域范围差别直接视为语言立场冲突。（置信标记：medium）
  - `en/Q63855150.json`，`article[0]`：The Demchok sector is a disputed area named after the villages of Demchok in Ladakh and Demchok in Tibet
    中文释义：Demchok sector是以拉达克和西藏两处Demchok村命名的争议区域。
  - `zhs/Q1106358.json`，`article[0]`：巴里加斯（英语：Parigas）是中国和印度西部边境中的一块争议领土，面积约1,900平方公里
    中文释义：中文条目以Parigas/巴里加斯为题，给出约1900平方公里范围。

## Democratic Republic of Congo（英文锚点 44052）

语言：en, fr, sw；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **实体范围／清洗风险**：英语仅一条redirect字符串而法语有完整刚果民主共和国正文；不能把英语未述政治事实当编辑立场差异。（置信标记：medium）
  - `en/Q44052.json`，`article[0]`：redirect Democratic Republic of the Congo
    中文释义：。
  - `fr/Q2627.json`，`article[0]`：La république démocratique du Congo  (en kikongo ya leta : , en swahili : , en lingala : , en tshiluba : ), aussi appelée plus simplement RDC, Congo, RD Congo ou de manière informe
    中文释义：。

## Denmark（英文锚点 76972）

语言：da, en, is；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：英语称78个岛有人居住，冰岛语明确写72个(2007)。这是很可能受年份或岛屿统计口径影响的候选，不能判为同一时点矛盾。丹麦/王国及本土范围也须区分。（置信标记：medium）
  - `en/Q76972.json`，`article[1]`：As of 2013, the Kingdom of Denmark, including the Faroe Islands and Greenland, has a total of 1,419 islands above ; 443 of which have been named and of which 78 are inhabited. Spanning a total area of , metropo
    中文释义：列出443个已命名岛屿，其中78个有人居住。。
  - `is/Q591.json`，`article[1]`：Danmörk samanstendur af Jótlandsskaga og 443 eyjum en af þeim eru 72 (2007) byggðar. Landið liggur að sjó að vestan, norðan og austan. Að vestan er No
    中文释义：称有443个岛屿，其中72个(2007)有人居住。。

## Depsang Plains（英文锚点 19178639）

语言：en, hi, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：印地语以中国占领东部、印度控制西部表述，中文以解放军占领后当前中印分控叙述；控制格局相近但措辞与历史重点不同。（置信标记：medium）
  - `hi/Q526007.json`，`article[0]`：चीन ने पूर्वी भाग पर क़ब्ज़ा किया हुआ है
    中文释义：中国占据东部。。
  - `zhs/Q7093266.json`，`article[0]`：目前印度控制着达普桑盆地西部的一部分
    中文释义：目前印度控制西部一部分。。
  - `en/Q19178639.json`，`article[6]`：have been divided between the two countries across a Line of Actual Control
    中文释义：两国沿实际控制线分隔。。

## Djibouti（英文锚点 17207794）

语言：en, so, ti；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：英语与索马里语首段采用不同层级的邻接地名（索马里/索马里兰），可能影响政治实体显著性；这不单独证明对索马里兰主权的相反判定。提格里尼亚语归档为空。（置信标记：medium_preliminary）
  - `en/Q17207794.json`，`article[0]`：bordered by Somalia to the south, Ethiopia to the southwest, Eritrea in the north, and the Red Sea and the Gulf of Aden to the east. Th
    中文释义：南邻写作Somalia。。
  - `so/Q2107.json`，`article[0]`：Somaliland oo ka xigta koonfurbari. Dhinaca kale Jabuuti waxaa ka xiga Bada cas iyo Gacanka Cadmeed.
    中文释义：东南邻写作Somaliland。。

## Doi Pha Hom Pok National Park（英文锚点 34521762）

语言：en, th；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：泰语首段保留山高2285米、524平方公里和2000年建园等数值；英文首段相关高度/面积字段有清洗空缺，但第二段补充鸟类观察。数值缺失应视作数据质量/表达互补，不是立场偏差。（置信标记：medium）
  - `th/Q794393.json`，`article[0]`：ความสูง 2,285 เมตร
    中文释义：高度2285米。
  - `en/Q34521762.json`，`article[0]`：The park was established on September 4, 2000.
    中文释义：公园建于2000年9月4日。。

## Doklam（英文锚点 54473004）

语言：en, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：英文明示不丹位置并附中国声索，中文以中国行政区定位并用“越界”定性印军行动；这是明确的归属/行动合法性框架差异，不能将简繁视为两份独立支持证据。（置信标记：high）
  - `en/Q54473004.json`，`article[0]`：an area in Bhutan
    中文释义：不丹的一片地区。
  - `en/Q54473004.json`，`article[0]`：but it is also claimed by China
    中文释义：中国也对其提出声索。
  - `zhs/Q5736695.json`，`article[0]`：位于中国西藏日喀则市亚东县下亚东乡南端
    中文释义：位于中国西藏亚东县下亚东乡南端。
  - `zhs/Q5736695.json`，`article[0]`：印度军队越界阻止中国在这一地区修路
    中文释义：印度军队越界阻止中国修路。

## Donetsk Oblast（英文锚点 494889）

语言：en, ru, uk；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：三种语言首段并不显示相反法理归属；英文所阅段落提供战争/控制历史补充。未检索到的乌文战争段落不能据摘要判为不存在。（置信标记：medium_preliminary）
  - `en/Q494889.json`，`article[2]`：In 2014, parts of the oblast, including Donetsk, came under the control of Russian-backed separatists who declared the Donetsk People's Republic, leading to a war against government forces; the de facto administrative center was subsequently moved to Mariupol and then Kramatorsk. During the 2022 Russian invasion of Ukraine, the oblast again became the site of heavy fighting, and Russia later declared the annexation of the entirety of the oblast a
    中文释义：详细记录2014年分离主义控制及2022年战事与俄罗斯宣布吞并。。
  - `ru/Q22454.json`，`article[0]`：Доне́цкая о́бласть (), или Доне́тчина () — административно-территориальная единица Украины, расположенная на юго-востоке страны, в Донбассе.
    中文释义：首段明确称为乌克兰行政区。。
  - `uk/Q3177.json`，`article[0]`：Доне́цька о́бласть (Донеччина) — адміністративно-територіальна одиниця першого рівня на сході України.
    中文释义：首段称为乌克兰东部一级行政区。。

## Doumeira Islands（英文锚点 33892215）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Dragonja（英文锚点 16461043）

语言：en, hr, sl；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：克罗地亚语称河长28公里，斯洛文尼亚语称30公里；可能涉及测量口径，列为数值差异候选，不等同领土立场。（置信标记：high）
  - `hr/Q186182.json`，`article[0]`：Duga je 28 km
    中文释义：长28公里。。
  - `sl/Q104298.json`，`article[0]`：dolga je 30 km
    中文释义：长30公里。。

## Drina river（英文锚点 5021206）

语言：bs, en, sr；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：波斯尼亚语与塞尔维亚语均说明由Tara和Piva汇合、长约346公里；塞语补充支流和历史边界叙述。英文归档没有可用正文，因此不能把英文缺失解释为有意省略。（置信标记：medium）
  - `bs/Q7548.json`，`article[1]`：Nastaje spajanjem crnogorskih rijeka Tare i Pive u Šćepan Polju. Od rijeka koje protiču Bosnom i Hercegovinom jedino je rijeka Sava duža od Drine. Ujedno je i najduža pritoka Save. Svojim tokom dužine od oko 346 kilometara prolazi kroz mnogobrojna mjesta u Bosni i Hercegovini. U donjem Podrinju (Semberiji) Drina jednim dijelom čini granicu između Bosne i Her
    中文释义：由Tara和Piva汇合，约346公里。。
  - `sr/Q1995510.json`，`article[0]`：Река Дрина (346 -{km}-) припада Црноморском сливу, а настаје спајањем река Таре и Пиве код Шћепан Поља (надморска висина 470 -{m}-). Сливно подручје обухвата југозападни и западни део Србије, северни део Црне Горе и источни део Босне и Херц
    中文释义：德里纳河346公里，在Šćepan Polje由Tara和Piva汇合。。

## East Jerusalem（英文锚点 343508）

语言：ar, en, iw；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：阿语首段把1967年事件称为以色列占领；希伯来语首段从耶路撒冷市界及1967年并入以色列的行政法律框架叙述。英文引入国际法上的巴勒斯坦领土地位。属于法律/行政框架和措辞差别，非作者动机或主权真值裁定。（置信标记：high）
  - `ar/Q5232674.json`，`article[0]`：وحتى الاحتلال الإسرائيلي للمدينة عام 1967
    中文释义：直至1967年以色列对城市的占领。
  - `iw/Q122078.json`，`article[0]`：אזור מזרח ירושלים סופח לישראל בעקבות מלחמת ששת הימים
    中文释义：东耶路撒冷地区在六日战争后被并入以色列。
  - `en/Q343508.json`，`article[0]`：Under international law, East Jerusalem is  considered a part of the West Bank
    中文释义：根据国际法，东耶路撒冷被视为西岸的一部分。

## Egypt（英文锚点 8087628）

语言：ar, en；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：阿语104百万人与英语约100百万人及人口排名不同；需匹配统计年份/修订时间，暂不认定矛盾或偏见。（置信标记：medium）
  - `ar/Q400490.json`，`article[0]`：مِصرُ (رسميًّا: جُمْهُورِيّةُ مِصْرَ العَرَبيّةِ) هي دولة عربية عابرة للقارات تمتد على الركن الشمالي الشرقي لأفريقيا والركن الجنوبي الغربي من آسيا عبر جسر بري شكلته شبه جزيرة سيناء
    中文释义：。
  - `en/Q8087628.json`，`article[0]`：Egypt (  , ), officially the Arab Republic of Egypt, is a transcontinental country spanning the northeast corner of Africa and southwest corner of Asia via a land bridge formed by 
    中文释义：。

## El Salvador（英文锚点 9356）

语言：en, es；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：英语人口为2023年约650万，西语为2021年6486023，年份已明确不同，是时间互补而非冲突；不应标为立场差异。（置信标记：medium）
  - `en/Q9356.json`，`article[0]`：The country's population in 2023 was estimated to be 6.5 million.
    中文释义：2023年人口估计650万。。
  - `es/Q1149.json`，`article[0]`：En el año 2021 contaba con una población estimada en 6486023 habitantes
    中文释义：2021年人口估计6486023。。

## Equatorial Guinea（英文锚点 9366）

语言：en, es, fr；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：西语导语通过宪法自我定义列民主国家；英语和法语所审段落强调威权与人权。宪法定义与实际治理评价不是同一命题的直接矛盾，但叙述框架不同。（置信标记：high）
  - `es/Q10643.json`，`article[0]`：se define en su constitución como Estado independiente, republicano, unitario, social y democrático
    中文释义：在宪法中定义为独立、共和、单一、社会和民主国家。。
  - `en/Q9366.json`，`article[4]`：Equatorial Guinea's government is authoritarian
    中文释义：赤道几内亚政府为威权政府。。
  - `fr/Q1323.json`，`article[1]`：continue à connaître de graves violations des droits de l'homme.
    中文释义：继续存在严重人权侵犯。。

## Eritrea（英文锚点 17238590）

语言：en, so, ti；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：1991与1993可能分别指实际脱离与正式独立，需核对各自事件；不直接将时间差别判定为事实冲突。（置信标记：medium_preliminary）
  - `so/Q2407.json`，`article[1]`：1991, dalka Eratariya waxa hada waxaa ka taliya madaxweyne Isaias Afewerki.
    中文释义：索马里语提到1991年脱离。。
  - `ti/Q1476.json`，`article[0]`：ብ1993 ካብ ኢትዮጵያ ናጻ ኮይና። ርእሰ ከተማኣን ዝበዝሐ ህዝቢ ዘለዋ ከተማኣን ኣስመራ እያ።
    中文释义：提格里尼亚语提到1993年独立。。

## Erkeshtam（英文锚点 16180244）

语言：en, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英中均说明是中吉口岸、名称来自吉方村庄；中文第二段补充跨山地形与贸易道路。未观察到控制权叙述冲突。（置信标记：medium）
  - `en/Q16180244.json`，`article[0]`：named after a village on the Kyrgyz side of the border
    中文释义：以吉尔吉斯一侧的村庄命名。
  - `zhs/Q7933680.json`，`article[1]`：亚洲公路65号线
    中文释义：亚洲公路65号线。

## Essequibo River（英文锚点 541348）

语言：en, es；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：英西都描述委内瑞拉主张与圭亚那实际管理；西语使用“占据”且以法理/事实对照展开，体现措辞框架，不能等于国家编辑者一致支持某方。（置信标记：high）
  - `en/Q541348.json`，`article[1]`：The river is administered by Guyana
    中文释义：河流由圭亚那管理。
  - `es/Q226179.json`，`article[1]`：administrado y ocupado
    中文释义：被管理和占据。

## Eswatini（英文锚点 27451）

语言：en；类型：country；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Europa Island（英文锚点 9407）

语言：en, fr, mg；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：英语写1897年正式成为法国属地，法语写自1896年起属于法国；需要核对占有、宣布、行政归属是否指不同事件，不先判为真伪冲突。马语明示马达加斯加声索，法语也承认该声索，不能据摘录认定两语完全相反。（置信标记：medium）
  - `en/Q9407.json`，`article[0]`：The island officially became a possession of France in 1897.
    中文释义：该岛于1897年正式成为法国属地。。
  - `fr/Q179234.json`，`article[1]`：Ce territoire, français depuis 1896, fait partie avec l'île Juan de Nova, l'atoll Bassas da India, l'île Tromelin et les îles Glorieuses de l'ensemble appelé îles Éparses de l'océan Indien, incorporé depuis la loi ordinaire du  aux Terres australes et antarctiques françaises. L'île Europa est cependant revendiquée par Madagascar.
    中文释义：法国自1896年起的领土，但由马达加斯加声索。。
  - `mg/Q281548.json`，`article[0]`：Ny Nosy Europa na Nosy Ampela dia nosy kely aty amin' ny Ranomasimbe Indianina, latsaky ny 30 km2 ny velarantany, any amin' ny tapany atsimon' ny Lakandranon' i Môzambika. Isan' ireo Nosy Miparitaka izy. Ny Nosy Europa anefa dia takian' i Madagasikara. Isan'ny toerana lehibe maneran-tany fiterahan' ny sokatra maitso ny Nosy Euro
    中文释义：马达加斯加声索Europa/Nosy Ampela，并介绍生态和生存条件。。

## Falkland Islands（英文锚点 7550182）

语言：en, es；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：英文内部自治与西文联合国非自治领土类别属于不同制度维度；有法政框架侧重差异，不是可直接归并为相反事实。（置信标记：medium_preliminary）
  - `en/Q7550182.json`，`article[0]`：internal self-governance, but the United Kingdom takes responsibility for their defence and foreign affairs. The capital and largest settlement is Stanley on East Falkland.
    中文释义：英国海外领土并有内部自治。。
  - `es/Q3929221.json`，`article[0]`：territorio dependiente y no autónomo, bajo administración del Reino Unido, que abarca la totalidad del archipiélago de las Malvinas, situado en el océano Atlántico sudoccidental, e
    中文释义：称为依附、非自治领土。。
  - `es/Q3929221.json`，`article[2]`：Es uno de los 17 territorios en la lista de las Naciones Unidas de territorios no autónomos bajo supervisión del Comité de Descolonización de las Naciones Unidas, con el fin de examinar la situación con respecto a la aplicación de la Declaración sobr
    中文释义：说明列入联合国非自治领土名单。。

## Fasht Dibal conflict（英文锚点 70391330）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Fergana Valley（英文锚点 334903）

语言：en, ky, tg, uz；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英文概述民族多样性和近现代冲突，乌兹别克语列举矿产；吉尔吉斯语补充谷地尺寸。三者均涉及乌、吉、塔三国，不能归成相互排他的领土主张。（置信标记：medium）
  - `en/Q334903.json`，`article[1]`：the valley is ethnically diverse and in the early 21st century was the scene of conflict
    中文释义：该谷地族群多样，21世纪初发生冲突。
  - `uz/Q20944.json`，`article[1]`：neft, kumir, tabiiy gaz
    中文释义：石油、煤、天然气。

- **摘录未见明确差异**：英语先说主要位于乌兹别克斯坦并延伸到吉尔吉斯斯坦和塔吉克斯坦；塔吉克语说分属这三个国家。范围精度不同但相容，未发现直接相反归属。（置信标记：medium）
  - `en/Q334903.json`，`article[0]`：lies mainly in eastern Uzbekistan, but also extends into southern Kyrgyzstan and northern Tajikistan
    中文释义：主要在乌兹别克斯坦东部，也延伸到吉尔吉斯斯坦南部及塔吉克斯坦北部。
  - `tg/Q34428.json`，`article[0]`：байни се давлати имрӯза тақсим шудааст: Ӯзбекистон, Тоҷикистон ва Қирғизистон
    中文释义：分属现今三个国家：乌兹别克斯坦、塔吉克斯坦和吉尔吉斯斯坦。

## Fiji（英文锚点 10707）

语言：en, to；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：汤加语提供2018年人口与Suva/Viti Levu等本地名称，英语摘录详细讲群岛及地质；属于摘录信息互补，汤加语材料很短，不作立场判断。（置信标记：medium）
  - `en/Q10707.json`，`article[0]`：an island country in Melanesia
    中文释义：美拉尼西亚的岛国。
  - `to/Q1603.json`，`article[1]`：Hono tokolahi ʻi he taʻu 2018: 912 241.
    中文释义：2018年人口：912241。

## France（英文锚点 5843419）

语言：ar, en, fr, it, mg, nl；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：人口数字及年份不同：马达加斯加语明确2009年65.1百万，荷兰语明确2020年67.06百万。这是年份条件不同的统计信息，不构成已证实事实冲突。（置信标记：high）
  - `mg/Q619.json`，`article[0]`：65,1 tapitrisa tamin' ny 1 Janoary 2009.
    中文释义：2009年1月1日为6510万人。。
  - `nl/Q1315598.json`，`article[1]`：67,06 miljoen inwoners (januari 2020)
    中文释义：2020年1月约6706万人。。

## French Guiana（英文锚点 21350970）

语言：en, fr, nl；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：法语补充2015起单一领土集体的制度安排；荷语导语补充与苏里南的争议区域。行政层级与边界背景是互补信息。（置信标记：medium）
  - `fr/Q6764.json`，`article[0]`：La Guyane (  ; en créole guyanais : Lagwiyann), est une collectivité territoriale unique française située en Amérique du Sud, limitrophe du Brésil au sud-est et au sud, et du Surin
    中文释义：。
  - `nl/Q488.json`，`article[0]`：Frans-Guyana (Frans: Guyane) is een Frans overzees departement aan de noordkust van Zuid-Amerika. Het is het grootste gebied van de Europese Unie buiten Europa. Het grenst in het w
    中文释义：。

## Gabon（英文锚点 12027）

语言：en, es, fr；类型：country；状态：excerpt_screened_no_clear_difference。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Gaza Strip（英文锚点 12047）

语言：ar, en, iw；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：所阅导语分别突出占领法律框架、内部实际治理和1948年地理历史；这些命题可以共存，不能把不同侧重直接视为互斥归属。（置信标记：medium_preliminary）
  - `en/Q12047.json`，`article[0]`：Israeli military occupation since 1967.
    中文释义：突出自1967年以来以色列军事占领。。
  - `iw/Q2543.json`，`article[0]`：מבחינת ריבונות היא מזוהה עם הרשות הפלסטינית, ומאז 2007 היא בשליטת החמאס. נכון ליולי 2021 מוערכת אוכלוסיית רצועת עזה על ידי ה-CIA ב-1,957,062 תושבים, על פי 
    中文释义：区分巴勒斯坦权力机构的主权关联与2007年以来哈马斯控制。。
  - `ar/Q2269.json`，`article[0]`：قطاع غزّة هو المنطقة الجنوبية من السهل الساحلي الفلسطيني على البحر المتوسط؛ على شكل شريط ضيّق شمال شرق شبه جزيرة سيناء، وهي إحدى منطقتين معزولتين (الأخرى هي الضفة الغربية) داخل حدود فلسطين الإنتدابية لم تسيطر عليها القوات الصهيونية في حرب 1948، ولم تصبح ضمن حد
    中文释义：突出巴勒斯坦沿海平原及1948年历史。。

## Gegharkunik Province（英文锚点 470502）

语言：az, en, hy；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：阿塞拜疆语首段使用“西阿塞拜疆”地理政治称呼；英/亚美尼亚语以亚美尼亚省份定义。明确可观察到命名及地域框架差异，但并不据此给整种语言标记偏见。（置信标记：high）
  - `az/Q216993.json`，`article[0]`：Qərbi Azərbaycannda Göyçə gölünü hər tərəfdən əhatə edən bir vilayətdir
    中文释义：在“西阿塞拜疆”环绕Göyçə湖的省份。
  - `en/Q470502.json`，`article[0]`：is a province (marz) of Armenia.
    中文释义：是亚美尼亚的一个省。。

## Georgia (country)（英文锚点 48768）

语言：az, en, ka；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：地理上两者均置于欧亚交界；格鲁吉亚语另外明示社会政治和文化上属于欧洲，表现身份叙述侧重，非已证实的事实冲突。（置信标记：medium）
  - `en/Q48768.json`，`article[0]`：at the intersection of Eastern Europe and Western Asia
    中文释义：位于东欧与西亚交汇处。
  - `ka/Q823.json`，`article[0]`：თუმცა სოციოპოლიტიკურად და კულტურულად ევროპის ნაწილია.
    中文释义：但在社会政治和文化上是欧洲的一部分。

## Gibraltar（英文锚点 7607314）

语言：en, es；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：两语均承认英国海外领土和西班牙声索；英语导语/后续强调永久割让及居民公投，西语导语强调联合国非自治领土身份，后续按西班牙解释讨论非法占领地峡。是法律身份和论据的侧重/归因差异，不能把“海外领土”与“非自治领土”当作互斥事实。（置信标记：high）
  - `en/Q7607314.json`，`article[2]`：The sovereignty of Gibraltar is a point of contention in Anglo-Spanish relations, as Spain asserts a claim to the territory. Gibraltarians overwhelmingly rejected proposals for Spanish sovereignty in a 1967 referendum, and for shared sovereignty in a 2002 referendum. Nevertheless, Gibraltar maintains close economic and cultural links with Spain, with many Gi
    中文释义：介绍西班牙声索及居民1967/2002年拒绝相关主权提案。。
  - `es/Q7643.json`，`article[0]`：Gibraltar (en inglés: Gibraltar, ) es un territorio británico de ultramar situado en una pequeña península del extremo sur de la península ibérica y hace frontera terrestre con España, país que reclama su soberanía. Para la Organización de las Naciones Unidas, Gibraltar, como colonia, es uno de los territorios no autónomos bajo supervisión de su Comité Especial de Descolonización, al igual que otros dieciséis casos más.
    中文释义：介绍英国海外领土、西班牙声索与联合国非自治领土地位。。
  - `es/Q7643.json`，`article[1]`：Atendiendo al artículo  del Tratado de Utrecht, «la ciudad y castillos de Gibraltar, juntamente con su puerto, defensas y fortalezas» en 1713 serían una propiedad a perpetuidad de la Corona británica en territorio de jurisdicción española, debiendo ser ofrecido a España en primer lugar si el Reino Unido renunciase, vendiera o enajenase de alguna manera dicha propiedad. El istmo entre el peñón y las otras fortificaciones españolas es para España territorio ocupado ilegalmente, atendiendo a su int
    中文释义：按西班牙解释讨论地峡非法占领，需保留归因。。

## Gilgit-Baltistan（英文锚点 18807336）

语言：en, hi, ur, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：印地语导语采用印度领土框架，英语/乌尔都语突出巴方管理与争议；这是归属框架差异，应区分法理声索和事实控制。（置信标记：medium_preliminary）
  - `hi/Q190627.json`，`article[0]`：यह भारत की उत्तरतम राजनैतिक इकाई है। गिलगित-बल्तिस्तान कश्मीर का हिस्सा है। इसकी सीमायें पश्चिम में खैबर-पख़्तूनख्वा से, उत्तर में अफ़ग़ानिस्तान के वख
    中文释义：使用印度最北政治单位的表述。。
  - `en/Q18807336.json`，`article[0]`：administered by Pakistan as an administrative territory  and constituting the northern portion of the larger Kashmir region which has been the subject of a dispute between India and Pakistan since 1947, and between India and China since som
    中文释义：以巴基斯坦管理及更大克什米尔争议来描述。。
  - `ur/Q43807.json`，`article[0]`：گلگت بلتستان (انگریزی: Gilgit Baltistan بلتی زبان: རྒྱལ་སྐྱིད་ སྦལྟི་ཡུལ།) پاکستان کے زیر انتظام علاقہ ہے جو متنازعہ ریاست جموں و کشمیر کا حصہ ہے۔ 1840ء سے پہلے یہ علاقے مختلف ریاستوں میں بٹا ہوا تھا جن میں بلتستان، گلگت
    中文释义：称为巴基斯坦管理且属有争议的查谟和克什米尔。。

## Glorioso Islands（英文锚点 12087）

语言：ar, en, fr, mg；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英/阿首段同时说明法国控制及科摩罗、马达加斯加声索，法/马语摘录补充马达加斯加1973年提出声索，属于时间与背景互补。（置信标记：medium）
  - `en/Q12087.json`，`article[0]`：but are also claimed by Comoros, Madagascar and formerly by Seychelles
    中文释义：也被科摩罗、马达加斯加及过去的塞舌尔声索。
  - `fr/Q444673.json`，`article[1]`：a été émise  par ce pays en 1973.
    中文释义：该国于1973年提出声索。。

- **数字／时间候选差异**：阿语总面积5平方公里、马达加斯加语7平方公里，可能涉及陆地/礁盘范围或资料版本，须核查，不能自动归因立场。（置信标记：medium）
  - `ar/Q8850403.json`，`article[0]`：تبلغ مساحتها الإجمالية 5 كيلومترات مربعة
    中文释义：总面积5平方公里。
  - `mg/Q281540.json`，`article[0]`：Mirefy 7 km2 ilay vondronosy.
    中文释义：该群岛面积7平方公里。。

## Golan Heights（英文锚点 7515865）

语言：ar, en, iw；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：阿语导语优先断言属于叙利亚并谈联合国认定的占领，英语先区分地质/地缘政治定义；应进一步比较英语完整政治段落，不能据导语顺序认定英语否认占领。（置信标记：medium）
  - `ar/Q3410.json`，`article[0]`：الجولان هي هضبة تقع في بلاد الشام بين نهر اليرموك من الجنوب وجبل الشيخ من الشمال، تابعة إداريًا لمحافظة القنيطرة (كلياً في ما مضى وجزئيًا في الوقت الحاضر)، وهي جزء من سوريا وتتبع ل
    中文释义：。
  - `en/Q7515865.json`，`article[0]`：The Golan Heights ( or ; ), or simply the Golan, is a region in the Levant spanning about . The region defined as the Golan Heights differs between disciplines: as a geological and
    中文释义：。

- **措辞／归因／命名差异**：英语以黎凡特地区及不同学科的地域范围开头；希伯来语首句直接定位在以色列东北部。此为地域归属框架差异，不能由此断言哪种主权解释正确。（置信标记：high）
  - `en/Q7515865.json`，`article[0]`：is a region in the Levant
    中文释义：是黎凡特的一片地区。
  - `iw/Q11803.json`，`article[0]`：הוא אזור בצפון-מזרח מדינת ישראל
    中文释义：是以色列国东北部的地区。

## Greater and Lesser Tunbs（英文锚点 931816）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Greece（英文锚点 12108）

语言：el, en, tr；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：希腊语导语补充2021年人口，土耳其语给2022估计；英土均叙述民主和西方文明渊源。人口并非同年数值，所审片段没有明确立场冲突。（置信标记：medium）
  - `el/Q145806.json`，`article[0]`：Σύμφωνα με την απογραφή του 2021
    中文释义：根据2021年人口普查。。
  - `tr/Q4289.json`，`article[0]`：Nüfusu 2022 itibarıyla yaklaşık 10,3 milyon
    中文释义：2022年人口约1030万。。

## Green Line (Israel)（英文锚点 2420091）

语言：ar, en, iw；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：阿语直接称绿线分隔1948年与1967年被占领土地；英/希伯来语以1949年停战分界线定义，并使用1948战争/独立战争等不同命名。是可见用词及历史命名框架差异，双方同时提及停战线并非永久国界，不能从单段裁定作者或全语言社群立场。（置信标记：high）
  - `ar/Q1040157.json`，`article[0]`：الخط الأخضر بفلسطين، هو لفظ يطلق على الخط الفاصل بين الأراضي المحتلة عام 1948 والأراضي المحتلة عام 1967. وقد حددته الأمم المتحدة بعد هدنة عام 1949 التي أعقبت الحرب بعد الحرب ا
    中文释义：绿线分隔1948年被占领土地与1967年被占领土地。。
  - `en/Q2420091.json`，`article[0]`：The Green Line, (pre-)1967 border, or 1949 Armistice border, is the demarcation line set out in the 1949 Armistice Agreements between the armies of Israel and those of its neighbors (Egypt, Jordan, Lebanon and Syria) after the 1948 Arab–Israeli War. It served as the de facto borders of the State of 
    中文释义：绿线是1949年停战协定确定的分界线。。
  - `iw/Q6767.json`，`article[0]`：הקו הירוק הוא קו שביתת-הנשק של מדינת ישראל עם מצרים, עם ירדן, עם סוריה ועם לבנון, כפי שנקבע בהסכמי שביתת הנשק שנחתמו בשנת 1949, לאחר מלחמת העצמאות ועד מלחמת ששת הימים בשנת 1967. שמו ניתן לו מכך שבמפות המודפסות שלפני מלחמת ששת הימים, הוא סומן בצבע ירו
    中文释义：绿线为以色列与周边国家的停战线，独立战争后至1967年。。

## Guatemala（英文锚点 17238567）

语言：en, es；类型：country；状态：excerpt_screened_no_clear_difference。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Gue（英文锚点 16964915）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Guinea（英文锚点 12176）

语言：en, fr；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：国家导语分别突出政治历史与自然资源，是内容侧重互补；不足以据此判定政治偏向。（置信标记：medium_preliminary）
  - `en/Q12176.json`，`article[1]`：Formerly French Guinea, it achieved independence in 1958. Guinea has a history of military coups d'état. After decades of authoritarian rule, in 2010 it held its first democratic election. As it continued to hold multi-p
    中文释义：强调1958年独立和政变/民主选举历史。。
  - `fr/Q1321.json`，`article[0]`：Riche en ressources naturelles, elle est surnommée le château d'eau de l'Afrique de l'Ouest et possède le tiers des réserves mondiales de bauxite, ce qui lui vaut d’être régulièrement associée à des . Elle prend son indépendance d
    中文释义：强调自然资源、水塔及铝土矿储量。。

## Guyana（英文锚点 17238691）

语言：en, es, nl；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：荷语首段概述与苏里南及委内瑞拉争议，西语补充两项声索的面积和占比；英文首段侧重国家地理。是争议细节量的互补，不证明英文全文回避争议。（置信标记：medium）
  - `nl/Q24944.json`，`article[0]`：Guyana heeft grensgeschillen met Suriname en met Venezuela.
    中文释义：圭亚那与苏里南、委内瑞拉有边界争议。。
  - `es/Q10645.json`，`article[1]`：lo que representa el 74,21% del territorio
    中文释义：占领土的74.21%。

## Guyana–Venezuela territorial dispute（英文锚点 6896458）

语言：en, es；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：两语均承认圭亚那实际管理、委内瑞拉声索；西语额外明确排除委内瑞拉控制的Anacoco岛，英语摘录补充1966日内瓦协定与2020国际法院受理。为边界例外和法律程序互补。（置信标记：high）
  - `en/Q6896458.json`，`article[0]`：(), sometimes also called  or Essequibo, is a disputed territory of  west of the Essequibo River that is administered and controlled by Guyana but claimed by Venezuela. The boundary dispute was inherited from the colonial powers (Spain in the case of Venezuela
    中文释义：由圭亚那管理控制、委内瑞拉声索。。
  - `es/Q10784734.json`，`article[0]`：El disputa territorial de la Guayana Esequiba es una disputa territorial en curso entre Guyana y Venezuela por el área de 159 500 km² (61 583 mi²) al oeste del río Esequibo. El territorio, excluida la isla de Anacoco controlada por Venezuela, está controlado por Guyana como parte de seis de sus regiones, según el Laudo Arbitral de París de 1899, pero es reclamado por Venezuela.
    中文释义：除委内瑞拉控制的Anacoco岛外由圭亚那控制，委内瑞拉声索。。
  - `en/Q6896458.json`，`article[1]`：The status of the territory is subject to the Geneva Agreement, which was signed by the United Kingdom, Venezuela and British Guiana on 17 February 1966. This treaty stipulates that the parties will agree to find a practical, peaceful and satisfactory solution to the dispute. On 18 December 2020, the International Court of Justice accepted the case submitted by Guyana to settle the dispute.
    中文释义：1966年日内瓦协定及2020年国际法院受理。。

## Haa District（英文锚点 477204）

语言：dz, en, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：英语正文面积1905平方公里，与中文导语1585平方公里不一致；应核查行政边界和统计年份，不能据此推断政治立场。（置信标记：high）
  - `en/Q477204.json`，`article[13]`：Haa Dzongkhag covers a total area of 1905 sq km.
    中文释义：哈阿宗总面积1905平方公里。。
  - `zhs/Q742126.json`，`article[0]`：面积达1,585km2
    中文释义：面积1585平方公里。。

- **摘录未见明确差异**：两个摘录都将Haa视为不丹20个宗/地区之一。宗喀语并列地方行政名称，英文另述语言；未识别明确立场冲突，但不是宗喀语全文专家审校。（置信标记：medium）
  - `en/Q477204.json`，`article[0]`：one of the 20 dzongkhag or districts comprising Bhutan
    中文释义：构成不丹的20个宗/地区之一。
  - `dz/Q2248.json`，`article[0]`：འབྲུག་རྒྱལ་ཁབ་འདི་ནང་རྫོང་ཁག་ 20
    中文释义：不丹王国的20个宗/地区。

## Hainan（英文锚点 166411）

语言：en, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：中文细分无争议本岛和存在争议的离岛、法定管辖与实控；英语概述三个群岛及设省经过。两者提供不同粒度，涉及海洋/陆地面积口径需分开。（置信标记：medium）
  - `zhs/Q421.json`，`article[1]`：海南省在地理上可分为海南本岛和南海诸岛（海南离岛），其中本岛位于海南省的西北部，大致等于海南岛及其领海附属岛屿，与周边国家没有领土争议；离岛位于海南省中北部至南部，大致等于三沙市法定管辖的中沙群岛、西沙群岛和南沙群岛，与周边国家尚存领土争议，中华人民共和国实际控制西沙和中沙全部岛礁，而没有实际控制南沙部分岛礁。
    中文释义：。
  - `en/Q166411.json`，`article[1]`：The province has a land area of , of which Hainan Island is  and the rest is over 200 islands scattered across three archipelagos: Zhongsha, Xisha and Nansha. It was part of Guangd
    中文释义：。

## Haiti（英文锚点 13373）

语言：en, ht；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英语导语加入纳瓦萨岛争议，海地克里奥尔语所审历史段重点为反奴隶制独立和1825年赔款。是取样段落主题互补，不证明全文存在有意遗漏。（置信标记：medium）
  - `en/Q13373.json`，`article[0]`：Navassa Island, which is claimed by Haiti
    中文释义：海地主张纳瓦萨岛。。
  - `ht/Q13.json`，`article[1]`：Se premye peyi nwa ki rache libète li poukont li anba men lame fransèz.
    中文释义：是第一个依靠自身从法国军队手中争得自由的黑人国家。。

## Halaib Triangle（英文锚点 1256880）

语言：ar, en；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：阿文的事实管理与英文的历史边界解释可以互补，不能因首段选择不同而判为相反立场。（置信标记：medium_preliminary）
  - `ar/Q181841.json`，`article[0]`：بحكم الأمر الواقع. وهي محل نزاع حدودي بين مصر والسودان، ويطلق عليها الجانب السوداني المنطقة الإدراية لحكومة دو
    中文释义：明确埃及事实政治和行政管理及埃苏争议。。
  - `en/Q1256880.json`，`article[0]`：1899 by the Anglo-Egyptian Condominium, which runs along the 22nd parallel north, and the "administrative boundary" set by the British in 1902, which gave administrative responsibility for an area of land north of the li
    中文释义：补充1899政治边界与1902行政边界差别。。

## Hatay Province（英文锚点 403424）

语言：ar, en, tr；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：英语把叙利亚的异议归因给叙利亚；阿拉伯语直接评价1939年公投可信度，属于归因及评价措辞差异。不是对历史正确性的外部裁决。（置信标记：high）
  - `en/Q403424.json`，`article[0]`：Sovereignty over most of the province remains disputed with neighbouring Syria
    中文释义：该省大部分地区的主权仍与邻国叙利亚存在争议。
  - `ar/Q168200.json`，`article[1]`：استفتاء مشكوك في صحته
    中文释义：可信度受到质疑的公投。

## Heglig（英文锚点 6796525）

语言：ar, en；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：阿语首段直接称为苏丹城市；英文区分苏丹管理、苏丹和南苏丹双方声索。是首段归属/争议显著性差异，不等于阿语全文否认南苏丹声索。（置信标记：medium）
  - `ar/Q1275055.json`，`article[0]`：مدينة هجليج  هي مدينة سودانية
    中文释义：Heglig是一座苏丹城市。
  - `en/Q6796525.json`，`article[0]`：The entirety of Heglig is claimed by both Sudan and South Sudan, but administered by Sudan.
    中文释义：整个Heglig被苏丹和南苏丹声索，但由苏丹管理。。

## History of Bhutan（英文锚点 42389）

语言：en, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：英文概括从未被外部征服/占领/统治，中文称早期为迦摩缕波领土并成为西藏政权边陲。存在历史范围/早期传说与有记录时代差异，需同年代及来源核验，暂不作确定冲突裁定。（置信标记：medium）
  - `en/Q42389.json`，`article[1]`：Bhutan is one of the few countries which has been independent throughout its history, never conquered, occupied, or governed by an outside power (notwithstanding occasional nominal
    中文释义：。
  - `zhs/Q1300125.json`，`article[0]`：6世纪中叶以前，不丹是印度迦摩缕波王国（Kamarupa）的领地，生活著土著库奇人。650年，由于迦摩缕波王国政治动荡，吐蕃王国的藏人迁入不丹地区，驱逐了库奇人，使不丹脱离了印度人的统治，成为西藏政权的边陲。“不丹”这个名字就义为吐蕃（Bhota）的边陲（anta）。
    中文释义：。

## Honduras（英文锚点 13394）

语言：en, es；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英语笼统以Tegucigalpa为首都，西语明确Tegucigalpa与Comayagüela共同构成首都。是行政单位精细程度互补，不能直接判为事实互斥。（置信标记：medium）
  - `en/Q13394.json`，`article[0]`：Its capital and largest city is Tegucigalpa.
    中文释义：首都和最大城市为Tegucigalpa。。
  - `es/Q5600.json`，`article[0]`：Tegucigalpa, junto con Comayagüela, constituyen la capital del país
    中文释义：Tegucigalpa与Comayagüela共同构成首都。。

## Hong Kong（英文锚点 13404）

语言：en, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英中均认定香港为中国特别行政区。英语历史段按割让和租借展开，中文给当前人口和自由港功能；这些是所审段落的侧重互补。（置信标记：high）
  - `en/Q13404.json`，`article[0]`：a city and special administrative region of China
    中文释义：中国的城市和特别行政区。。
  - `zhs/Q247430.json`，`article[0]`：是中华人民共和国的一个特别行政区
    中文释义：中文同样列为中华人民共和国特别行政区。。

## Iceland（英文锚点 14531）

语言：da, en, is；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：人口数字不同且时间标注不同，属于需核对年份和数据源的数值候选，不是主权观点冲突。（置信标记：medium_preliminary）
  - `da/Q5843.json`，`article[0]`：364.260 indbyggere og et areal på 103.000 km², hvoraf landarealet udgør 100.250 km², hvilket gør det
    中文释义：丹麦语首段人口364,260。。
  - `is/Q65242.json`，`article[0]`：391.000 manns (mars 2023). 
    中文释义：冰岛语首段人口约391,000并标2023年3月。。

## Ilemi Triangle（英文锚点 4042526）

语言：en, sw；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：斯瓦希里语保留10320至14000平方公里范围，英文补充1950年巡逻线、1914年条约及埃塞俄比亚未正式提出声索。两者均说明肯尼亚现实际控制，不构成对立。（置信标记：medium）
  - `sw/Q114462.json`，`article[0]`：Kwa sasa inatawaliwa na Kenya.
    中文释义：目前由肯尼亚管理。。
  - `en/Q4042526.json`，`article[1]`：all territory up to the northern 1950 Sudanese Patrol Line
    中文释义：直至北侧1950年苏丹巡逻线的全部地域。

## Ilha de Guajará-mirim（英文锚点 12806952）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Imia（英文锚点 22734752）

语言：el, en；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：英语介绍岛屿并分别归因希腊、土耳其的争议；希腊语首句直接称希腊岛屿。后续又明确标注希腊立场，不能说希腊全文未讨论争议。（置信标记：high）
  - `en/Q22734752.json`，`article[1]`：as indisputably Greek by Greece but as grey zones of undetermined sovereignty by Turkey
    中文释义：希腊认为无争议地属于希腊，土耳其视为主权未定灰区。
  - `el/Q7997.json`，`article[0]`：δύο ελληνικές ακατοίκητες νησίδες
    中文释义：两个希腊无人小岛。

## India（英文锚点 14533）

语言：en, hi, ne, ur, zhs, zht；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：英文截至2023-05称人口世界第一，印地语仍称中国之后第二；尼语/乌语也为第二，中文称第一。明显需按数据日期核对，不能仅解释为政治立场。（置信标记：medium）
  - `en/Q14533.json`，`article[0]`：India, officially the Republic of India (ISO: ), is a country in South Asia. It is the seventh-largest country by area, the most populous country as of 1 May 2023, and the most pop
    中文释义：。
  - `hi/Q59.json`，`article[0]`：भारत (आधिकारिक नाम: भारत गणराज्य, ) दक्षिण एशिया में स्थित भारतीय उपमहाद्वीप का सबसे बड़ा देश है। भारत भौगोलिक दृष्टि से विश्व का सातवाँ सबसे बड़ा देश है, जबकि जनसंख्या के दृष्टिको
    中文释义：。

## Indonesia（英文锚点 14579）

语言：en, id, ms；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：英语约2.8亿、印尼语2022年277749853、马语2022年约2.75亿。年份、估计与四舍五入需分开处理；不是明确立场冲突。各语均称群岛国家。（置信标记：medium）
  - `en/Q14579.json`，`article[0]`：With around 280 million people
    中文释义：约2.8亿人口。。
  - `id/Q44.json`，`article[1]`：277,749,853 jiwa pada tahun 2022
    中文释义：2022年人口277749853。。
  - `ms/Q2060.json`，`article[1]`：275 juta orang pada 2022
    中文释义：2022年约2.75亿人口。。

## Ingwavuma（英文锚点 500183）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Iran（英文锚点 14653）

语言：ar, en, fa；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：同一海湾的命名不同：阿语导语使用阿拉伯湾，英语和波斯语使用波斯湾。可确认地名框架差异，但不能把语言自动等同国家政策或作者意图。（置信标记：high）
  - `ar/Q3672.json`，`article[0]`：الخليج العربي
    中文释义：阿拉伯湾。。
  - `en/Q14653.json`，`article[0]`：the Persian Gulf
    中文释义：波斯湾。。
  - `fa/Q163930.json`，`article[0]`：خلیج فارس
    中文释义：波斯湾。。

## Iraq（英文锚点 7515928）

语言：ar, en, fa；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：阿语第二段补充2020年人口与族群比例；波斯语第二段补充地形、石油储量；英文第二段补充古文明。属于国家内容侧重不同，未确认同一事实冲突。（置信标记：medium）
  - `ar/Q1415.json`，`article[1]`：سنة 2020 بزهاء 40 مليوناً و150 ألف نسمة
    中文释义：2020年约4015万人。
  - `fa/Q1428.json`，`article[1]`：۱۴۳ میلیارد بشکه ذخایر تاییدشدهٔ نفتی
    中文释义：1430亿桶已探明石油储量。

## Ireland（英文锚点 147575）

语言：da, en, is；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **实体范围／清洗风险**：两个语言版本对齐的是整个爱尔兰岛，不是单独爱尔兰共和国；若查询把Ireland作为声索国家，需先修正实体范围，不能把岛/国家混用归为立场差异。（置信标记：medium_preliminary）
  - `en/Q147575.json`，`article[0]`：Ireland ( ;  ; Ulster-Scots:  ) is an island in the North Atlantic Ocean, in north-western Europe. It is separated from Great Brit
    中文释义：英语明确为爱尔兰岛。。
  - `is/Q4171.json`，`article[0]`：Írland (enska Ireland, gelíska Éire) er þriðja stærsta eyja Evrópu á eftir Stóra-Bretlandi og Íslandi. Hún liggur vestan við Stóra-Bretland og Írlandshaf en að Atlantshafi í vestri
    中文释义：冰岛语明确为欧洲第三大岛，并描述其政治分割。。

- **实体范围／清洗风险**：两篇实际都是爱尔兰岛，非仅爱尔兰共和国。跨语言身份一致，但将其作为声索国家词条时存在岛/国家范围风险，不能当作国家立场差异。（置信标记：medium）
  - `en/Q147575.json`，`article[0]`：is an island in the North Atlantic Ocean
    中文释义：是北大西洋中的岛屿。
  - `da/Q5832.json`，`article[0]`：Irland er den tredjestørste ø i Europa
    中文释义：爱尔兰是欧洲第三大岛。

- **数字／时间候选差异**：2022年与2006年的全岛人口估计不同，年份已明确，不能据此判为同一时间事实冲突。（置信标记：medium）
  - `en/Q147575.json`，`article[1]`：As of 2022, the population of the entire island is just over 7 million
    中文释义：截至2022年全岛人口略超过700万。
  - `da/Q5832.json`，`article[1]`：lige under seks millioner (2006)
    中文释义：略低于600万（2006年）。

## Isfara Valley（英文锚点 2199501）

语言：en, ky, tg；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **实体范围／清洗风险**：元数据对齐目标是Isfara Valley，但吉尔吉斯语与塔吉克语导语均为Isfara城市，英语Valley正文为空。必须先核对城市与河谷范围，不能将城市人口资料和空河谷页比较成国别立场。（置信标记：high）
  - `ky/Q18351.json`，`article[0]`：Исфара – Тажикстандын түштүгүндөгү шаар (1952-жылдан). Исфара дарыясынын боюнда. Калкы 35,5миң (1991). Темир жол станциясы. Гидрометаллургия, жарык берүүчү техн
    中文释义：Isfara是塔吉克斯坦城市，1952年起为城市。。
  - `tg/Q1863.json`，`article[0]`：Исфара ( >  аз *’spr «сипар» дар суғдӣ) — шаҳр дар шимоли Тоҷикистон, дар вилояти Суғд ҷойгир шудааст. Номи аввали ин шаҳр Асбара буд. 
    中文释义：Isfara是塔吉克斯坦北部Sughd省的城市。。

## Isla Suárez（英文锚点 12802694）

语言：en, es, pt；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：两篇对于同一1867年阿亚库乔条约引用的条款编号不同（2/4）；应核对原条约及引文段落，属于可追查的来源定位差别。（置信标记：medium_preliminary）
  - `en/Q12802694.json`，`article[1]`：article 2, declares:
    中文释义：将1867条约边界引文定位第2条。。
  - `es/Q1065640.json`，`article[1]`：artículo 4 expresa sobre la línea limítrofe:
    中文释义：将相应1867条约边界引文定位第4条。。

- **措辞／归因／命名差异**：英语描述巴西de facto管理，葡萄牙语用de jure；这是事实控制与法律权利两种不同概念，应作为法律归属叙述差异核查，不自行裁定合法性。（置信标记：high）
  - `en/Q12802694.json`，`article[0]`：Brazil administers it de facto
    中文释义：巴西对其实施事实管理。
  - `pt/Q2320240.json`，`article[0]`：que a administra de jure
    中文释义：对其实施法律意义上的管理。

## Island of Vukovar（英文锚点 14163290）

语言：en, hr, sr；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：克罗地亚语导语称克罗地亚河岛并用占领措辞；英、塞导语先称争议岛屿。属于明确归属/叙述框架差异，不独立裁定主权。（置信标记：high）
  - `hr/Q126772.json`，`article[0]`：hrvatski riječni otok
    中文释义：克罗地亚河流岛屿。。
  - `hr/Q126772.json`，`article[1]`：drži pod okupacijom.
    中文释义：仍置于占领之下。。
  - `en/Q14163290.json`，`article[0]`：is a disputed island
    中文释义：是争议岛屿。。
  - `sr/Q4162643.json`，`article[0]`：Територија је под спором између Хрватске и Србије.
    中文释义：该领土为克罗地亚与塞尔维亚所争议。。

## Island of Šarengrad（英文锚点 14106957）

语言：en, hr, sr；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：克罗地亚语以“克罗地亚河岛”开篇；塞尔维亚语以塞克争议领土开篇，并列双方河界/地籍论据。属于归属措辞和争议呈现方式差异。（置信标记：high）
  - `hr/Q16322.json`，`article[0]`：Šarengradska ada je hrvatski riječni otok na Dunavu
    中文释义：Šarengrad是多瑙河上的克罗地亚河岛。
  - `sr/Q1430712.json`，`article[0]`：које је тренутно спорна територија између Србије и Хрватске
    中文释义：目前是塞尔维亚与克罗地亚之间的争议领土。

## Israel（英文锚点 9282173）

语言：ar, en, iw；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：希伯来语导语以犹太民族家园及独立叙述建国，并在面积中明确包括以色列宣告主权的东耶路撒冷、戈兰；英语描述地理位置，并在历史叙述明确巴勒斯坦流离失所/占领区域。此处为概念范围与法律/历史框架候选，阿语首段保留大量未清洗模板，不可把其模板与叙事段直接比较成价值偏差。（置信标记：medium）
  - `iw/Q320304.json`，`article[0]`：יִשְׂרָאֵל היא מדינה במזרח התיכון, במערב יבשת אסיה, השוכנת על החוף הדרום־מזרחי של הים התיכון. ישראל הוקמה בשטחי ארץ ישראל, ביתו הלאומי וארץ מולדתו של העם היהודי. המדינה הכריזה על עצמאותה בה' באייר תש"ח, 14 במאי 1948, והיא בעלת משטר מסוג דמוקרטיה פרלמנטרית.
    中文释义：以色列建立于犹太人民民族家园和故土，1948年宣布独立。。
  - `iw/Q320304.json`，`article[1]`：שטחה של המדינה הוא 22,072 קמ"ר (כולל מזרח ירושלים ורמת הגולן עליהן הכריזה ריבונות, ללא אזור יהודה ושומרון). אוכלוסייתה מנתה בשנת 2023, על־פי נתוני הלשכה המרכזית לסטטיסטיקה, 9,716,600 תושבים. מבחינה דמוגרפית, רו
    中文释义：面积包括已宣告主权的东耶路撒冷及戈兰，不含犹太和撒马利亚地区。。
  - `en/Q9282173.json`，`article[2]`：Upon its independence, Israel became almost immediately embroiled in conflict with its five neighboring Arab states, whose armies began entering the area of the former Mandatory Palestine on 15 May, starting the 1948 Arab–Israeli War. Early the next year, the 1949 Armistice Agreements left Israel in control of over one-third more territory than the partition plan had called for, with no independent Arab state created. During both stages of the 1948 Palestine war, over 700,000 Palestinian Arabs were expelled from or fled Israeli territory to the West Bank, Gaza, and the neighboring Arab countri
    中文释义：1948年战争和巴勒斯坦阿拉伯人流离失所的叙述。。

## Italy（英文锚点 14532）

语言：en, fr, it；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：意大利语导语补充人口/欧盟地位，法语第二段补充1861统一与1946共和国；初筛无明确主权冲突。（置信标记：medium）
  - `it/Q2340360.json`，`article[0]`：LItalia (AFI: , ), ufficialmente Repubblica Italiana, è uno Stato membro dell'Unione europea, situato nell'Europa meridionale e occidentale, il cui territorio coincide in gran part
    中文释义：。
  - `fr/Q1492.json`，`article[1]`：L'Italie apporte une contribution très importante à la civilisation occidentale : elle est notamment le berceau de la civilisation étrusque, de la Grande-Grèce, de l'Empire romain,
    中文释义：。

## Ivory Coast（英文锚点 57744）

语言：en, fr；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：两文一致区分首都与经济中心，法文补充机构所在地；是行政现实细节互补。（置信标记：medium_preliminary）
  - `en/Q57744.json`，`article[0]`：Its capital is Yamoussoukro, in the centre of the country, while its largest city and economic centre is the port city of Abidjan. It borders Guinea to the northwest, Liberia to the west, Ma
    中文释义：区分亚穆苏克罗首都与阿比让经济中心。。
  - `fr/Q786.json`，`article[1]`：La Côte d'Ivoire a pour capitale politique et administrative Yamoussoukro mais la quasi-totalité des institutions se trouvent à Abidjan, son principal centre économique. Sa langue officielle est le fr
    中文释义：补充绝大多数机构仍位于阿比让。。

## Jamaica（英文锚点 15660）

语言：en, es；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英文第二段介绍殖民史，西语第二段补充岛屿长宽与距邻岛距离；地理与历史互补。（置信标记：medium）
  - `en/Q15660.json`，`article[1]`：following the arrival of Christopher Columbus in 1494
    中文释义：在1494年哥伦布抵达之后。
  - `es/Q8004.json`，`article[1]`：240 km de largo y un máximo de 80 km de ancho
    中文释义：长240公里、最宽80公里。

## James Shoal（英文锚点 3281084）

语言：en, ms, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：英语导语明确马来西亚管理，同时列三方声索；中文段落详列三方行政主张和大陆架理由，不能把行政划分主张当作实际管理。主题侧重可影响归属判断。（置信标记：medium）
  - `en/Q3281084.json`，`article[0]`：The shoal and its surrounds are administered by Malaysia.
    中文释义：暗沙及周边由马来西亚管理。。
  - `zhs/Q8253.json`，`article[1]`：中华民国内政部将其划为高雄市辖属
    中文释义：中华民国内政部将其划入高雄市。。

- **措辞／归因／命名差异**：英语区分马来西亚管理与中方/台方声索；马来语导言用合法控制字样。这是法律评价与事实管理的区分，未据此裁定合法主权归属。（置信标记：high）
  - `en/Q3281084.json`，`article[0]`：It is claimed by Malaysia, the People's Republic of China, and the Republic of China (Taiwan).
    中文释义：马来西亚、中华人民共和国和中华民国（台湾）均声索。
  - `ms/Q689005.json`，`article[0]`：di bawah kawalan sah oleh tentera laut negara Malaysia
    中文释义：由马来西亚海军合法控制。

## Jammu and Kashmir (union territory)（英文锚点 61449812）

语言：en, hi, ur；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：英、印地、乌尔都语均采用印度行政管理的基本描述。印地语对一侧使用“巴基斯坦占领的克什米尔”，乌尔都语称“巴基斯坦管理的自由克什米尔”；这是行政状态与政治命名/占领用词差异，不是简单的管理者事实相反。（置信标记：high）
  - `en/Q61449812.json`，`article[0]`：Jammu and Kashmir is a region administered by India as a union territory and consists of the southern portion of the larger Kashmir region, which has been the subject of a dispute between India and Pakistan since 1947, and between India and China since 1962. The Line of Control separates Jammu and Kashmir from the Pakistani-administered territories of Azad Kashmir and Gilgit-Baltistan in the west and north. It lies to the north of the Indian states of Himachal Prade
    中文释义：由印度作为中央直辖区管理，控制线另一侧为巴基斯坦管理区域。。
  - `hi/Q1067402.json`，`article[0]`：पाक अधिकृत कश्मीर
    中文释义：包含“巴基斯坦占领的克什米尔”措辞。。
  - `ur/Q866322.json`，`article[0]`：پاکستان کے زیر انتظام آزاد کشمیر
    中文释义：包含巴基斯坦管理的自由克什米尔表述。。

## Japan（英文锚点 15573）

语言：en, ja, ko, ru, zhs, zht；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：岛屿数6852/14125差别可能涉及测量标准与2023重新统计的更新速度；归档文本未统一统计口径，不能作立场偏差证据。日文归档为空。（置信标记：medium_preliminary）
  - `ko/Q241789.json`，`article[1]`：6,852개의 섬으로 이루어진 군도 국가인 일본은 혼슈, 규슈, 시코쿠, 홋카이도 등 4개의 섬이 일본 전체 면적의 97%를 차지하며, 대부분의 섬들이 화산 활동을 통해 생겨났다.
    中文释义：韩语列6852岛。。
  - `ru/Q1472.json`，`article[1]`：6852 островов. Четыре крупнейших острова — Хонсю, Хоккайдо, Кюсю и Сикоку — составляют свы
    中文释义：俄语列6852岛。。
  - `zhs/Q247418.json`，`article[0]`：14,125座岛屿所组成，面积约37.8万平方公里。国土全境被太平洋及鄂霍次克海、日本海、东海等陆缘海环抱，西邻朝鲜半岛以及俄罗斯远东地区，东北接千岛群岛，西南面台湾与中国大陆。人口达1.2
    中文释义：中文列14125岛。。

## Jiangxinpo（英文锚点 55586764）

语言：en, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：两者均定位恩梅开江和迈立开江间地带，英文明示现属缅甸，中文导语及次段补充地貌、原住人群和面积；这些是互补范围细节。（置信标记：medium）
  - `en/Q55586764.json`，`article[0]`：Jiangxinpo () is an area currently in Kachin State, Myanmar, located between the N'Mai and Mali Rivers, west of the Gaoligong Mountains of Yunnan, China. It was previously under th
    中文释义：。
  - `zht/Q139388.json`，`article[0]`：江心坡是指位於雲南高黎貢山以西的恩梅開江及邁立開江之間的地帶，面積約爲27000平方公里。北起西藏最南的察隅縣，西至邁立開江，東至恩梅開江，南到兩江匯流處，是景頗族、儂日旺（景頗化的獨龍族）的世居地。
    中文释义：。

## Juan de Nova Island（英文锚点 15724）

语言：en, fr, mg；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：法语补充guano铁路与Jean-de-Noves名称使用史，马达加斯加语保留跑道1.2公里。法/马两语均明确法国领地及马达加斯加声索，不能仅按语言推断两方对立。（置信标记：medium）
  - `fr/Q401300.json`，`article[0]`：Une ligne de chemin de fer y fut construite pour transporter le guano.
    中文释义：曾为运输鸟粪修建铁路。。
  - `mg/Q281546.json`，`article[0]`：tany frantsay takian' i Madagasikara
    中文释义：法国领地、马达加斯加声索。

## Junagadh State（英文锚点 32188194）

语言：en, hi, ur；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：印地语导语以公投并入印度叙述，乌尔都语导语突出1947年纳瓦布宣布加入巴基斯坦。二者可能描述不同时间阶段，需审查完整历史，不能直接按语言裁定谁正确。（置信标记：medium）
  - `hi/Q803701.json`，`article[0]`：भारतीय संघ में जनमत द्वारा शामिल कर लिया गया।
    中文释义：通过公投并入印度联邦。。
  - `ur/Q109973.json`，`article[0]`：پاکستان کے ساتھ الحاق کا اعلان
    中文释义：宣布加入巴基斯坦。。

## KaNgwane（英文锚点 1913990）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Kafia Kingi（英文锚点 32815383）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Kalapani territory（英文锚点 30049213）

语言：en, ne；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：尼泊尔语导语直接把Kalapani置于尼泊尔Darchula，后述印度反复声索；英语先写印度管理、尼泊尔自1997年声索，并用“according to Nepal”归因尼方行政位置。属于主张是否归因/作为无归因事实陈述的差异，不能由此独立裁定领土归属。（置信标记：high）
  - `ne/Q10852.json`，`article[0]`：कालापानी नेपालको सुदूरपश्चिम प्रदेशस्थित दार्चुला जिल्लाको व्यास नगरपालिकामा रहेको क्षेत्र हो।
    中文释义：Kalapani是尼泊尔Darchula的Byas市区域。。
  - `en/Q30049213.json`，`article[0]`：The Kalapani territory is an area under Indian administration as part of Pithoragarh district in the Kumaon Division of the Uttarakhand state, but it is also claimed by Nepal since 1997. According to Nepal's claim, it lies in Darchula district, Sudurpashchim Province. / The territory represents part of the basin of the Kalapani river, one of the headwaters of the Kali R
    中文释义：印度管理、尼泊尔自1997年声索；按尼方声索属于Darchula。。
  - `ne/Q10852.json`，`article[1]`：सीमा विवाद  / कालापानी क्षेत्र भारतले पटकपटक आफ्नो क्षेत्रको रूपमा दाबी गर्दै आइरहेको छ। भारतको अनुसार कालापानी उत्तराखण्डस्थित पिथौरागढ जिल्लाको एक गाउँको रुपमा रहेको उल्लेख छ। सन् १८१६ मा नेपाल र तत्कालीन इस्ट इन्डिया कम्पनीसँग भएको सुगौली सन्धिले तय
    中文释义：边界争议段记述印度反复声索及双方对河源的分歧。。

## Kardak（英文锚点 876441）

语言：en, tr；类型：territory_or_related_geography；状态：excerpt_screened_no_clear_difference。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Karki, Azerbaijan（英文锚点 3075692）

语言：az, en, hy；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：az称阿塞拜疆飞地并使用亚美尼亚占领，en区分法理阿塞拜疆/实际亚美尼亚控制，hy导语直接定位为亚美尼亚阿拉拉特村庄。对应行政事实和主权归因呈现不同，不能只按地名差异判断。（置信标记：medium）
  - `az/Q121025.json`，`article[0]`：Kərki — Azərbaycan Respublikası Naxçıvan Muxtar Respublikasının Sədərək rayonunun inzibati-ərazi vahidində kənd. Azərbaycanın Ermənistan ərazisindəki 3 eksklav ərazisindən biri. 19
    中文释义：。
  - `en/Q3075692.json`，`article[0]`：Karki () or Tigranashen () is a village that is de jure an enclave of Azerbaijan, de facto under the control of Armenia, administrated within the Ararat Municipality of the Ararat 
    中文释义：。
  - `hy/Q701048.json`，`article[0]`：Տիգրանաշեն, գյուղ Հայաստանի Արարատի մարզում՝ Մ 2 (Երևան-Գորիս-Մեղրի) միջպետական ավտոճանապարհի անմիջապես աջ կողմում։ 
    中文释义：。

## Kaurik（英文锚点 65554647）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Kazakhstan（英文锚点 16642）

语言：en, ru, uz；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英文首段注明首都2019—2022年名Nur-Sultan，俄语第二段补充经济以碳氢行业为主；首都阿斯塔纳的基本事实一致。（置信标记：medium）
  - `en/Q16642.json`，`article[0]`：Its capital is Astana, known as Nur-Sultan from 2019 to 2022.
    中文释义：首都阿斯塔纳2019至2022年名努尔苏丹。。
  - `ru/Q1657.json`，`article[1]`：В экономике доминирует углеводородная промышленность
    中文释义：经济由碳氢工业主导。

- **事实互补**：两篇对首都及中亚/东欧位置相合；乌兹别克语摘录提供17州和各邻国边界长度，英文摘录则较宏观。属于细节互补，未据此发现主权冲突。（置信标记：medium）
  - `en/Q16642.json`，`article[0]`：Its capital is Astana
    中文释义：首都是阿斯塔纳。
  - `uz/Q1645.json`，`article[0]`：maʼmuriy jihatdan 17 viloyat
    中文释义：行政上有17个州。

## Kenya（英文锚点 188171）

语言：en, sw；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：两语均确定东非国家；斯瓦希里语逐项列边界，英语补充2019年普查与城市经济。所审片段显示基本地理兼容，没有明确领土立场差异。（置信标记：medium）
  - `en/Q188171.json`，`article[0]`：is a country in East Africa
    中文释义：是东非国家。。
  - `sw/Q1676.json`，`article[1]`：Kenya imepakana na Ethiopia
    中文释义：肯尼亚与埃塞俄比亚接壤。。

## Kfar Qouq（英文锚点 31272881）

语言：ar, en；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：阿英均将Kfar Qouq定位于黎巴嫩Rashaya/Beqaa；阿语补充德鲁兹与希腊正教居民和家族，英语补充罗马神庙遗址。属于文化/考古细节互补，不支持国别归属相反。（置信标记：medium）
  - `ar/Q536683.json`，`article[0]`：كفر قوق هي إحدى القرى اللبنانية من قرى قضاء راشيا في محافظة البقاع. معظم سكان القرية من أتباع الطائفة الدزريَّة و طائفة الروم الارثوذكس ومن عائلاتها : سرايا، عربي، عبد الخالق، أبو درهمان، الحداد، عون، عازار،خميس، الخوري ... ..
    中文释义：黎巴嫩Rashaya村落，居民主要为德鲁兹和希腊正教社群。。
  - `en/Q31272881.json`，`article[1]`：The population of the hillside village is predominantly Druze. It contains two Roman temple sites in the Western section of the town dating to around 111 BC  and another less preserved temple near the church. Fragments such as columns and an inscribed block have been re-used in the village and surrounding are
    中文释义：主要德鲁兹人口，含罗马神庙遗址。。

## Khan Tengri（英文锚点 1915050）

语言：en, ky, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：中文提供未被英文清洗文本保留下来的具体海拔值，英文补充登山分类；简繁同源不计独立观点。（置信标记：medium_preliminary）
  - `en/Q1915050.json`，`article[0]`：geologic elevation is , but its glacial icecap rises to . For this reason, in mountaineering circles, including for the Soviet Snow Leopard award criteria, it is considered a 7,000
    中文释义：区分岩体海拔与冰帽，登山按7000米峰计算。。
  - `zhs/Q57953.json`，`article[0]`：6,995公尺（包括冰川帽为7,010公尺）。位于托木尔峰北面，西邻吉尔吉斯斯坦境内伊塞克湖盆地，北邻伊犁河谷地，南邻塔里木盆地北缘的阿克苏绿州。汗腾格里峰一带地势高峻，山岭海拔多在4,000公尺以上，6,000公尺以上
    中文释义：明确6995米、含冰帽7010米。。

- **数字／时间候选差异**：英语称天山第二高峰，吉尔吉斯语首句称天山最高峰，紧接着又称最高峰之一。应核查峰顶冰盖/地质高度、山系范围及文本内部矛盾，不直接认定主权偏差。（置信标记：high）
  - `en/Q1915050.json`，`article[1]`：the second-highest mountain in the Tian Shan
    中文释义：天山第二高峰。
  - `ky/Q10897.json`，`article[0]`：Теңир-Тоонун эң бийик чокусу.
    中文释义：天山的最高峰。

## Khao Phra Wihan National Park（英文锚点 8717575）

语言：en, th；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英语详述高棉遗迹及边境地理；泰语补充国家公园面积、设立法律和日期。应区分泰国国家公园与柬埔寨寺庙，避免对象混淆。（置信标记：medium）
  - `en/Q8717575.json`，`article[0]`：Khao Phra Wihan National Park () is a protected natural area in Sisaket Province, Thailand, that contains numerous ruins of the 11th century Khmer Empire.  The park lies  south of 
    中文释义：。
  - `th/Q34192.json`，`article[0]`：อุทยานแห่งชาติเขาพระวิหาร อยู่ในพื้นที่อำเภอกันทรลักษ์ จังหวัดศรีสะเกษ และอำเภอน้ำขุ่น อำเภอน้ำยืน จังหวัดอุบลราชธานี มีเนื้อที่ 85,388.97 ไร่ (136.62 ตารางกิโลเมตร) อาณาเขตด้านใต้
    中文释义：。

## Kherson Oblast（英文锚点 1273370）

语言：en, ru, uk；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：英俄文均将赫尔松州列为乌克兰行政区并描述俄罗斯占领；乌语进一步将公投称为伪造。存在评价措辞强度差异，但不能将俄语自动归为支持俄方。（置信标记：high）
  - `ru/Q57932.json`，`article[4]`：бо́льшая часть области находится под российской оккупацией.
    中文释义：该州大部分处于俄罗斯占领下。。
  - `en/Q1273370.json`，`article[2]`：internationally unrecognized.
    中文释义：在国际上未获承认。。
  - `uk/Q3182.json`，`article[3]`：фейковий "референдум"
    中文释义：伪造的“公投”。。

## Khuriya Muriya Islands（英文锚点 17350）

语言：ar, en；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：两语同样将五岛置于阿曼Dhofar；阿语摘录明确1854年转让英国与1967年归还，英语摘录补充古代名称和航海记载。历史细节互补，未发现这组摘录中直接归属冲突。（置信标记：medium）
  - `ar/Q36272.json`，`article[1]`：في عام 1854 تنازل عنها سلطان عُمان لبريطانيا لإقامة محطة كابلات اتصالات (تلغراف). ضمت بريطانيا الجزر فوراً إلى محمية عدن حتى عام 1963، عندما نقلت بريطانيا سلطة الإشراف عليها إلى القائم السياسي (البريطاني) على الخليج العربي المقيم في البحرين. ثم اعيدت للسيادة العُمانية في 30 نوفمبر 1967. / اسمها القديم كان الحلانيات ثم تغير اسمها إلى كوريا موريا وفي عهد السلطان قابوس أصب
    中文释义：1854年转让英国，1967年11月30日归还阿曼主权。。
  - `en/Q17350.json`，`article[0]`：The Khuriya Muriya Islands (also Kuria Muria, Kooria Mooria, Curia Muria) (; transliterated: Juzur Khurīyā Murīyā or Khūryān Mūryān) are a group of five islands in the Arabian Sea,  off the southeastern coast of Oman. The islands form part of the province of Shalim and the Hallaniyat Islands in the governorate of Dhofar.
    中文释义：五岛属于阿曼Dhofar省Shalim与Hallaniyat。。

## Kimathanka（英文锚点 20289915）

语言：en, ne；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：英文引用1991年人口303、50户；尼泊尔语段落引用2001年人口368、72户。是不同年份统计，不能把数字差当作事实矛盾或立场差异。（置信标记：high）
  - `en/Q20289915.json`，`article[0]`：At the time of the 1991 census, it had a population of 303 people living in 50 individual households.
    中文释义：1991年人口303人、50户。。
  - `ne/Q23684.json`，`article[1]`：जनसङ्ख्या - ३६८
    中文释义：人口368。

## Kinburn Peninsula（英文锚点 43156381）

语言：en, ru, uk；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：三文所阅地理/行政/词源信息互补，导语未显示相反主权归属。词源译法若研究需另行语言学核对。（置信标记：medium_preliminary）
  - `en/Q43156381.json`，`article[0]`：Administratively the peninsula is divided between two regions, each represented by one rural community: Pokrovske (Mykolaiv Oblast) and Heroiske (Kherson Oblast), population  1,450. It is part of the Ivory Coast of Sviatoslav National Nature Park.
    中文释义：列出两个州与各自社区。。
  - `ru/Q707897.json`，`article[0]`：45 км, ширина — 4-12 км, площадь — 215,6 км². Западная часть полуострова расположена в Николаевском районе Николаевской области, восточная часть — в С
    中文释义：补充长度45千米、宽度4—12千米、面积215.6平方千米。。
  - `uk/Q6617.json`，`article[1]`：Назва  / Півострів був названий на честь форту Кінбурн XVI століття, який був побудований османами для захисту річки Дніпро. Назва походить від турецького «Kilburun» і означає «прекрасний (вузький) полюс». Фортеця часто бу
    中文释义：补充奥斯曼堡垒名称和历史。。

## Kinmen（英文锚点 164266）

语言：en, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：中英均注明中华民国管辖；中文补充地方语言与早期开发史，英文补充县域及乌坵构成。不存在据此认定的控制权冲突。（置信标记：medium）
  - `en/Q164266.json`，`article[0]`：governed as a county by the Republic of China (Taiwan)
    中文释义：作为中华民国（台湾）的县管辖。
  - `zhs/Q20308.json`，`article[0]`：金门县内辖有3镇、3乡。
    中文释义：金门县辖3镇、3乡。。

## Koalou（英文锚点 74618082）

语言：en, fr；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英语补充2009起双方联合委员会管理，法语导语并列两国行政归属与主权争议。治理机制与声索背景可互补。（置信标记：medium）
  - `en/Q74618082.json`，`article[1]`：Since 2009 the area has been administered by the Joint Committee for the Concerted Management of the Kourou/Koalou Area (COMGEC-K). The committee is comprised of 14 members from ea
    中文释义：。
  - `fr/Q12565231.json`，`article[0]`：Koalou (nom burkinabé) ou Kourou (nom béninois) est une zone rurale avec deux principaux villages le long de la route nationale reliant le Burkina Faso au Bénin en traversant un po
    中文释义：。

## Korean Peninsula（英文锚点 247273）

语言：en, ko；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **实体范围／清洗风险**：韩语标题한국/조선/코리아释义为朝鲜半岛地区或韩民族的国家概念，范围含半岛及附属岛屿；英语Korean Peninsula正文为空。不能把韩语한국直接等同South Korea，也不足以作语言立场比较。（置信标记：high）
  - `ko/Q280.json`，`article[0]`：한국(韓國), 조선(朝鮮), 남북한(南北韓), 또는 코리아()는 동아시아의 한반도에 위치한 지역 또는 한민족의 나라를 지칭하는 말로, 오늘날에는 한반도와 그 부속 도서를 이르는 말이다.
    中文释义：한국/조선/코리아指半岛上的地区或韩民族国家概念，今指半岛及附属岛屿。。

## Kosovo（英文锚点 17391）

语言：en, sq, sr；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：阿尔巴尼亚语直接称独立国家，塞尔维亚语称在塞尔维亚领土上单方面宣布的国家并诉诸法律框架，英语称部分承认国家。是明确可引证的国家地位框架差异，不是本审计对国际法的裁决。（置信标记：high）
  - `en/Q17391.json`，`article[0]`：a landlocked partially recognised state
    中文释义：一个内陆、获得部分承认的国家。
  - `sq/Q3586.json`，`article[0]`：është një shtet i pavarur
    中文释义：是一个独立国家。
  - `sr/Q729518.json`，`article[0]`：једнострано проглашене државе на територији Републике Србије
    中文释义：在塞尔维亚共和国领土上单方面宣布的国家。

## Kula Kangri（英文锚点 1594423）

语言：en, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：英语导语以不丹最高峰主张及“完全位于西藏”的争论开头；中文明确目前由中国洛扎县管辖，同时保留很多人认为位于不丹的说法。是主张归因、实际管理和山峰归属争论的侧重差异；简繁共享来源。（置信标记：high）
  - `en/Q1594423.json`，`article[0]`：Kula Kangri is claimed by many authorities to be the highest mountain in Bhutan but this is disputed by others, who claim that Kula Kangri is wholly in Tibet.The mountain is part of the Bhutan Himalaya.
    中文释义：是否不丹最高峰或完全位于西藏存在争论。。
  - `zhs/Q609281.json`，`article[1]`：目前归属中国西藏自治区洛扎县管辖。但是也有很多人认为它是不丹境内的第一高峰。不丹人是藏族的一支，不丹王国历史上曾向拉萨政府称藩，所以不丹和中国西藏自治区至今没有明确的划界。把该峰看作中国境内山峰的人认为干卡本森峰才是位于中不边界的不丹最高峰。
    中文释义：目前归中国洛扎县管辖，同时保留位于不丹的说法。。

## Kuril Islands（英文锚点 197615）

语言：en, ja, ru；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：俄语以属萨哈林州叙述并归因日本争议；日语以实际控制用语并分别归因两国法律观点，英语也区分俄方行政和日本声索。属法律归属与实际控制框架差异，不是三语对实际控制完全相反。（置信标记：high）
  - `ru/Q14416.json`，`article[1]`：Курильские острова входят в Сахалинскую область России.
    中文释义：千岛群岛属于俄罗斯萨哈林州。。
  - `ja/Q481680.json`，`article[1]`：全島がロシア連邦の実効支配地域である。
    中文释义：全岛处于俄罗斯联邦实际控制之下。。
  - `en/Q197615.json`，`article[1]`：Japan claims the four southernmost islands
    中文释义：日本声索最南部四岛。。

## Kutuzov Island（英文锚点 14714690）

语言：en, ru, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：转让、河道变更、1991承认和现行政划分是不同时间/法律维度的互补；不将不同历史侧重直接判为矛盾。（置信标记：medium_preliminary）
  - `en/Q14714690.json`，`article[1]`：Under former Chinese possession it was known as Daxitong dao. Control was transferred to the Soviet Union by the government of Manchukuo. Under the terms of the agreement, the island remained in Russia's possession with the fall of the Soviet Union. The Republic of China (Taiwan) does not recognize this and other transfers to the USSR or Russia since 1931.
    中文释义：说明原中国归属、满洲国转让、中华民国不承认转让。。
  - `zht/Q3192119.json`，`article[1]`：該島本在烏蘇里江航道西側，1925年至1927年間，蘇聯在大西通島西側疏浚航道，使烏蘇里江改道，其正流推向中國一側，使得大西通島置於主航道以東。因此以主航道爲國界爲由，蘇聯管轄。1991年根據《中蘇國界東段協定》，中國正式承認蘇聯對該島的管轄權。
    中文释义：补充1925—1927疏浚改道和1991协定承认管辖。。
  - `ru/Q3232450.json`，`article[0]`：Кутузов — крупнейший остров на реке Уссури. Административно относится к Бикинскому району Хабаровского края России.
    中文释义：现俄方行政区划。。

## Kuwait（英文锚点 7515890）

语言：ar, en；类型：country；状态：excerpt_screened_no_clear_difference。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Kyrgyzstan（英文锚点 170131）

语言：en, ky, tg, uz, zhs, zht；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：吉语称总统制，中文称议会制；可能与2021宪制变化及修订来源年份有关，需按时间核实，不可直接断为民族立场。（置信标记：medium）
  - `ky/Q1031.json`，`article[1]`：Кыргызстан — унитардык, мамлекеттик башкарууга дин аралашпаган, президенттик мамлекет.  
    中文释义：。
  - `zhs/Q5296.json`，`article[1]`：作为中亚古国，吉尔吉斯斯坦历史达两千年，经历各种王朝与文化。因其被山峦环绕而相对孤立，吉尔吉斯文化得以较好传承；又因地理位置，吉尔吉斯斯坦处于多个文化交汇点。尽管众多部落族群在吉尔吉斯斯坦居住已久，但时有外来势力入侵统治。直至1991年从原苏联独立后，吉尔吉斯斯坦成为一个拥有独立主权的民族国家。政治体制为单一制和议会制。吉尔吉斯斯坦至今仍时有民族冲突、叛乱以
    中文释义：。

## Lachin corridor（英文锚点 21402399）

语言：az, en, hy；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：阿塞拜疆语使用qondarma（所谓/虚构的）修饰纳卡共和国；亚美尼亚语以人道走廊及阿尔察赫共和国框架命名。英文区分法理阿塞拜疆与2020年协议下俄维和控制。是称谓/合法性框架差异，且版本时间变化须另审。（置信标记：high）
  - `az/Q519574.json`，`article[0]`：qondarma "Dağlıq Qarabağ Respublikası"
    中文释义：所谓/虚构的“纳戈尔诺-卡拉巴赫共和国”。
  - `hy/Q754745.json`，`article[0]`：Բերձորի մարդասիրական միջանցք
    中文释义：Berdzor人道主义走廊。
  - `en/Q21402399.json`，`article[0]`：The corridor is de jure in the Lachin District of Azerbaijan
    中文释义：该走廊法理上位于阿塞拜疆拉钦区。

## Ladakh（英文锚点 303611）

语言：en, hi, ur；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：印地语关于拉达克范围的叙述显著包含印度声索地域，英语区分管理与争议；涉及范围/声索框架，不应当作同一行政边界的简单事实陈述。（置信标记：medium_preliminary）
  - `hi/Q2573.json`，`article[1]`：केन्द्र शासित प्रदेश लद्दाख के अन्तर्गत पाक अधिकृत गिलगित बलतिस्तान ,चीन अधिकृत अक्साई चिन और शक्सगम घाटी का क्षेत्र भी शामिल है ।  सन 1963 में पाकिस्तान द्वारा 5180 वर्ग किलोमीटर का शक्सगम घाटी क्षेत्र चीन को उपहार में दिया गया ,जो लद्दाख का हिस्सा 
    中文释义：将巴控吉尔吉特、中国控制阿克赛钦与沙克斯干谷纳入拉达克框架。。
  - `en/Q303611.json`，`article[0]`：administered by India as a union territory which constitutes a part of the larger Kashmir region and has been the subject of dispute between India, Pakistan, and China since 1947. Ladakh is 
    中文释义：称印度管理的联邦属地及更大的克什米尔争议。。
  - `ur/Q12997.json`，`article[0]`：لَدّاخ بھارت کا ایک یونین علاقہ ہے۔ یہ شمال میں قراقرم اور جنوب میں ہمالیہ کے پہاڑی سلسلوں کے درمیان میں ہے۔ یہ بھارت میں سب سے کم
    中文释义：称印度联邦属地。。

## Lake Nyasa（英文锚点 276464）

语言：en, sw；类型：territory_or_related_geography；状态：excerpt_screened_no_clear_difference。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Lake Victoria（英文锚点 72979）

语言：en, sw；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：两语均列坦桑尼亚49%、乌干达45%、肯尼亚6%的湖面划分，所审证据相互印证，不能当作单一国家拥有全湖。（置信标记：high）
  - `en/Q72979.json`，`article[1]`：Kenya occupies 6% (), Uganda 45% (), and Tanzania 49% ().
    中文释义：肯尼亚6%、乌干达45%、坦桑尼亚49%。。
  - `sw/Q3532.json`，`article[0]`：49% (km2 33,700) nchini Tanzania, 45% (km2 31,000) nchini Uganda, na 6% (km2 4,100) nchini Kenya.
    中文释义：坦桑尼亚49%、乌干达45%、肯尼亚6%。。

## Laos（英文锚点 17752）

语言：en, km, lo, th；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **证据不足**：泰语所选开头保留了未清理的信息框模板，和英语正文不能按段落位置直接比较。不能把清洗残留当成观点遗漏；需要选取后续真实正文再作细致比较。（置信标记：medium）
  - `en/Q17752.json`，`article[0]`：is a landlocked country in Southeast Asia
    中文释义：是东南亚内陆国家。
  - `th/Q1942.json`，`article[0]`：{{Infobox country
    中文释义：保留的国家信息框模板标记。

## Lapthal（英文锚点 65554275）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Lebanon（英文锚点 17771）

语言：ar, en, iw；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：阿语在邻国称谓中使用“被占领的巴勒斯坦—以色列”；英语和希伯来语使用以色列。是可直接定位的政治地名/归属修辞差异。（置信标记：high）
  - `ar/Q1309.json`，`article[0]`：وفلسطين المحتلة - إسرائيل من الجنوب
    中文释义：南边是被占领的巴勒斯坦—以色列。
  - `en/Q17771.json`，`article[0]`：Israel to the south
    中文释义：南部为以色列。
  - `iw/Q221222.json`，`article[0]`：המדינה גובלת בישראל בדרום
    中文释义：该国南部与以色列接壤。

## Liancourt Rocks（英文锚点 15083928）

语言：en, ja, ko；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：韩语与英语措辞重点不同，但韩语也明确载有日本主张；不能把导语直接归属语气误判为全文删除争议。（置信标记：medium_preliminary）
  - `ko/Q2174.json`，`article[0]`：대한민국의 암초이다. 울릉도에서 뱃길로 200리 정도 떨어져 있다. 서양권에서는 1849년에 독도를 발견한 프랑스 선박인 '리앙쿠르 호'의 이름을 따서 리앙쿠르 암초(, )라고 부
    中文释义：导语直接称韩国的礁岛。。
  - `ko/Q2174.json`，`article[1]`：현재 대한민국이 실효지배하고 있으나 일본국 정부에서는 다케시마()라는 명칭으로 영유권을 주장하고 있다.
    中文释义：随后注明韩国实际控制、日本提出主张。。
  - `en/Q15083928.json`，`article[1]`：While South Korea controls the islets, its sovereignty over them is contested by Japan. North Korea also claims the territory. South Korea classifies the islets as Dokdo-ri, Ulleung-eup, Ulleung County, North Gyeongsang Province, while Japan classifies the islands as part of Okin
    中文释义：区分韩国控制、日本争议，并列各国行政分类。。

- **措辞／归因／命名差异**：英语称韩国administered/control，并同时记日本争议；日语称海警常驻占拠。二者并非否认同一个事实控制，但占拠比管理具有不同评价色彩，属于措辞框架差异。（置信标记：high）
  - `en/Q15083928.json`，`article[0]`：administered by South Korea
    中文释义：由韩国管理。
  - `ja/Q2136996.json`，`article[1]`：現在は韓国の沿岸警備隊が常駐し占拠している
    中文释义：目前韩国海岸警卫队常驻并占据。

## Libya（英文锚点 17633）

语言：ar, en；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：阿语与英语列利比亚世界面积排名17和16、石油储量排名9和10。属统计口径/数据期候选差异，不是已核实立场冲突。（置信标记：high）
  - `ar/Q1571.json`，`article[0]`：الرقم 17 كأكبر بلدان العالم مساحةً
    中文释义：世界面积第17。。
  - `en/Q17633.json`，`article[0]`：the 16th-largest in the world
    中文释义：世界面积第16。。

## Lolwe（英文锚点 63818631）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Luapula Province border dispute（英文锚点 441520）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Luhansk Oblast（英文锚点 494904）

语言：en, ru, uk；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：乌语第二段直接指出俄罗斯入侵后被俄军占领；俄语导语也称乌克兰行政区。摘录存在战争叙事显著性差异，但不能据此说俄语全文否认占领。（置信标记：medium）
  - `uk/Q1799.json`，`article[1]`：Внаслідок російського вторгнення в Україну, територія Луганської області окупована збройними силами Російської Федерації.
    中文释义：。
  - `ru/Q11152.json`，`article[0]`：Луга́нская о́бласть (), или Луганщина (), — административно-территориальная единица Украины, расположенная на крайнем востоке страны, преимущественно в бассейне среднего течения Се
    中文释义：。

## Macau（英文锚点 19068）

语言：en, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：“transferred”与“回归”是历史事件措辞差异；两文都承认现中国特别行政区身份，非事实控制冲突。（置信标记：medium_preliminary）
  - `en/Q19068.json`，`article[1]`：transferred to China. Macau is a special administrative region of China, which maintains separate governing and economic systems f
    中文释义：1999年转交中国。。
  - `zhs/Q16175.json`，`article[0]`：1999年回归以前则为葡萄牙第二大城巿。澳门位于南海北岸、珠江口西侧，北接广东省珠海市，东面与邻近的香港相距63公里，其余两面与南海邻接。澳门亦是粤港澳大湾区的
    中文释义：使用1999年回归表述。。

## Macclesfield Bank（英文锚点 611705）

语言：en, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：两语导语均描述水下环礁；中文补充水深、地形及按20米等深线估算面积，英语补充命名船只的不同来源说法。水下地貌信息可互补，不能从这些摘录推断主权认同。（置信标记：medium）
  - `en/Q611705.json`，`article[0]`：Macclesfield Bank is an elongated sunken atoll of underwater reefs and shoals in the South China Sea. It lies east of the Paracel Islands, southwest of Pratas Island and north of the Spratly Islands. 
    中文释义：Macclesfield Bank是南海水下环礁。。
  - `zhs/Q3121136.json`，`article[1]`：地理 / 中沙环礁属于中沙群岛，向西距离三沙市西沙群岛的永兴岛约200公里，向东距离黄岩岛约300公里。环礁全为海水淹没，陆地面积为零；但若以20米等深线计算，中沙环礁的面积足有6000多平方公里，从海底看，像是一片海底高原，上面耸立着一座座高山。
    中文释义：全礁淹没、陆地面积为零，并按20米等深线估算面积。。

## Madagascar（英文锚点 18964）

语言：ar, en, fr, mg；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：地质时间叙述存在数字差异候选：英语给离非洲180百万年、离印度约90百万年；马达加斯加语出现35百万年及50百万年后再分离，需地质资料复核且可能含原文笔误。（置信标记：medium）
  - `en/Q18964.json`，`article[1]`：around 180 million years ago
    中文释义：约1.8亿年前。。
  - `mg/Q825.json`，`article[1]`：35 tapitrisa
    中文释义：3500万。。
  - `mg/Q825.json`，`article[1]`：50 tapitrisa taona taoriana
    中文释义：5000万年之后。。

## Mainland China（英文锚点 55079）

语言：en, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英文给地缘政治及排除港澳台的惯例定义；中文补充中华人民共和国与中华民国法律中的不同定义，并明确法理声索与实际控制不同。这是法律定义和语境范围互补，不能直接互判为事实矛盾。（置信标记：medium）
  - `en/Q55079.json`，`article[0]`："Mainland China" is a geopolitical term
    中文释义：“中国大陆”是一个地缘政治术语。
  - `zhs/Q4124.json`，`article[0]`：虽然中华民国政府未实际控制该领土，但仍在法理上主张拥有对该地区的主权
    中文释义：区分法理主张与未实际控制。

## Malawi（英文锚点 19088）

语言：en, sw；类型：country；状态：excerpt_screened_no_clear_difference。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Malaysia（英文锚点 3607937）

语言：en, id, ms, th, tl, vi, zhs, zht；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：面积分别见330803、330345、329847km²，人口资料也跨年份；范围与年代须核对。中文p0残留Infobox模板是清洗质量问题，不是观点。（置信标记：medium）
  - `id/Q748.json`，`article[0]`：Malaysia (Jawi: مليسيا) adalah sebuah negara federal yang terdiri dari tiga belas negeri (negara bagian) dan tiga wilayah federal di Asia Tenggara dengan luas 330.803 km persegi. I
    中文释义：。
  - `zhs/Q5025.json`，`article[1]`：马来西亚全国总面积共330,345平方公里，被南中国海分为东西两大部分：西半部的马来半岛分为十一个州及二个联邦直辖区吉隆坡和布城，常称为「西马」，北接泰国，南部隔著柔佛海峡，以新柔长堤和第二通道与新加坡连接；而东半部位于世界第三大岛婆罗洲的北部，分属沙巴和砂拉越两个邦及纳闽联邦直辖区，常被称为「东马」，南邻印度尼西亚的加里曼丹，而汶莱则与东马三面接壤。首都位
    中文释义：。
  - `tl/Q648.json`，`article[0]`：Ang Malaysia  /ma·ley·sya/ (Malay: Malaysia,  o ) ay isang bansang binubuo ng labintatlong mga estado at tatlong teritoryong federal sa Timog Silangang Asya na may kabuuang sukat n
    中文释义：。

- **摘录未见明确差异**：英泰导言均说明13州、3联邦直辖区及东西两部分，并区分吉隆坡与行政中心。所选范围未识别明确主权立场差异。人口及排名应另按年份核对，不拿排名不同直接判偏见。（置信标记：medium）
  - `en/Q3607937.json`，`article[0]`：thirteen states and three federal territories
    中文释义：13州和3联邦直辖区。
  - `th/Q1924.json`，`article[0]`：ประกอบด้วยรัฐ 13 รัฐ และดินแดนสหพันธ์ 3 ดินแดน
    中文释义：由13州和3联邦直辖区组成。

## Malaysia–Singapore border（英文锚点 3956978）

语言：en, ms；类型：territory_or_related_geography；状态：excerpt_screened_no_clear_difference。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Malaysia–Thailand border（英文锚点 3956827）

语言：en, ms, th；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：英文称陆地边界595公里；马来语称总长646公里，分551公里陆地及95公里河流。数字和计量分类明显不同，需要核对河界是否计入陆界、路线及来源；不能未经核查归因立场。（置信标记：high）
  - `en/Q3956827.json`，`article[0]`：a land boundary running for 595 km (370 mi)
    中文释义：陆地边界595公里。
  - `ms/Q88419.json`，`article[0]`：sejauh 551 km adalah sempadan darat manakala 95 km
    中文释义：551公里是陆地边界，另有95公里。

- **摘录未见明确差异**：两篇边界及条约叙述相容；泰历2452对应公历1909（减543），不能把两个数字当日期矛盾。也都描述95公里河流边界。（置信标记：medium）
  - `en/Q3956827.json`，`article[1]`：the 1909 treaty
    中文释义：1909年条约。
  - `th/Q277281.json`，`article[1]`：ปี พ.ศ. 2452
    中文释义：佛历2452年，即公历1909年。
  - `en/Q3956827.json`，`article[0]`：95 km stretch
    中文释义：95公里的一段。

## Maldives（英文锚点 19117）

语言：en, fr；类型：country；状态：excerpt_screened_no_clear_difference。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Maroni (river)（英文锚点 1849310）

语言：en, fr, nl；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：荷兰语明确609与612公里分别属苏里南/法国定义，英语细述源流争议，法语补充分段名称。不同长度可来自定义而非事实互斥。（置信标记：high）
  - `nl/Q89542.json`，`article[0]`：609 kilometer lang volgens de Surinaamse definitie en 612 kilometer lang volgens de Franse definitie
    中文释义：按苏里南定义609公里，法国定义612公里。。
  - `en/Q1849310.json`，`article[3]`：which of the two tributary rivers was the headwater, and thus the border.
    中文释义：哪条支流为源头并构成边界。。

## Marshall Islands（英文锚点 19147）

语言：en；类型：country；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Masoller（英文锚点 5476766）

语言：en, es, pt；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：村庄定位与争议背景互补。不能因西文导语只称乌拉圭地方就推断其全文否认边界争议。（置信标记：medium_preliminary）
  - `en/Q5476766.json`，`article[0]`：Masoller is a village or populated centre of the Rivera Department in northern Uruguay, next to the de facto border with Brazil, in an area where that border is disputed.
    中文释义：指出村庄处事实边界且边界有争议。。
  - `pt/Q4167752.json`，`article[0]`：Masoller é uma localidade uruguaia do departamento de Rivera, na zona norte do departamento, ao lado do Rincão de Artigas (Fronteira Brasil-Uruguai) Está situada a 48 km da cidade de Rivera, capital do departamento.
    中文释义：补充位于Rincão de Artigas旁与距Rivera48千米。。

## Matsu Islands（英文锚点 206515）

语言：en, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：两语均将马祖置于中华民国管辖，并给36岛；英文补充1949年连江县分治，中文第二段补充风景区和鸟类保护。属于历史与生态互补。（置信标记：medium）
  - `en/Q206515.json`，`article[1]`：before its effective partition in 1949 following the Chinese Civil War
    中文释义：1949年内战后实际分治之前。
  - `zhs/Q26131.json`，`article[1]`：2000年成立马祖列岛燕鸥保护区
    中文释义：2000年成立燕鸥保护区。

## Matthew Island and Hunter Island（英文锚点 1832217）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Mauritius（英文锚点 19201）

语言：en, fr；类型：country；状态：excerpt_screened_no_clear_difference。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Mayotte（英文锚点 19211）

语言：ar, en, fr；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：所阅阿文突出公投，法文突出制度身份，均可与法国行政管理事实并存；未据摘要推断缺失科摩罗主张。（置信标记：medium_preliminary）
  - `ar/Q24230.json`，`article[1]`：أغلبية سكانها من المسلمين، رفضوا الاستقلال في الاستفتاء الذي أدى لاستقلال الجزر الأخرى كدولة اتحادية.
    中文释义：居民拒绝独立的公投背景。。
  - `fr/Q33956.json`，`article[0]`：Mayotte (en mahorais : Maoré), officiellement nommée département de Mayotte, est à la fois une région insulaire française et un département de France d'outre-mer qui sont administrés dans le cadre d'une collectivité territoriale unique diri
    中文释义：说明法国大区/海外省及单一地方集体制度。。

## Mazraat Deir al-Ashayer（英文锚点 42492807）

语言：ar, en；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **实体范围／清洗风险**：英文题为Mazraat Deir al-Ashayer、称黎巴嫩扎赫勒区村庄；阿语题为Deir al-Ashayer、称叙利亚大马士革乡村省Qudsaya村庄。可能是相邻村庄/命名范围混配，不能先当成两国对同一村的立场对立；须核实坐标与跨语言链接。（置信标记：high）
  - `en/Q42492807.json`，`article[0]`：is a lebanese village in the Zahle District  of the Beqaa Governorate.
    中文释义：是黎巴嫩贝卡省扎赫勒区村庄。。
  - `ar/Q1655593.json`，`article[0]`：دير العشائر قرية في منطقة قدسيا ( حديثا ) في محافظة ريف دمشق.
    中文释义：Deir al-Ashayer是大马士革乡村省Qudsaya地区（近期划分）的村庄。。

## Mbamba Bay（英文锚点 14298100）

语言：en, sw；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英语给湖岸位置及潜在港口，斯瓦希里语给Nyasa县行政中心；是功能/行政细节互补，无明确归属冲突。（置信标记：medium）
  - `en/Q14298100.json`，`article[0]`：a town in western Tanzania
    中文释义：坦桑尼亚西部城镇。。
  - `sw/Q22116.json`，`article[0]`：makao makuu ya Wilaya ya Nyasa
    中文释义：Nyasa县行政中心。。

## Mekong（英文锚点 69147）

语言：en, lo, th；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英语摘录概述跨国流域及水坝生态问题；泰语摘录细化流经泰国地点和泰老界河段。地方尺度与流域尺度可互补，未对两篇全文作遗漏判断。（置信标记：medium）
  - `en/Q69147.json`，`article[0]`：a trans-boundary river in East Asia and Southeast Asia
    中文释义：东亚与东南亚的跨境河流。
  - `th/Q13797.json`，`article[1]`：ไหลผ่าน 6 ประเทศ คือ จีน พม่า ไทย ลาว กัมพูชา และเวียดนาม
    中文释义：流经六国：中国、缅甸、泰国、老挝、柬埔寨、越南。

## Melilla（英文锚点 20226）

语言：ar, en, es；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：阿语承认西班牙主权，但同时使用摩洛哥要求“收回”及“城市位于摩洛哥”的措辞；英西语以西班牙自治市、与摩洛哥接壤定义。属于归属框架和恢复性措辞差异，而不是简单的实际管理事实冲突。（置信标记：high）
  - `ar/Q50348.json`，`article[0]`：تحت السيادة الإسبانية تطالب المغرب بإستعادتها كجزء من أراضيها
    中文释义：处于西班牙主权下，摩洛哥要求将其收回为本国领土的一部分。
  - `es/Q5982205.json`，`article[0]`：Melilla es una ciudad autónoma española
    中文释义：梅利利亚是西班牙自治市。

## Migingo Island（英文锚点 22297262）

语言：en, sw；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英语称肯尼亚岛屿并记录争端，斯瓦希里语补充2009测量和1926以来地图。所审证据对肯尼亚归属方向一致，区别为证据详略。（置信标记：medium）
  - `en/Q22297262.json`，`article[0]`：in Kenya on Lake Victoria
    中文释义：肯尼亚的一座岛。。
  - `sw/Q34940.json`，`article[1]`：Tangu mwaka 1926
    中文释义：自1926年以来。。

## Minerva Reefs（英文锚点 1608314）

语言：en, to；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：英语导言介绍斐济与汤加之间的争议；汤加语摘录直接称自1972年属于汤加王国。只是所引文本的归属陈述差异，不证明当前法律归属。（置信标记：medium）
  - `en/Q1608314.json`，`article[0]`：a territorial dispute between Fiji and Tonga
    中文释义：斐济与汤加之间的领土争议。
  - `to/Q2975.json`，`article[1]`：Ko e konga ia ʻo e puleʻanga ʻo Tonga mei he 1972
    中文释义：自1972年以来属于汤加王国的一部分。

## Mongolia（英文锚点 19271）

语言：en, mn, zht；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **实体范围／清洗风险**：蒙古语Q4681为列举蒙古国、内蒙古、外蒙古、蒙古人民共和国等的消歧/列表，而英语是蒙古国正文；不能把内容稀疏当立场遗漏。（置信标记：medium）
  - `mn/Q4681.json`，`article[0]`：Монгол Улс, 1992 оноос хойш Монгол Улсын нэр /  Өвөр Монгол, Бүгд Найрамдах Хятад Ард Улсын өөртөө засах засаг захиргааны нэгж /  Ар Монгол, Монголын түүхэн нутаг дэвсгэр /  Бүгд Найрамд
    中文释义：。
  - `en/Q19271.json`，`article[0]`：Mongolia () is a landlocked country in East Asia, bordered by Russia to the north and China to the south. It covers an area of , with a population of just 3.3 million, making it th
    中文释义：。

- **事实互补**：两篇都描述蒙古国及乌兰巴托、低人口密度；中文所引开头进一步给出21省及1市。英语“无封闭海岸的最大内陆国”和中文“第二大内陆国”限定不同，不作为直接矛盾。（置信标记：medium）
  - `en/Q19271.json`，`article[0]`：the world's largest landlocked country that does not border a closed sea
    中文释义：世界上不濒临封闭海域的最大内陆国。
  - `zht/Q5308.json`，`article[0]`：蒙古國由行政區劃分為21個省和一個直轄市兼首都的烏蘭巴託所構成
    中文释义：蒙古国行政区包括21省和作为首都的乌兰巴托市。

## Mont Blanc（英文锚点 44768）

语言：en, fr, it；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英法均说明法意边界位置，英语明确峰顶归属长期争议；意语同时使用两国最高峰及某些地理约定下欧洲最高的称谓，法语按计入高加索的口径讨论排名。地理排名需保留范围定义，不判为简单数字冲突。（置信标记：medium）
  - `en/Q44768.json`，`article[1]`：It gives its name to the Mont Blanc massif, which straddles parts of France, Italy and Switzerland. Mont Blanc's summit lies on the watershed line between the valleys of Ferret and Veny in Italy, and the valleys of Montjoie, and Arve in France. Ownership of the summit area has long been disputed between France and Italy.
    中文释义：峰顶在分水岭，所有权长期存在法意争议。。
  - `it/Q19908.json`，`article[0]`：Il Monte Bianco (Mont Blanc in francese e in arpitano), con un'altitudine di  (secondo l'ultima misura ufficiale effettuata il 3 dicembre 2017), è la montagna più alta delle Alpi, d'Italia, di Francia e anche d'Europa, secondo alcune convenzioni geografiche, da cui i soprannomi di tetto d'Europa e di Re delle Alpi, condividendo assieme al monte Elbrus nel Caucaso un posto tra le cosiddet
    中文释义：按某些地理约定是欧洲最高山，并称两国最高峰。。
  - `fr/Q6845.json`，`article[0]`：Le mont Blanc (en ), dans le massif du Mont-Blanc, est le point culminant de la chaîne des Alpes. Avec une altitude de , il est le plus haut sommet d'Europe occidentale et le sixième sur le plan continental en prenant en compte les montagnes du Caucase, dont l'Elbrouz () est le plus haut sommet. Il se situe sur la frontière fran
    中文释义：西欧最高，若计入高加索则大陆排名不同。。

## Montenegro（英文锚点 20760）

语言：en, hr, sr；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：英/克语边界列表列科索沃；塞语导语列与阿尔巴尼亚接壤，历史段还将三公国称作塞尔维亚公国，而英语只称三公国。须区分科索沃口径及民族历史框架，不能仅凭边界名单作主权裁定。（置信标记：medium）
  - `en/Q20760.json`，`article[0]`：Kosovo to the east
    中文释义：东邻科索沃。。
  - `sr/Q1691.json`，`article[0]`：Албанијом на југу
    中文释义：南邻阿尔巴尼亚。。
  - `sr/Q1691.json`，`article[1]`：три српске кнежевине
    中文释义：三个塞尔维亚公国。。

## Morocco（英文锚点 19291）

语言：ar, en, es；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：首段南界描述将西撒哈拉作为单独争议地域的显著程度不同，可能反映领土框架差异；需保留整篇主张归因再作进一步判断。（置信标记：medium_preliminary）
  - `ar/Q293523.json`，`article[0]`：وموريتانيا جنوبًا؛ وفي الشريط البحري الضيق الفاصل بين المغرب وإسبانيا توجَد مكتنفات متنازع عليه
    中文释义：南邻写作毛里塔尼亚。。
  - `en/Q19291.json`，`article[0]`：disputed territory of Western Sahara to the south. Mauritania lies to the south of Western Sahara. Morocco also claims the Spanish exclaves of Ceuta, Melilla and Peñón de
    中文释义：南邻先列有争议西撒哈拉，再说明毛里塔尼亚在其南。。

## Mount Everest（英文锚点 42179）

语言：en, ne, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：尼语给出2020前后高度变化并定位尼泊尔地方行政区，中文明确中尼边界及南北坡，英语亦称国界越过峰顶；导语地方定位不等于排他主权否认。（置信标记：medium）
  - `ne/Q1116.json`，`article[0]`：सगरमाथा संसारको सबैभन्दा अग्लो चुचुरो हो । यसको उचाई समुन्द्र सतहबाट ८,८४८.८६ मिटर (२९,०३१.६९ फिट) छ । / सन् ८ डिसेम्बर २०२० अगाडी यसको उचाई समुन्द्र सतहबाट ८,८४८ मिटर मानिएको थियो ।
    中文释义：。
  - `zht/Q15492.json`，`article[1]`：珠穆朗瑪峯位於中華人民共和國（西藏自治區）與尼泊爾薩加瑪塔專區的交界處的喜馬拉雅山脈中段，北緯27°59′15.85″，東經86°55′39.51″，北坡在西藏定日縣境內，南坡在尼泊爾索盧坤布縣境內。
    中文释义：。

## Moyo District（英文锚点 1786757）

语言：en, sw；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：斯瓦希里语给人口352900，英文给邻接南苏丹各州及道路关系；均定义为乌干达北部地区，人口年份未在摘录给出，不据此作冲突。（置信标记：medium）
  - `sw/Q41082.json`，`article[1]`：Idadi ya wakazi wake ni takriban 352,900.
    中文释义：人口约352900。。
  - `en/Q1786757.json`，`article[1]`：South Sudan to the north and east
    中文释义：北面和东面为南苏丹。

## Myanmar（英文锚点 19457）

语言：bn, en, my, th, zht；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英、缅、泰摘录共同描述相同邻国与早期Pyu/Mon历史；繁中补充首都迁移与单一制的解释。数字差异需时间和口径对齐，摘要没有证明互斥的领土立场。（置信标记：medium）
  - `en/Q19457.json`，`article[0]`：also known as Burma (the official name until 1989)
    中文释义：又名Burma，该名在1989年前为官方名称。
  - `zht/Q26508.json`，`article[0]`：首都為奈比多（2005年以前設於最大城市仰光）
    中文释义：首都迁移时间信息。

- **事实互补**：人口和主要地理信息基本相合；孟加拉语摘录解释1989年更名及反对意见，补充政治命名背景，不足以判定与英语全文立场相反。（置信标记：medium）
  - `en/Q19457.json`，`article[0]`：also known as Burma (the official name until 1989)
    中文释义：亦称Burma，至1989年前为正式名称。
  - `bn/Q8847.json`，`article[1]`：তবে গণতান্ত্রিক দলগুলোর অনেক অনুসারীই এই নামকরণের বিপক্ষে।
    中文释义：不过许多民主派支持者反对此次命名。

## Mykolaiv Oblast（英文锚点 494928）

语言：en, ru, uk；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英语和乌语所审段落均记载2022侵入与收复，乌语给3%与11月10日；俄语导语侧重行政地理。不能由俄语摘要没有战事就断定全文遗漏或支持一方。（置信标记：medium）
  - `en/Q494928.json`，`article[1]`：During the 2022 Russian invasion of Ukraine
    中文释义：2022年俄罗斯入侵乌克兰期间。。
  - `uk/Q3173.json`，`article[1]`：близько 3% області окупували
    中文释义：约占领该州3%。。

## Naf River（英文锚点 1946736）

语言：bn, en, my；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英语、缅甸语明确边界河流属性；孟加拉语所摘导言提供长度、平均宽度与本国河流登记，属于地理尺度和细节互补，未据此判断主权偏差。（置信标记：medium）
  - `en/Q1946736.json`，`article[0]`：marking the border of southeastern Bangladesh and northwestern Myanmar
    中文释义：标示孟加拉国东南部与缅甸西北部边界。
  - `bn/Q63990.json`，`article[0]`：নদীটির দৈর্ঘ্য ৬৩ কিলোমিটার, গড় প্রস্থ ১৩৬৪ মিটার
    中文释义：河长63公里、平均宽1364米。

## Nakhchivan Autonomous Republic（英文锚点 385358）

语言：az, en, hy；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：阿塞拜疆语以阿塞拜疆境内自治国家定义，英语以阿塞拜疆内陆飞地自治共和国定义；亚美尼亚语历史段直接称其已被去亚美尼亚化且“非法并入阿塞拜疆”。这是明确法律评价措辞差异，不代表本审计裁定其合法性。（置信标记：high）
  - `az/Q1107.json`，`article[0]`：Azərbaycan Respublikasının tərkibində muxtar dövlət.
    中文释义：阿塞拜疆共和国组成内的自治国家。。
  - `en/Q385358.json`，`article[0]`：The Nakhchivan Autonomous Republic (, ), is a landlocked exclave of the Republic of Azerbaijan. The region covers  with a population of 459,600. It is bordered by Armenia
    中文释义：阿塞拜疆共和国的内陆飞地自治共和国。。
  - `hy/Q5479.json`，`article[1]`：Այժմ Նախիջևանը հայաթափված է և ապօրինաբար բռնակցված Ադրբեջանի Հանրապետությանը։
    中文释义：如今纳希切万被去亚美尼亚化，并被非法并入阿塞拜疆共和国。。

## Namwan Assigned Tract（英文锚点 67988267）

语言：en, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：签署与生效时间及永租废除互补，不是1960/1961自相矛盾。（置信标记：medium_preliminary）
  - `en/Q67988267.json`，`article[0]`：1897, and legally became the territory of Burma in 1961.
    中文释义：1897永租、1961合法成为缅甸领土。。
  - `zht/Q7527606.json`，`article[0]`：1960年中華人民共和國與緬甸聯邦簽訂《中華人民共和國和緬甸聯邦邊界條約》，廢除“永租”關係，1961年條約生效後正式成爲緬甸領土。
    中文释义：补充1960签约、1961生效并废永租。。

## Navassa Island（英文锚点 21312）

语言：en, ht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **证据不足**：海地克里奥尔语正文仅短导语加论文外链，英语完整介绍双方声索与美国管理；不能仅凭海地语未展开来判断偏向或否认美国管理。（置信标记：medium）
  - `ht/Q86902.json`，`article[0]`：Lanavaz se yon ti zile ki pa abite nan lanmè Karayib la.
    中文释义：。
  - `en/Q21312.json`，`article[0]`：Navassa Island (; ; , sometimes ) is a small uninhabited island in the Caribbean Sea. Located northeast of Jamaica, south of Cuba, and  west of Jérémie on the Tiburon Peninsula of 
    中文释义：。

## Nelang（英文锚点 39990004）

语言：en, hi, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：印地语直接描述印度村落，英语并列印度行政归属及中国声索，中文用印度实控/中国认为属札达县。重点是事实控制和声索归因区分，不把不同名称自动当不同实体。（置信标记：medium）
  - `hi/Q1397601.json`，`article[0]`：नेलांग (Nelang) भारत के उत्तराखण्ड राज्य के उत्तरकाशी ज़िले में स्थित एक छोटा सा गाँव है। यह तिब्बत की सीमा के समीप है। नेलांग घाटी एक पर्यटन केन्द्र भी है। यह ग्राम और पड़ोस के धू
    中文释义：。
  - `en/Q39990004.json`，`article[0]`：Nelang or Nilang is a river valley of the Himalayas, containing a small eponymous village, in the Uttarkashi District of the state of Uttarakhand, India. It is close to the dispute
    中文释义：。
  - `zhs/Q3551130.json`，`article[1]`：领土争议  / 中国认为，位于甲扎岗噶河流域的桑、葱莎、波林三多地区是中国领土，属于西藏阿里地区札达县托林镇波林村管辖。该地区面积约1451平方公里，目前被印度实际控制。
    中文释义：。

## Nepal（英文锚点 171166）

语言：en, hi, ne, zht；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：正式国名“现称/曾称”存在时间或规范用名差异，须查归档修订与国名政策；不据此推断立场偏差。（置信标记：medium_preliminary）
  - `en/Q171166.json`，`article[0]`：Federal Democratic Republic of Nepal (), is a landlocked country in South Asia. 
    中文释义：英语仍以尼泊尔联邦民主共和国为正式名。。
  - `zht/Q3298.json`，`article[0]`：曾稱尼泊爾聯邦民主共和國（），是南亞喜馬拉雅山脈地區的一個內陸國家，北與中國相接，其餘三面與印度爲鄰，與孟加拉國僅隔27公里的走廊。尼泊爾的土地面積為
    中文释义：中文以曾称联邦民主共和国表述。。

## New Caledonia（英文锚点 21342）

语言：en, fr；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：两篇都说明法国所属特殊集体地位；法语摘录补充自治、自决和去殖民化进程，和英语摘录的群岛地理、人口描述可互补。不能声称英语全文没有自决信息。（置信标记：medium）
  - `en/Q21342.json`，`article[0]`：a sui generis collectivity of overseas France
    中文释义：法国海外的特殊地位集体。
  - `fr/Q573024.json`，`article[1]`：un degré fort d'autonomie et le droit à l'autodétermination
    中文释义：高度自治及自决权。

## Nicaragua（英文锚点 21362）

语言：en, es；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：西语补充15个省、2个自治区和海上邻国；英语给莫斯基托海岸历史。可互补，未在所审片段发现归属矛盾。（置信标记：medium）
  - `es/Q1982.json`，`article[0]`：quince departamentos y dos regiones autónomas
    中文释义：15个省及两个自治区。。
  - `en/Q21362.json`，`article[1]`：The Mosquito Coast followed a different historical path
    中文释义：莫斯基托海岸走过不同历史路径。。

## Nigeria（英文锚点 21383）

语言：en, fr；类型：country；状态：excerpt_screened_no_clear_difference。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Noktundo（英文锚点 27603039）

语言：en, ko, ru；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英文说明由岛变半岛并给早期女真/朝鲜战争历史；韩语补充朝鲜已放弃主权、实际为俄罗斯领土，以及近代聚落人口，属于控制现状与历史互补。（置信标记：medium）
  - `en/Q27603039.json`，`article[0]`：is a former island (currently a peninsula)
    中文释义：昔日为岛、如今为半岛。
  - `ko/Q68034.json`，`article[0]`：조선민주주의인민공화국은 영유권을 포기했으며 사실상 러시아 연방의 영토이다.
    中文释义：朝鲜已放弃主权，事实上属俄罗斯联邦领土。。

- **措辞／归因／命名差异**：15世纪历史归属及1587年行动主体存在明确文本差异：英语称女真所有且朝鲜军队入侵；俄语称朝鲜王朝所有并称驻军。只确认来源陈述不同，不替外部历史考证裁定真假。（置信标记：high）
  - `en/Q27603039.json`，`article[1]`：In the 15th century, Noktundo belonged to the Jurchen.
    中文释义：15世纪鹿屯岛属于女真。
  - `en/Q27603039.json`，`article[1]`：the invading army from Yi Sun-sin
    中文释义：李舜臣的入侵军队。
  - `ru/Q1859845.json`，`article[1]`：Ноктундо принадлежал корейской династии Чосон с XV века.
    中文释义：鹿屯岛自15世纪属于朝鲜王朝。
  - `ru/Q1859845.json`，`article[1]`：местным гарнизоном под командованием Ли Сунсина
    中文释义：李舜臣指挥的当地驻军。

## North Borneo（英文锚点 390647）

语言：en, ms；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：马语精确列1882–1946保护地、1946–1963殖民地及1963入马来西亚；英语补充更早特许权起源。历史阶段互补。（置信标记：medium）
  - `ms/Q48515.json`，`article[0]`：Borneo Utara (North Borneo) merupakan satu negeri naungan British di bawah Syarikat Berpiagam Borneo Utara British pada 1882-1946, dan kemudian menjadi tanah jajahan mahkota Britis
    中文释义：。
  - `en/Q390647.json`，`article[0]`：North Borneo (usually known as British North Borneo, also known as the State of North Borneo) was a British protectorate in the northern part of the island of Borneo, which is pres
    中文释义：。

## North Korea（英文锚点 21255）

语言：en, ja, ko, zhs, zht；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英中均描述半岛分裂与边界，韩文给2023年人口及文化语，中文详列1950战争经过。这是覆盖与命名差异，不能把中文“抗美援朝”单独等同全文否认北方进攻，后文明确写“发动对大韩民国的进攻”。（置信标记：medium）
  - `en/Q21255.json`，`article[0]`：both countries claim the entirety of the Korean Peninsula.
    中文释义：双方均声索整个朝鲜半岛。。
  - `zhs/Q1698.json`，`article[11]`：发动对大韩民国的进攻
    中文释义：发动对韩国的进攻。。
  - `ko/Q495.json`，`article[0]`：2023년 기준으로 약 2,563만 명
    中文释义：2023年约2563万人。。

- **数字／时间候选差异**：英语区分1945年38线分区与1953年停战；日语摘录把1953年以来的分界概括为38线。标记历史阶段/地理精确性候选供核查，不凭摘录作外部历史裁决。（置信标记：medium）
  - `en/Q21255.json`，`article[1]`：In 1945, after the Japanese surrender at the end of World War II, Korea was divided into two zones along the 38th parallel
    中文释义：1945年日本投降后朝鲜沿38线划成两区。
  - `ja/Q907180.json`，`article[1]`：1953年7月に朝鮮戦争休戦協定が締結されて以来、朝鮮半島は北緯38度線を境に
    中文释义：1953年7月朝鲜停战协定签订以来，朝鲜半岛以北纬38度线为界。

## Ntem River（英文锚点 7705513）

语言：en, es, fr；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：西语强调末段及河口构成赤道几内亚与喀麦隆边界，法语补充加蓬源头并概称三国边界。应检查河段范围后再判断表述精确性，不把部分河段对整体河流的描述直接判为矛盾；英语页为空。（置信标记：medium）
  - `es/Q5004297.json`，`article[0]`：El río Campo (también llamado río Ntem) es un río en la parte continental norte del país africano de Guinea Ecuatorial. Su tramo final, incluyendo su desembocadura en el golfo de Biafra, forma parte de la frontera con Camerún.
    中文释义：Campo/Ntem末段及河口构成赤道几内亚—喀麦隆边界。。
  - `fr/Q6041940.json`，`article[1]`：Prenant sa source dans la province gabonaise du Woleu-Ntem, il se jette dans l'Océan Atlantique au Cameroun, au sud de la localité de Campo.
    中文释义：发源于加蓬Woleu-Ntem，流入喀麦隆大西洋。。

## Okpara River（英文锚点 35673421）

语言：en, fr；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英文说明河流构成贝宁—尼日利亚边界且沿岸村庄有争议；法语补充源头和流域信息。仅属首段/摘要覆盖范围差异，不证明法语全文否认争议。（置信标记：medium）
  - `en/Q35673421.json`，`article[0]`：Several villages along the river are disputed between Benin and Nigeria.
    中文释义：沿河多个村庄为贝宁和尼日利亚争议对象。。
  - `fr/Q9786949.json`，`article[1]`：L'Okpara prend sa source à Darou Kparou.
    中文释义：Okpara源于Darou Kparou。。

## Olivenza（英文锚点 305819）

语言：en, es, pt；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：葡语导语突出法理声索，西语突出西班牙行政归属，英文补充历史；可核实为叙述焦点差异，非三个文本都在断言相同维度的排他控制权。（置信标记：medium_preliminary）
  - `es/Q88865.json`，`article[0]`：Olivenza es una localidad y municipio español situado en la parte occidental de la provincia de Badajoz, en la comunidad autónoma de Extremadura. Perteneciente a la comarca de los Llanos de Olivenza —
    中文释义：直接称西班牙地方及市镇。。
  - `pt/Q14491.json`，`article[0]`：Reivindicado de jure por Portugal, o município integra atualmente a província de Badajoz da comunidade autónoma espanhola da Estremadura. É a capital da comarca espanhola de Llanos de Olivenza (), também conhecida como C
    中文释义：明确葡萄牙法理声索，同时承认目前纳入西班牙行政区。。
  - `en/Q305819.json`，`article[1]`：The town of Olivença was under Portuguese sovereignty continuously between 1297 (Treaty of Alcañices) and 1801, when it was occupied by Spain during the War of the Oranges and ceded that year under the Treaty of Badajoz.
    中文释义：补充1297—1801葡萄牙主权与战争后转让历史。。

## Oman（英文锚点 22316）

语言：ar, en；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：同一海域在阿语摘录称“阿拉伯湾”，英文称“波斯湾”。这是政治地名选择候选，不等同于阿曼领土控制事实冲突。（置信标记：high）
  - `ar/Q1349.json`，`article[1]`：والخليج العربي
    中文释义：以及阿拉伯湾。
  - `en/Q22316.json`，`article[0]`：the Persian Gulf
    中文释义：波斯湾。

## Outer Mongolia（英文锚点 147471）

语言：en, mn, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：同一历史地理名称的时期与范围描述互补：蒙古语追溯术语早期使用，中文区分清末通称与有时包含唐努乌梁海。不要把历史范围不同直接当成当前国家边界冲突。（置信标记：medium）
  - `en/Q147471.json`，`article[0]`：from 1691 to 1911
    中文释义：从1691年至1911年。
  - `mn/Q23562.json`，`article[1]`：нэр томьёо 1632 оны үед анхлан гарчээ
    中文释义：该术语约在1632年首次出现。
  - `zht/Q5317.json`，`article[1]`：範圍有時亦含包括科布多和內屬之唐努烏梁海
    中文释义：范围有时也包括科布多和内属的唐努乌梁海。

## Paektu Mountain（英文锚点 182248）

语言：en, ko, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：中文导语强调1962割让后成为界山；韩语导语强调民族圣山；英语导语以跨境火山地理为主。是历史/文化重点差异，并存在“长白山”山系与主峰的范围区别，不能简单比面积。（置信标记：medium）
  - `zhs/Q22168.json`，`article[0]`：长白山（），古名不咸山（或为白罗聂·显干之音译）、太白山，在朝鲜半岛称白头山（），1962年因《中朝边界条约》割让给朝鲜部分后成为中华人民共和国和朝鲜民主主义人民共和国边境的界山。广义的长白山是指一条西南－东北走向绵延上千公里的一系列山脉，横亘于中华人民共和国吉林、辽宁、黑龙江三省的东部及朝鲜民主主义人民共和国两江道交界处。狭义上的长白山则单指其主峰白头峰，
    中文释义：。
  - `ko/Q126879.json`，`article[0]`：백두산(白頭山)은 조중 국경(조선민주주의인민공화국-중국 국경)에 있는 화산이다. 중국에서는 장백산()이라 불린다. 한민족에게는 민족의 영산으로 숭앙되어 왔으며, 환웅이 무리 3,000명을 이끌고 제사를 열었다는 태백산과 동일시되기도 한다.
    中文释义：。
  - `en/Q182248.json`，`article[0]`：Paektu Mountain or Baekdu Mountain is an active stratovolcano on the Chinese–North Korean border. It is called in Chinese Changbai Mountain and in Manchu Golmin Šanggiyan Alin. At 
    中文释义：。

## Pakistan（英文锚点 23235）

语言：en, hi, ur, zht；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：英语接近2.43亿、乌尔都语约2.42亿、印地语2.1亿；中文信息框明确2022年242923845并残留模板。需按年份/估计来源核对，不能把人口更新差异当作立场偏差。（置信标记：medium）
  - `en/Q23235.json`，`article[0]`：almost 243 million people
    中文释义：人口接近2.43亿。。
  - `hi/Q877.json`，`article[0]`：21 करोड़ की आबादी
    中文释义：人口2.1亿。。
  - `ur/Q608.json`，`article[0]`：تقریباً 242 ملین
    中文释义：人口约2.42亿。。
  - `zht/Q9268.json`，`article[1]`：|人口估計年份 = 2022年 / |總人口數據 = 242,923,845
    中文释义：信息框中人口估计年份2022、总人口242923845。。

## Pamir Mountains（英文锚点 498462）

语言：en, tg, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：中文以高原及分区管辖、2002边界安排展开；英语以山系位置和丝路展开。地理概念范围并非完全一致，不能比较段落长度即推断立场。（置信标记：medium）
  - `en/Q498462.json`，`article[0]`：a mountain range between Central Asia and Pakistan
    中文释义：中亚与巴基斯坦之间的山系。。
  - `zhs/Q36833.json`，`article[0]`：帕米尔高原中西部为塔吉克斯坦管辖，东部为中国管辖，南部瓦罕帕米尔为阿富汗管辖。
    中文释义：给出三国分区管辖。。

- **事实互补**：英语摘录说明跨国山系范围；塔吉克语摘录给索莫尼峰高度及历史名称，属于地理和命名史互补。不能从导言未列某国就判断否认其领土。（置信标记：medium）
  - `en/Q498462.json`，`article[1]`：Much of the Pamir Mountains lie in the Gorno-Badakhshan Province of Tajikistan
    中文释义：帕米尔山系大部位于塔吉克斯坦山地巴达赫尚。
  - `tg/Q11329.json`，`article[1]`：қуллаи Исмоили Сомонӣ бо баландии 7495 м
    中文释义：索莫尼峰高7495米。

## Paracel Islands（英文锚点 23410）

语言：en, vi, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：越文首段明确中/台/越三方主权争议与中国实际控制，中文第二段给三方行政区划及其他方未实控岛屿，英文首先标为争议群岛。控制方基本一致，信息在声索、行政及地理上互补。（置信标记：medium）
  - `vi/Q1424.json`，`article[0]`：là đối tượng tranh chấp chủ quyền giữa Trung Quốc, Đài Loan và Việt Nam.
    中文释义：是中国、台湾、越南之间的主权争议对象。。
  - `zhs/Q70797.json`，`article[1]`：越南将西沙群岛划归岘港市黄沙岛县管辖，中华民国政府将其置于高雄辖下，但均没有实际控制西沙群岛中的任何一个岛屿。
    中文释义：列出声索方行政安排，区分实际控制。。

## Parangcho（英文锚点 30365761）

语言：en, ko, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：韩语称2006年由海洋水产部命名波浪礁，中文称中国1999等调查并命名丁岩；为各方命名行动的互补历史，不是同事件日期冲突。（置信标记：medium）
  - `ko/Q720141.json`，`article[0]`：파랑초(波浪礁) 또는 딩옌자오(; 줄여서 딩옌)는 이어도 북동쪽 4.5 km 지점에 있는 수심 24.6m의 수중 암초다. 대한민국 해양수산부에 의해 2006년 12월 29일 파랑초로 명명되었다.
    中文释义：。
  - `zhs/Q418347.json`，`article[0]`：丁岩礁（），是东中国海上的一个暗礁，在苏岩礁东北方向4.5公里。该暗礁长372米，宽169米，面积5.28万平方米。 / 中国于1999年、2001年、2002年对该暗礁进行调查，并将其命名为“丁岩”。中国海警船在丁岩礁附近海域常态巡逻。
    中文释义：。

## Pedra Branca dispute（英文锚点 17586244）

语言：en, ms；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：马来语出现“我们”的叙述位置，较英文第三人称争端叙述更明确地以马方为参照；为具体文本措辞候选，不推广为整个马来语维基偏差。（置信标记：medium_preliminary）
  - `ms/Q105701.json`，`article[0]`：perairan wilayah kita. Jarak Pulau Batu Puteh adalah lebih jauh dari titik terdekat Singapura (Changi) ia
    中文释义：使用“我们的领海”第一人称。。
  - `en/Q17586244.json`，`article[0]`：The Pedra Branca dispute was a territorial dispute between Singapore and Malaysia over several islets at the eastern entrance to the Singapore Strait, namely Pedra Branca (previously called Pulau Batu Puteh and now Batu Puteh by Malaysia), Middle Rocks and Sou
    中文释义：以新马争端及国际法院解决来叙述。。

## Penghu（英文锚点 206519）

语言：en, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：均描述90个岛屿及台湾辖下县；中文更明确ROC台湾省行政层级与距离，英语补充地理概述，不足以认定相互排斥归属。（置信标记：medium）
  - `en/Q206519.json`，`article[0]`：The Penghu (, Hokkien POJ: Phîⁿ-ô͘  or Phêⁿ-ô͘ ) or Pescadores Islands are an archipelago of 90 islands and islets in the Taiwan Strait, located approximately  west from the main i
    中文释义：。
  - `zhs/Q610380.json`，`article[0]`：澎湖群岛，亦称澎湖列岛，是位于台湾海峡上的一组群岛，东距台湾本岛约50公里，西离中国大陆约140公里，由90个大小岛屿组成，总面积约为128平方公里，元世祖（1281年）正式收入中国版图，隶属福建同安，现全境均属中华民国台湾省澎湖县管辖，为中华民国实际管辖区域第一大离岛群。16世纪时葡萄牙殖民者来到东方，发现澎湖海域鱼产丰富，在岛上住著许多渔民，因此称呼澎湖
    中文释义：。

## People's Republic of China（英文锚点 33151668）

语言：dz, en, hi, ja, ko, ky, ms, ru, tg, tl, vi, zhs, zht；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：印地语仍称人口世界第一，俄语明确2022年后人口第二、在印度之后；属于数据更新/统计日期待核对候选。英文归档仅剩分类行，不能解释为英语没有相关内容。中文23省/34行政区与越南语22省行使管辖权，应区分主张与实际管理口径。（置信标记：high）
  - `hi/Q2220.json`，`article[0]`：चीन (),आधिकारिक रूप से चीनी जनवादी गणराज्य (), पूर्वी एशिया का एक देश है। यह विश्व का सर्वाधिक जनसंख्या वाला देश है, जिसकी जनसंख्या 1.4 अरब से अधिक है, जो भारत से थोड़ा आगे है। चीन पाँच समय क्षेत्रों के बराबर फैला हुआ है और 14 देशों की भूमि से सीमाएँ हैं, विश्व के किसी भी देश से 
    中文释义：称中国人口为世界第一，稍高于印度。。
  - `ru/Q1134.json`，`article[0]`：Кита́й (), официальное название — Кита́йская Наро́дная Респу́блика (сокр. КНР), () — государство в Восточной Азии. Занимает третье место в мире по территории (9 598 962 км2), уступая России и Канаде, а по численности сократившегося в 2022 году населения — 1 411 750 000 жителей (без Тайваня, Гонконга и Макао) — второе после Индии. Уровень урбанизации равен 65 %. Внутренняя миграция направлена из экономически отстающих
    中文释义：称2022年人口减少后世界第二、在印度之后。。
  - `zhs/Q118.json`，`article[0]`：其中包括23个省份
    中文释义：行政区包括23省。。
  - `vi/Q1529.json`，`article[0]`：Chính phủ Trung Quốc thi hành quyền tài phán tại 22 tỉnh
    中文释义：中国政府对22省行使管辖权。。

- **证据不足**：英语PRC归档只有分类，不能把与其他语言正文的长度差异解释成立场遗漏。以下比较仅涉及有正文的本族语言版本。（置信标记：medium）
  - `en/Q33151668.json`，`article[0]`：States and territories established in 1949
    中文释义：1949年建立的国家和领土。

- **措辞／归因／命名差异**：吉尔吉斯语地理介绍将台湾与海南并列为沿岸大岛；他加禄语将台湾主权明确表述为声索。这是陈述方式和归因差别，需要考虑地理/行政表述语境。（置信标记：medium）
  - `ky/Q1962.json`，`article[0]`：алардын ирилери: Тайвань, Хайнань
    中文释义：其中较大的岛屿为台湾、海南。
  - `tl/Q1748.json`，`article[0]`：inaangkin din nito ang soberanya ng Taiwan
    中文释义：它也声索台湾的主权。

## Philippines（英文锚点 23440）

语言：en, ms, tl, vi, zhs, zht；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：英、马来、塔加洛语使用7641岛，中文约7000；人口也含2015与2021等不同日期。是粒度/统计期差异候选，非立场证据。越南语p0残留模板应作为清洗问题。（置信标记：medium）
  - `en/Q23440.json`，`article[0]`：7,641 islands
    中文释义：7641座岛屿。。
  - `zhs/Q2134.json`，`article[0]`：菲律宾群岛由约7000个岛屿组成
    中文释义：约7000座岛。。
  - `vi/Q35811.json`，`article[0]`：{{Tóm tắt về quốc gia
    中文释义：原文残留国家信息模板。。

## Portugal（英文锚点 23033）

语言：en, es, pt；类型：country；状态：excerpt_screened_no_clear_difference。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Pratas Island（英文锚点 410487）

语言：en, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：中英均给台湾/中华民国管辖，英文补充邻近海底地形，中文补充历代地名、渔村和庙宇。没有据摘要观察到控制方冲突。（置信标记：medium）
  - `en/Q410487.json`，`article[1]`：Pratas Atoll, North Vereker Bank and South Vereker Bank
    中文释义：东沙环礁、北卫滩、南卫滩。
  - `zhs/Q392189.json`，`article[0]`：有清朝渔民建造的渔村和庙宇，如大王庙
    中文释义：补充渔村与庙宇历史。

## Preah Vihear Temple（英文锚点 2367753）

语言：en, km, th；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英语与泰语都明示1962国际法院认定寺庙属柬埔寨，泰语补充2008世界遗产；未观察到两者在该核心命题相反，不能假定泰语必然反对。（置信标记：medium）
  - `en/Q2367753.json`，`article[0]`：Preah Vihear Temple (Khmer: ប្រាសាទព្រះវិហារ Prasat Preah Vihear) is an ancient Khmer temple that was built during the Khmer Empire and is on the top of a  cliff in the Dângrêk Mou
    中文释义：。
  - `th/Q34197.json`，`article[1]`：ปราสาทพระวิหารมีสถาปัตยกรรมแบบเขมร สร้างตามแนวเหนือใต้ซึ่งผิดแปลกไปจากปราสาทขอมส่วนใหญ่ ไทยและกัมพูชามีประวัติพิพาทเหนือตัวปราสาทเป็นเวลานานแล้ว ใน พ.ศ. 2505 ศาลยุติธรรมระหว่างประเ
    中文释义：。

- **数字／时间候选差异**：高棉语导语625米，泰语657米；需核查测量对象（山顶/寺庙）、海拔基准及来源，暂作数值候选。（置信标记：medium）
  - `km/Q5454.json`，`article[0]`：ប្រាសាទព្រះវិហារ (Prasat Preah Vihear) ស្ថិតនៅភាគខាងជើងនៃប្រទេសកម្ពុជាក្នុងភូមិសាស្ត្រ ភូមិធម្មជាតិ ឃុំស្រអែម ស្រុកជាំក្សាន្ត ខេត្តព្រះវិហារ និងពីអតីកាលមានទីតាំងក្នុងភូមិគ១ ឃុំកន្ទ
    中文释义：。
  - `th/Q34197.json`，`article[0]`：ปราสาทพระวิหาร ( บฺราสาทพฺระวิหาร; ) เป็นปราสาทหินตามแบบศาสนาฮินดูที่ตั้งอยู่บริเวณทิวเขาพนมดงรัก ( ภฺนํฎงแรก; "ภูเขาไม้คาน") สูงจากระดับทะเลปานกลาง 657 เมตร ที่ตั้งของศาสนสถานแห่ง
    中文释义：。

## Prevlaka（英文锚点 526808）

语言：en, hr, sr；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：地理、尺寸和现代争端背景互补；塞尔维亚语短条目不宜据导语认定政治回避。（置信标记：medium_preliminary）
  - `en/Q526808.json`，`article[1]`：Because of its strategic location in the southern Adriatic, in the aftermath of the SFR Yugoslav breakup, the peninsula became subject to a territorial dispute between Croatia and FR Yugoslavia, a federal state that included Montenegro. The territory was functional under UN until
    中文释义：补充南斯拉夫解体后克罗地亚与南联盟争端。。
  - `hr/Q82712.json`，`article[0]`：Prevlaka je poluotok u Hrvatskoj na ulazu u Boku kotorsku u južnoj Dalmaciji. Nalazi se u jugoistočnome dijelu Konavala uz mjesto Vitaljinu za čiji je morski greben vezan
    中文释义：克罗地亚半岛的地理定位。。
  - `sr/Q86999.json`，`article[0]`：Превлака је полуострво између Витаљине и Оштрог рта, на улазу у Боку Которску; погрешан назив за Оштри рт. Налази се са лијеве стране на уласку у Бококоторски залив. Дуга је 2600 м и широка 150-500 м, са површином од око 1 km². Не
    中文释义：给出长度、宽度、面积及历史归属。。

## Pulam Sumda（英文锚点 39988964）

语言：en, hi, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：印地语首段以印度村庄定义；中文明确实际印度控制、中国声索，并用“侵占”描述1954年后的情况；英文同时列印度行政归属和中国声索。存在归属框架及侵占措辞差异，不代替外部事实裁定。（置信标记：high）
  - `hi/Q1397606.json`，`article[0]`：भारत के उत्तराखण्ड राज्य के उत्तरकाशी ज़िले में स्थित एक छोटा सा गाँव है।
    中文释义：是印度北阿坎德邦北卡什县的小村庄。。
  - `zhs/Q3550787.json`，`article[1]`：波林三多却在1954年的协议签定后不久被印度侵占。
    中文释义：中文使用“侵占”措辞。。
  - `en/Q39988964.json`，`article[1]`：and claimed by Zanda County, Ngari Prefecture, Tibet, China.
    中文释义：同时记载中国西藏阿里札达县的声索。。

## Pweto（英文锚点 33570605）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Qaa（英文锚点 6290006）

语言：ar, en；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：阿语补充地理距离气候人口，英语补充主要希腊天主教社群；两者均定位黎巴嫩，初筛无明确归属冲突。（置信标记：medium）
  - `ar/Q1645945.json`，`article[1]`：جغرافيتها  / تبعد قاع بعلبك حوالي 136 كلم عن بيروت عاصمة لبنان. ترتفع حوالي 657 مترا عن سطح البحر وتمتد على مساحة تُقدَّر بـ 1291 هكتاراً. يعتبر مناخها شبه صحراوي فهو حار صيفا وبارد 
    中文释义：。
  - `en/Q6290006.json`，`article[0]`：Qaa (Arabic: القاع), El Qaa, Al Qaa, Qaa Baalbek or Masharih al-Qaa is a town in Baalbek-Hermel Governorate, Lebanon. / It has a mainly Greek Catholic population.
    中文释义：。

## Qaruh Island（英文锚点 3580162）

语言：ar, en；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：两者均称科威特小岛并给出275×175米尺度，阿语较详距离与海域，英语解释名称来自石油沉积；是细节互补。（置信标记：medium）
  - `ar/Q35667.json`，`article[0]`：قاروه، أصغر الجزر الكويتية الجنوبية وأكثرها توغلا داخل البحر حيث تبعد عن ساحل الزور 37,5 كم، كما تبعد عن جزيرة كبر 33 كم و789 مترا، وتبعد عن جزيرة أم المرادم بمسافة 16 كم و90 مترا 
    中文释义：。
  - `en/Q3580162.json`，`article[0]`：Qaruh Island () is an island belonging to the state of Kuwait, which received its name from the large amounts of petroleum sediments in the area (known as Qar in Arabic). It is the
    中文释义：。

## Qasr, Lebanon（英文锚点 55938288）

语言：ar, en；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：尽管阿文题名“قصر الهرمل”看似另一实体，正文明确是北贝卡赫尔梅勒行政区的边境镇，和英语Qasr村基本一致；不能仅按题名就误判实体错配。（置信标记：high）
  - `ar/Q1292386.json`，`article[0]`：بلدة في شمال البقاع اللبناني على الحدود السورية
    中文释义：黎巴嫩北贝卡、叙利亚边境上的城镇。。
  - `en/Q55938288.json`，`article[0]`：a village located in the Hermel District
    中文释义：位于赫尔梅勒区的村庄。。

## Qatar（英文锚点 8238258）

语言：ar, en；类型：country；状态：excerpt_screened_no_clear_difference。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Qazax District（英文锚点 1492873）

语言：az, en, hy；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：三语首段都将Qazax定位于阿塞拜疆；英文第二段补充飞地和亚美尼亚部队控制，阿语族语言材料补充词源/群体。未据摘要认定相反主权立场。（置信标记：medium）
  - `en/Q1492873.json`，`article[1]`：It has two exclaves inside Armenia
    中文释义：在亚美尼亚境内有两个飞地。
  - `az/Q2552.json`，`article[0]`：Azərbaycan Respublikasında inzibati – ərazi vahidi.
    中文释义：阿塞拜疆共和国行政单位。。

## Qit'at Jaradah（英文锚点 50235927）

语言：ar, en；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：阿文保留具体尺寸、英文相应位置数值缺失，首先是数值保留/清洗差异，不能当观点相反。（置信标记：medium_preliminary）
  - `ar/Q9178660.json`，`article[1]`：الجغرافيا  / تاريخياً لم يتم اعتبار قطعة جرادة جزيرة، ولكن في عام 2000 إدعت البحرين أن حجم الجزيرة يبلغ حوالي 12 × 4 أمتار (39 قدماً × 13 قدماً) عند ارتفاع المد مع ارتفاع حوالي 0.4 متر (1 قدم 4 بوصة)، و600 × 75 متراً (1969 قدماً × 246 قدماً) عند إنخفاض المد. الرأي المعارض يقول إنها تظهر فقط في المد المنخفض وتنغ
    中文释义：保留巴方2000年涨潮/低潮尺寸及对立的低潮高地说。。
  - `en/Q50235927.json`，`article[1]`：Geography / While historically Qit'at Jaradah has not been considered an island, Bahrain claimed in 2000 that the cay measured approximately  at high tide with an elevation of approximately , and  at low tide. The opposing view is that it is a low-tide elevation. The feature is uninhabited a
    中文释义：有相同双方描述，但尺寸经清洗丢失。。

## Ras Doumeira（英文锚点 19949336）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Rasu（英文锚点 53730295）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Republic of China（英文锚点 35181758）

语言：en, fa, hi, ja, ko, ky, mn, my, ne, ru, tg, tl, ur, vi, zhs, zht；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：俄语明确“部分承认国家”，越南语直接“主权国家”，中文以民主共和国及有效管辖范围描述。属于法律身份表述显著程度差异，不对承认问题作独立裁定。英语article为空不能做英文本比较。（置信标记：high）
  - `ru/Q2594.json`，`article[0]`：частично признанное государство
    中文释义：部分获得承认的国家。。
  - `vi/Q49103.json`，`article[0]`：một quốc gia có chủ quyền
    中文释义：一个主权国家。。
  - `zhs/Q271.json`，`article[0]`：目前有效管辖台湾本岛
    中文释义：目前有效管辖台湾本岛。。

- **实体范围／清洗风险**：尼泊尔语题为台湾且以历史叙事起笔，其他语种多题为中华民国；台湾岛/政治实体/历史国家范围应逐段明确，不能自动当所有命题同一对象。（置信标记：medium）
  - `ne/Q64212.json`，`article[0]`：ताइवान जापानको स्वामित्वमा गएको थियो।
    中文释义：台湾转归日本所有。。
  - `ja/Q279710.json`，`article[0]`：中華民国
    中文释义：中华民国。。

- **实体范围／清洗风险**：英语ROC归档无正文，其他语言多用Taiwan标题混合岛屿与政体范围。需在解释立场前记录这种范围风险，但不能因此抹去原文明示的国家/省份陈述差异。（置信标记：medium）
  - `fa/Q7493.json`，`article[0]`：تایوان با نام رسمی جمهوری چین
    中文释义：台湾，正式名称中华民国。
  - `tg/Q2211.json`，`article[0]`：ҷазира дар шарқи Осиё ва яке аз провинтсияҳои Хитой
    中文释义：东亚岛屿及中国的一个省。

- **措辞／归因／命名差异**：吉尔吉斯语首句直接称中国境内的自治省；波斯语称岛国，他加禄语称主权国家；塔吉克语同句并存省与单独国家两种称谓。应标注这种归属/国家地位框架差异及内部混合，不能作为整个语言社区立场的统计结论。（置信标记：high）
  - `ky/Q80916.json`，`article[0]`：Кытайдын аймагына кирген, бирок өз алдынча башкарууга ээ провинция
    中文释义：属于中国领土但具有自治的省。
  - `fa/Q7493.json`，`article[0]`：یک کشور جزیره‌ای در شرق آسیا
    中文释义：东亚的岛国。
  - `tl/Q1811.json`，`article[1]`：soberanong estadong
    中文释义：主权国家。
  - `tg/Q2211.json`，`article[0]`：як давлати алоҳида бо номи «Ҷумҳурии Чин»
    中文释义：一个名为中华民国的单独国家。

## Republic of Kosovo（英文锚点 23735572）

语言：en；类型：country；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Republic of the Congo（英文锚点 19599929）

语言：en, fr, sw；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：斯瓦希里语给出1960-08-15独立日与邻国，英语补充1958共和国建立及1969–1992政治体制；日期不是同一事件冲突。（置信标记：medium）
  - `sw/Q2167.json`，`article[1]`：Jamhuri ya Kongo imepakana na Gabon, Kamerun, Jamhuri ya Afrika ya Kati, Jamhuri ya Kidemokrasia ya Kongo, Angola na Bahari ya Atlantiki. /   / Nchi ilikuwa koloni la Ufaransa hadi tar
    中文释义：。
  - `en/Q19599929.json`，`article[1]`：The region was dominated by Bantu-speaking tribes at least 3,000 years ago, who built trade links leading into the Congo River basin. Congo was formerly part of the French colony o
    中文释义：。

## Rockall（英文锚点 25655）

语言：da, en, is；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：丹麦语直接说英国对岛主权获承认，英文说英国领土主张不获爱尔兰承认。这里是主权承认状态表述不一致的可核查候选；须比较修订时间与“岛本身/领海/经济区”范围，不把语言身份当成原因。（置信标记：high）
  - `da/Q83654.json`，`article[0]`：Storbritanniens suverænitet over øen er anerkendt
    中文释义：英国对该岛的主权获承认。
  - `en/Q25655.json`，`article[0]`：but this claim is not recognised by Ireland.
    中文释义：但该主张不获爱尔兰承认。。

## Rukwanzi Island（英文锚点 12939596）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Russia（英文锚点 25391）

语言：en, ja, ko, ru, uk, zhs, zht；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：俄语导语明确区分国际承认边界与含未获承认吞并的克里米亚人口口径；英语、中文也使用occupied/annexed及未获承认措辞。不能仅凭俄语来源推定它完全回避吞并；现有摘录更多体现统计/法律范围细化，需对相同时间和边界口径作匹配。（置信标记：high）
  - `ru/Q9.json`，`article[0]`：Росси́я, или Росси́йская Федера́ция (), — государство в Восточной Европе и Северной Азии. Россия — крупнейшее государство в мире, её территория в международно признанных границах составляет  км². Население страны в тех же границах, но с территорией Крыма, аннексия которого не получила международного признания, составляет  чел. (; 9-е место в мире).
    中文释义：区分国际承认边界，提及克里米亚吞并未获国际承认。。
  - `en/Q25391.json`，`article[55]`：Deepening economic integration and conservative foreign and domestic policy / In early 2014, following a revolution in Ukraine, Russia occupied and annexed Crimea from neighbouring Ukraine following a disputed referendum, with Russian troops later participating in a war in eastern Ukraine between Russian-backed separatists and Ukrainian troops. In a major escalation of the conflict, Russia launched a full-scale invasion of Ukraine on 24 February 2022. The in
    中文释义：2014年俄方占领并吞并克里米亚，并记述2022年全面入侵。。
  - `zhs/Q518.json`，`article[28]`：2014年，乌克兰进行广场革命后，俄罗斯入侵并吞并了乌克兰的克里米亚半岛。吞并未获得国际承认，联合国大会通过第68/262号决议，申明“乌克兰在其国际公认边界内的领土完整”，同时特别指出克里米亚公投“一概无效，不能成为改变克里米亚自治共和国或塞瓦斯托波尔市地位的基础”。
    中文释义：2014年吞并未获国际承认，并引用联大决议。。

## Sabah（英文锚点 28678）

语言：en, ms, tl；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：他加禄语并非仅因菲律宾语言就否认马来西亚行政身份；所阅段落确认马来西亚州并补充自治特点。（置信标记：medium_preliminary）
  - `en/Q28678.json`，`article[0]`：state of Malaysia located on the northern portion of Borneo, in the region of East Malaysia. Sabah has land borders with the Malaysian state
    中文释义：称马来西亚州。。
  - `tl/Q76041.json`，`article[0]`：May ibang antas ng awtonomiya ang naturang teritoryo sa pangangasiwa, pandarayuhan, at hudikatura na siyang nagtatangi rito sa mga estado sa iba pang estado sa Tangway ng Malaysia. Matatagpuan ang Sabah sa hilagang Borne
    中文释义：补充行政、移民与司法方面自治。。

## Sakhalin（英文锚点 58088）

语言：en, ja, ru；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：俄语第二段明确归因日本政府对南部归属未定的立场，日语按北纬50度区分南北历史；这说明俄语并非只呈现俄方归属，需保留归因而非标成俄国观点。（置信标记：medium）
  - `ru/Q25346.json`，`article[1]`：Принадлежность южной части Сахалина, с точки зрения японского правительства, остаётся неопределённой, так как в Сан-Францисском договоре не сказано, в пользу какого государства Япо
    中文释义：。
  - `ja/Q805805.json`，`article[1]`：樺太は、北部と南部でそれぞれ異なる沿革を経たため、ここでは北緯50度線以北を「北樺太」（または「北サハリン」）、以南を「南樺太」と表記する。
    中文释义：。

## Sakteng Wildlife Sanctuary（英文锚点 30021220）

语言：en, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英文给三个保护区分区面积，中文给植被与物种；进一步检查英文p5和中文p3都记载2020年中国声索及不丹否认过去声索。不是中文/英文简单一方承认另一方否认。（置信标记：high）
  - `en/Q30021220.json`，`article[5]`：Bhutan rejected the assertion, and denied that China had ever laid claim to the area in the past.
    中文释义：不丹拒绝该断言，并否认中国过去曾声索此地。。
  - `zhs/Q7286380.json`，`article[3]`：不丹否认中国过去曾对保护区提出过领土主张。
    中文释义：同样记载不丹对过去声索的否认。。

## Saltoro Mountains（英文锚点 5020345）

语言：en, hi, ur；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：乌尔都语使用带合法性判断的“غاصبانہ قبضہ”，英文/印地语所阅导语主要描述地理与实际控制线；是明确措辞差异，不能据此裁定边界主权。（置信标记：medium_preliminary）
  - `ur/Q664505.json`，`article[0]`：غاصبانہ قبضہ جمایا ۔
    中文释义：称印度1984—1987年对山峰进行侵占/非法占领。。
  - `en/Q5020345.json`，`article[0]`：Actual Ground Position Line. Saltoro Kangri peak, Saltoro River, and Saltoro Valley are features on this range. The Actual Ground Position Line (AGPL) between Indian and Pakistan held area r
    中文释义：以实际地面位置线和地理位置描述。。
  - `hi/Q782907.json`，`article[0]`：पाकिस्तान प्रशासित कश्मीर के गिलगित-बल्तिस्तान क्षेत्र की सीमा पर स्थित है, जहाँ पर्वतमाला की पश्चिमी तरफ़ साल्तोरो घाटी स्थित है।
    中文释义：使用巴基斯坦管理克什米尔的地理参照。。

## Sang, Uttarakhand（英文锚点 39990782）

语言：en, hi, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：印地语称印度北卡什村庄，英语并列中国声索，中文明确中国认为属于札达但印度实际控制；差异在归属叙述与声索显著性。（置信标记：medium）
  - `hi/Q1397602.json`，`article[0]`：सांग (Sang) या जाधांग (Sang) भारत के उत्तराखण्ड राज्य के उत्तरकाशी ज़िले में स्थित एक छोटा सा गाँव है। यह तिब्बत की सीमा के समीप है। यह ग्राम और पड़ोस के धूमकु, नेलांग व पुलम सुम्द
    中文释义：。
  - `en/Q39990782.json`，`article[0]`：Sang (Jadhang) is a small hilly village in Uttarkashi District, Uttarakhand, India, and claimed by Zanda County, Ngari Prefecture, Tibet, China. A tributary of the Jadh Ganga, itse
    中文释义：。
  - `zhs/Q3551428.json`，`article[1]`：领土争议  / 中国认为，位于甲扎岗噶河流域的桑、葱莎、波林三多地区是中国领土，属于西藏阿里地区札达县托林镇波林村管辖。该地区面积约1451平方公里，目前由印度实际控制。
    中文释义：。

## Sapodilla Cayes（英文锚点 32960086）

语言：en, es；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：西语首段即列伯利兹、危地马拉、洪都拉斯观点；进一步读取英文p2也列同样争议。区别在位置显著性与地理展开，不能据英文首段直接定义“伯利兹区”就断言英文隐藏争议。（置信标记：high）
  - `es/Q4551156.json`，`article[0]`：Honduras también reclama los cayos Sapodilla en su constitución de 1982
    中文释义：洪都拉斯也在1982年宪法中声索Sapodilla群岛。
  - `en/Q32960086.json`，`article[2]`：Honduras also lays a claim to the Sapodilla Cayes in its 1982 constitution.
    中文释义：英文也明确记载同一洪都拉斯宪法声索。。

## Sastavci（英文锚点 11203864）

语言：en, sr；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **实体范围／清洗风险**：英文村庄与塞文地方共同体的行政尺度不同；“驻地在波黑”不等于整个Sastavci属于波黑，不能误判为相反归属主张。（置信标记：medium_preliminary）
  - `en/Q11203864.json`，`article[0]`：Sastavci is a village in the Serbian municipality of Priboj, in Zlatibor District. It lies immediately east of the village of Međurečje, which is an exclave of Bosnia and Herzegovina. There are no border controls in or around the village.
    中文释义：描述塞尔维亚村庄并区分旁边波黑飞地Međurečje。。
  - `sr/Q291983.json`，`article[0]`：Саставци су сеоска месна заједница која припада општини Прибој. Седиште ове месне заједнице се налази у насељеном месту Међуречје, које припада општини Рудо (Република Српска, БиХ). Међуречје је са свих страна окружено територијом Републике Србије и прибојском и месном заједницом Саставци. МЗ Саставци обухвата насељена места: Касидоле, Батковиће, Херцеговачку Голешу, Пожегрмац и Црнуговиће. По попису из 2011. године на подручју ове месне заједнице живело је 1.029 становника.
    中文释义：描述基层地方共同体，其驻地在属波黑的Međurečje，并列涵盖聚落。。

## Saudi Arabia（英文锚点 349303）

语言：ar, en；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英文首段给与邻国、两海的地理关系，阿语第二段详述沙特各历史政体及1744/1818年；自然地理和政治史互补，未确认同一事实冲突。（置信标记：medium）
  - `en/Q349303.json`，`article[0]`：the largest in Western Asia and the Middle East
    中文释义：西亚和中东面积最大。
  - `ar/Q583733.json`，`article[1]`：محمد بن سعود سنة 1157 هـ / 1744
    中文释义：穆罕默德·本·沙特于伊历1157年/1744年。

## Scarborough Shoal（英文锚点 1885348）

语言：en, tl, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英文明列菲律宾及PRC/ROC声索，中文同样明列三方并区分PRC实控；中文补行政层级与海警，核心实控/多方声索可相容。（置信标记：medium）
  - `en/Q1885348.json`，`article[1]`：It is a disputed territory claimed by the Republic of the Philippines through the 1734 Velarde map, while the People's Republic of China and the Republic of China (Taiwan) claim it
    中文释义：。
  - `zhs/Q144514.json`，`article[0]`：，是南海中沙群岛的一个环礁。该岛距离中沙环礁160海里、距西沙群岛340海里、海南岛500海里、距菲律宾苏碧湾100海里。为海盆中的海山上覆珊瑚礁而成，是中沙群岛涨潮时唯一露出水面的岛礁，邻近马尼拉海沟。中华人民共和国、菲律宾、中华民国都宣称对黄岩岛拥有主权，目前黄岩岛由中华人民共和国实际控制，行政属海南省三沙市西沙区管辖，中沙群岛镇政府所在地，目前由中国海
    中文释义：。

- **摘录未见明确差异**：两种摘录都承认多方声索，英语还介绍管理现状及2012年事件；有限摘录中没有直接相反的三方声索事实，不能因导言侧重不同就判偏见。（置信标记：medium）
  - `en/Q1885348.json`，`article[1]`：a disputed territory claimed by the Republic of the Philippines
    中文释义：菲律宾声索的争议领土。
  - `tl/Q54492.json`，`article[0]`：Ito ay inaankin ng Pilipinas, Tsina at Taiwan bilang kanilang territoryo.
    中文释义：菲律宾、中国和台湾均声索其为自己的领土。

## Semliki River（英文锚点 6300031）

语言：en, sw；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：斯瓦希里语短文提供Edward湖至Albert湖流向，英语补充侵蚀、河道迁移导致乌干达和刚果(金)边界附近土地损失；没有把自然河道变化直接解释成单方主权立场。（置信标记：medium）
  - `sw/Q110227.json`，`article[1]`：Unaanza katika ziwa Edward na kuishia katika ziwa Albert.
    中文释义：河流始于Edward湖，终于Albert湖。。
  - `en/Q6300031.json`，`article[1]`：Increasing snow melt from the Rwenzoris, overgrazing, and other alterations to the watershed have caused bank erosion and frequent changes to the course of the meandering lower reaches of the river. In some places, Uganda is losing up to  of land per year on its side of the river to erosion and silt from the Semliki is gradually filling in the southern end of Lake Albert. In other places, it is the DRC that is losing territory as the changing river course alters the apparent location of the border.
    中文释义：侵蚀及河道变化导致乌干达、其他地方刚果(金)损失土地。。

## Senkaku Islands（英文锚点 348333）

语言：en, ja, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：三个独立来源突出管理、命名与各方理由的不同信息，但都有争议框架。中文引述“中国自古领土”等有主体归因，不应误标为作者无归因直接断言；简繁同源。（置信标记：medium_preliminary）
  - `ja/Q27792.json`，`article[1]`：日本と中華人民共和国（中国）および中華民国（台湾）がそれぞれ領有権を主張している。「尖閣諸島」および「尖閣列島」は日本における呼称であり、中国では釣魚群島あるいは釣魚島およびその付属島嶼、台湾では釣魚臺列嶼と呼ばれている。詳しくは尖閣諸島問題を参照。
    中文释义：明确日本、中华人民共和国、中华民国分别主张。。
  - `zhs/Q6114.json`，`article[0]`：中华民国、中华人民共和国与日本国皆声称钓鱼台列屿为其领土，引发一连串争议。中华民国、中华人民共和国认为钓鱼台列屿依地理、历史和法理均为中国自古以来的领土，属台湾附属岛屿。日本称其为尖阁诸岛（），日本政府认为岛屿按历史及国际法均属于日本固有领土，归属西南诸岛一部分，没有领有权问题。
    中文释义：并列三方主张，且分别归因中国两方与日本的历史/法律论据。。
  - `en/Q348333.json`，`article[0]`：administered by Japan. They are located northeast of Taiwan, east of China, west of Okinawa Island, and north of the southwestern end of the
    中文释义：说明日本实际管理。。

## Serbia（英文锚点 29265）

语言：bs, en, hr, sq, sr；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：塞语边界导语列阿尔巴尼亚，英文明示通过有争议科索沃声索该边界；克/阿尔巴尼亚语列科索沃为邻方。反映地理列表的主权口径与归因差异，不能当统计事实同义。（置信标记：high）
  - `sr/Q1517.json`，`article[0]`：на југозападу са Албанијом
    中文释义：西南与阿尔巴尼亚接壤。。
  - `en/Q29265.json`，`article[0]`：claims a border with Albania through the disputed territory of Kosovo.
    中文释义：通过争议科索沃声索与阿尔巴尼亚的边界。。
  - `hr/Q7093.json`，`article[0]`：na jugu s Sjevernom Makedonijom i Kosovom.
    中文释义：南邻北马其顿和科索沃。。

## Serranilla Bank（英文锚点 750888）

语言：en, es；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：西语首段突出哥伦比亚正式主权获2012年法院判决确认；英文同意该判决涉及哥伦比亚/尼加拉瓜，但另明确判决未分析洪都拉斯、美国主张。是裁决适用范围与确定性框架/信息补充差异，不是互斥判决事实。（置信标记：high）
  - `es/Q1149050.json`，`article[0]`：La soberanía de Colombia sobre Serranilla fue ratificada expresamente
    中文释义：哥伦比亚对Serranilla的主权获明确确认。
  - `en/Q750888.json`，`article[1]`：although the judgment does not analyze or mention the claims of Honduras or United States over the reef.
    中文释义：但判决未分析或提及洪都拉斯、美国对礁盘的主张。。

## Sevastopol（英文锚点 51587）

语言：en, ru, uk；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：俄语承认2014年吞并、联合国多数成员承认为乌克兰部分，并区分实际为俄罗斯联邦城市；乌语明确“临时非法军事占领”；英语同样区分国际承认与俄占。共同法律/控制事实与评价措辞并存，不能把俄语的实际行政描述误作不存在国际非承认。（置信标记：high）
  - `ru/Q32261.json`，`article[1]`：В 2014 году Россия аннексировала Крымский полуостров, включая Севастополь. Государственная принадлежность территории Севастополя с тех пор является предметом разногласий между Россией и Украиной. Согласно административному делению Украины, частью которой он признаётся большинством государств — членов ООН, Севастополь является регионом Украины — городом со специальным статусом. Фактически Севастополь является субъектом Российской Федерации — городом федерального значения.
    中文释义：多数联合国成员承认乌克兰归属、实际为俄联邦城市。。
  - `uk/Q21358.json`，`article[2]`：З березня 2014 року місто тимчасово перебуває під російською незаконною військовою окупацією, що повністю підтверджує Резолюція Генеральної Асамблеї ООН про підтримку територіальної цілісності України.
    中文释义：自2014年3月临时处于俄罗斯非法军事占领。。
  - `en/Q51587.json`，`article[2]`：Sevastopol, along with the rest of Crimea, is internationally recognised as part of Ukraine, and under the Ukrainian legal framework, it is administratively one of two cities with special status (the other being Kyiv). However, it has been occupied by Russia since 27 February 2014, before Russia annexed Crimea on 18 March 2014 and gave it the status of a federal city of Russia. Both Ukraine and Russia consider the city administratively separate from the Autonomous R
    中文释义：国际承认为乌克兰部分，自2014年被俄罗斯占领。。

## Seychelles（英文锚点 27288）

语言：en, fr；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：英语115岛，法语116岛且明确含1个人工岛；计数口径足以解释差1，不能报作确定事实冲突。（置信标记：medium）
  - `en/Q27288.json`，`article[0]`：Seychelles (, ;   ), officially the Republic of Seychelles (; Creole: La Repiblik Sesel), is an archipelagic state consisting of 115 islands in the Indian Ocean. Its capital and la
    中文释义：。
  - `fr/Q8669.json`，`article[0]`：Les Seychelles, en forme longue la république des Seychelles (en créole seychellois :  et  ;  et ) est un archipel de cent-seize îles (dont une artificielle), situé en Afrique de l
    中文释义：。

## Shaksgam River（英文锚点 17659202）

语言：en, hi, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英文行政/声索与中文水文数据互补。实体是河流，原问题可能以河谷作为主题，需区分河流与河谷范围，不能用不同水文边界判立场。（置信标记：medium_preliminary）
  - `en/Q17659202.json`，`article[1]`：Administratively, the Chinese part of the valley is within the southernmost portions of Yarkand County (the source) and the Tashkurgan Tajik Autonomous County (lower course). India claims the entire valley as part of its Jammu and Kashmir state, now part of La
    中文释义：区分中国行政区及印度对整个河谷的主张。。
  - `zhs/Q1457941.json`，`article[1]`：概要 / 源出叶城县境内的喀喇昆仑山的特拉木坎力冰川。该冰川长度约28公里，面积则达到了124平方公里。喀喇昆仑山脉中国境内的冰川约36%都集中在克勒青河谷中，面积达到2235平方公里。其中包括面积达380平方千米、长42km的音苏盖提冰川，是中国长度最长、面积最大的树枝状山谷冰川，由14条冰川汇聚而成。还有9条长度在18—30公里，面积在70—200平方公里的大型冰川。
    中文释义：补充冰川长度、面积与叶城县水系。。

## Shatt al-Arab（英文锚点 147227）

语言：ar, en, fa；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：阿语/英文首先使用Shatt al-Arab，波斯语首先使用Arvandrud且同时给Shatt别名；阿语称阿拉伯湾，波斯语/英文称波斯湾。命名和历史叙述重点可不同，但词名差异本身不是当前河界事实冲突。（置信标记：high）
  - `ar/Q20260.json`，`article[0]`：ويصب في الخليج العربي
    中文释义：流入阿拉伯湾。
  - `fa/Q14776.json`，`article[1]`：خلیج فارس
    中文释义：波斯湾。
  - `fa/Q14776.json`，`article[0]`：اَروَندرود یا شَط العَرَب
    中文释义：Arvandrud或Shatt al-Arab。

## Shebaa Farms（英文锚点 194547）

语言：ar, en, iw；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：希伯来语导语作以色列主权陈述，英阿语以占领框架描述；希伯来语下一段另述国际争议及美国承认，因此应列法律框架差异并保留上下文，不能只截一句认定整篇单方。（置信标记：high）
  - `iw/Q135410.json`，`article[0]`：השטח בריבונות ישראלית מאז נחקק חוק הגולן ב-1981.
    中文释义：自1981戈兰法以来领土处于以色列主权之下。
  - `en/Q194547.json`，`article[0]`：the Israeli-occupied Golan Heights
    中文释义：以色列占领的戈兰高地。
  - `ar/Q63248.json`，`article[0]`：الجولان المحتل من قِبل إسرائيل
    中文释义：被以色列占领的戈兰。

## Shipki La（英文锚点 5852522）

语言：en, hi, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：英印地语将Shipki La作为印度—中国/西藏间通道和贸易口岸描述；中文历史段称“印军侵驻”、近期中国控制并拆除印哨，另有具体山顶/通道范围。应先核对山口、山顶哨所及传统边界范围；有立场措辞和控制变化候选，但不据此断言同一地点同一时间控制事实冲突。（置信标记：high）
  - `en/Q5852522.json`，`article[1]`：The pass is on the border between the Kinnaur district in the state of Himachal Pradesh, India, and the Ngari Prefecture in Tibet, China. The pass is one of India's border trading points with Tibet along with Nathu La in Sikkim, and Lipulekh in Uttarakhand. The pass is close to town of Khab.
    中文释义：印度Himachal Pradesh与中国Tibet之间边界贸易口岸。。
  - `zhs/Q3510163.json`，`article[1]`：历史 / 什布奇山口属于中国与印度边界中段领土争议区之一。1958年4月,印军侵驻拉容马山顶,在该地修建营房6间后建立永久哨所，曾被印度实际控制。近年来中国开始控制这里。并拆除了印度的哨所。中国声称，中印两国在此地的传统习惯边界在什布奇山口以西的活不桑河的河中心。什布奇山口是印度在中印中段边境通往中国西藏四大重要通道之一（其余三大通道分别为桑三桑巴通道、公贡桑巴通道及强拉山口）,1841年5月，查谟-克什米尔的森巴人侵犯中国西藏阿里，兵分三路，其中的一路就是通过什布奇山口侵入阿里的。
    中文释义：历史段使用印军侵驻及近年来中国开始控制的描述。。
  - `hi/Q26037.json`，`article[0]`：शिपकी ला या शिपकी दर्रा हिमालय का एक प्रमुख दर्रा हैं। यह भारत के हिमाचल प्रदेश के किन्नौर ज़िले को तिब्बत के न्गारी विभाग के ज़ान्दा ज़िले से जोड़ता है। सतलुज नदी इस दर्रे के पास ही एक तंग घाटी से गुज़रकर तिब्बत से भारत में दाख़िल होती है। भारत का राष्ट्रीय राजमार्ग ५ शिपकी ला त
    中文释义：该山口连接印度Kinnaur与TibetZanda。。

## Siachen Glacier（英文锚点 1673550）

语言：en, hi, ur, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：控制线编号9842/9884及冰川长度72/76公里是具体可复核的数值差异候选，可能含笔误、测量口径/年代；不能直接归为政治偏向。（置信标记：medium_preliminary）
  - `en/Q1673550.json`，`article[0]`：NJ9842 where the Line of Control between India and Pakistan ends. At  long, it i
    中文释义：英语控制线终点NJ9842。。
  - `ur/Q68432.json`，`article[0]`：9884 کے بالکل شمال مشرق میں ہے جہاں ہندوستان اور پاکستان کے مابین لائن آف کنٹرول
    中文释义：乌文对应位置写9884。。
  - `zht/Q628282.json`，`article[1]`：72公里，面積約3,000餘平方公里，平均氣溫在攝氏零下30－50度之間。地形上呈南北走向，西面爲薩爾託洛山脈（Saltoro Mountains），東面爲喀喇
    中文释义：繁中长度72公里。。
  - `ur/Q68432.json`，`article[0]`：76 کلومیٹر (47 میل) لمبا پر ، یہ قراقرم کا سب سے لمبا اور دنیا کے غیر قطبی علاقو
    中文释义：乌文长度76公里。。

- **措辞／归因／命名差异**：“整个冰川”与“该地区约2/3”可能指不同地理范围；必须核对冰川本体与周边争议区，不能未经范围对齐判为事实冲突。（置信标记：medium_preliminary）
  - `en/Q1673550.json`，`article[0]`：The entire Siachen Glacier, with all major passes, has been under the administration of India as part of the union territory of Ladakh, located in the Kashmir region since 1984. Pakistan maintains a territorial claim over the Siachen Glacier and controls the r
    中文释义：称整个冰川及主要山口由印度管理。。
  - `zht/Q628282.json`，`article[1]`：在1984年後，該地區大部分由印度控制，印度約控制了該地區面積的2/3。
    中文释义：称该地区大部分由印度控制、约面积2/3。。

## Singapore（英文锚点 27318）

语言：en, ms；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英马均列独立岛国，英语细列岛屿与历史，马来语强调金融、移民；仅能认定所审段落信息侧重不同，不推断立场冲突。（置信标记：medium）
  - `en/Q27318.json`，`article[0]`：an island country and city-state
    中文释义：岛国与城市国家。。
  - `ms/Q2104.json`，`article[0]`：sebuah negara pulau
    中文释义：一个岛国。。

## Singapore Strait（英文锚点 1610199）

语言：en, ms；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英文给2017年每天约2000艘商船及吃水限制，马来语保留114公里长、16公里宽。地理基本关系一致，数值/航运互补。（置信标记：medium）
  - `en/Q1610199.json`，`article[1]`：Approximately 2,000 merchant ships traverse the waters on a daily basis in 2017.
    中文释义：2017年每天约2000艘商船通过。。
  - `ms/Q147962.json`，`article[0]`：Panjang selat ini ialah 114 km dan lebarnya 16 km.
    中文释义：海峡长114公里、宽16公里。。

## Sipilou（英文锚点 21825447）

语言：en, fr；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：两者均定位科特迪瓦边境城镇；法语补交通枢纽与多族聚居，英语补行政层级和边检距离，未发现明确互斥事实。（置信标记：medium）
  - `fr/Q3223765.json`，`article[0]`：Sipilou est une ville et chef-lieu du département de Sipilou dans la région du Tonkpi dans l'ouest de la Côte d'Ivoire. Sipilou est également un chef-lieu de commune. Ville cosmopo
    中文释义：。
  - `en/Q21825447.json`，`article[0]`：Sipilou (also known as Siquita) is a town in the far west of Ivory Coast. It is a sub-prefecture of and seat of Sipilou Department in Tonkpi Region, Montagnes District. Sipilou is 
    中文释义：。

## Sir Creek（英文锚点 5228466）

语言：en, hi, ur；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英、印地、乌尔都语均承认印巴之间边界未决；英语导语提供停战裁决范围，印地语补充英殖民地图及双方提案，乌语补充1968年西部边界裁决后法律划界仍未定。96公里与乌语60–100公里应检查是河口本体还是更广区域，不先判矛盾。（置信标记：high）
  - `en/Q5228466.json`，`article[0]`：Sir Creek ( ), originally Ban Ganga, is a 96-km (60-mi) tidal estuary in the uninhabited marshlands of the Indus River Delta on the border between India and Pakistan. The creek flows into the Arabian Sea and separates Gujarat state in India from Sindh province in Pakistan. The long-standing India-Pakistan Sir Creek border dispute stems from the demarcation "from the mouth of Sir Creek to the top of Sir Creek, and from the top of Sir Creek eastward to a point on the line designated on the Western Terminus". From this point onward, the boundary is unambiguously fixe
    中文释义：96公里潮汐河口，印巴争端源于划界。。
  - `hi/Q47338.json`，`article[2]`：स्वतंत्रता के बाद पाकिस्तान ने खाडी के प्रदेश पर अपना मालिकाना हक जताया. इसके जवाब में भारत का प्रस्ताव था कि कच्छ के रण से लेकर खाडी के मुख तक की एक सीधी रेखा को सीमा रेखा मान लेना चाहिए। परंतु यह प्रस्ताव पाकिस्तान को मंजूर नही था।
    中文释义：独立后巴方声索、印方直线边界提案未获巴方同意。。
  - `ur/Q68441.json`，`article[0]`：سر کریک ہندوستانی ریاست گجرات اور پاکستانی صوبے سندھ کے درمیان کا علاقہ ہے۔ مگر ابھی تک سر کریک پر ہندوستان اور پاکستان کے مابین بین الاقوامی سرحد کے تعین ہونا باقی ہے۔ ساٹھ سے سو کلومیٹر کے اس علاقے میں بہت سی کریک یعنی خلیج اور دریاؤں کے دہانے ہیں۔ اس علاقے کا تنازع 1960ء کی دہائی میں سامنے آیا تھاجس پر 1968ء میں پاکستان اور بھارت کے درمیان ایک ویسٹرن باؤنڈری ٹرائیبیونل ایوارڈ قائم کیا گیا لیکن یہ طے نہیں ہو سکا کہ سر کریک کے علاقے میں بین الاقوامی سرحد کا تعین کس قانونی بنیاد پر کیا جائے۔ اس علاقے کا کچھ حصہ آبی ہے اور کچھ حصہ خشک۔ پاکستان اور بھارت کے مابین کئی دفعہ اس مسئلہ پر مذاکرات ہوچکے ہیں لیکن اس پر بھی کوئی فیصلہ نہیں ہو سکا ہے۔ ب
    中文释义：国际边界仍未确定，描述1968年裁决与未解法律划界。。

## Sixty-Four Villages East of the River（英文锚点 5405254）

语言：en, ru, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：繁中导语将1900行动写作俄国借口、惨案；俄语先介绍1858土地转让，后文仍明确中华民国未承认兼并而PRC1991放弃声索。属于历史框架/前景化差异，不能据俄语导语断言没有争议说明。（置信标记：high）
  - `zht/Q36831.json`，`article[0]`：俄國以義和團破壞東清鐵路爲藉口
    中文释义：俄国以破坏铁路为借口。。
  - `ru/Q1340863.json`，`article[1]`：земли к северу от Амура были переданы России.
    中文释义：阿穆尔河北岸土地被交给俄罗斯。。
  - `ru/Q1340863.json`，`article[6]`：никогда не признавала законной русскую аннексию.
    中文释义：从未承认俄罗斯兼并合法。。

## Slovenia（英文锚点 27338）

语言：en, hr, sl；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：三语均说明相同邻国；斯洛文尼亚语补充2021年人口与宪法少数族群，英文和克罗地亚语展开历史。人口近似差需按年份，未认定立场冲突。（置信标记：medium）
  - `sl/Q534.json`，`article[1]`：Po podatkih na dan 1. oktobra 2021
    中文释义：依据2021年10月1日数据。
  - `en/Q27338.json`，`article[1]`：Slavic, Germanic, and Romance languages and cultures
    中文释义：斯拉夫、日耳曼、罗曼语与文化。

## Snihurivka（英文锚点 6862279）

语言：en, ru, uk；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英语导语后段给出2022年3月至11月俄占时段；乌语导语给出2020行政改革信息。首段差异不能证明乌俄全文不提相同战争史。（置信标记：medium）
  - `en/Q6862279.json`，`article[1]`：It was occupied by Russia from March 2022 until November 2022.
    中文释义：。
  - `uk/Q20066.json`，`article[0]`：Снігурі́вка — місто в Україні, адміністративний центр Снігурівської міської громади Баштанського району Миколаївської області. Залізничний вузол. До 17 липня 2020 року — адміністра
    中文释义：。

## Socotra Governorate（英文锚点 41931850）

语言：ar, en；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：阿文行政细节与英文省份归属历史互补，均说明也门省级单位；尚无所阅段落的相反国家归属。（置信标记：medium_preliminary）
  - `ar/Q1873612.json`，`article[0]`：محافظة أرخبيل سقطرى محافظة تقع في جنوب اليمن، تنقسم إدارياً إلى مديريتين. عاصمتها حديبو، كانت مديريات المحافظة تتبع محافظة حضرموت حتى ديسمبر 2013 عندما صدر قرار باستحداث محافظة أرخبيل سقطرى.
    中文释义：行政分成两区、首府Hadibu及2013建省。。
  - `en/Q41931850.json`，`article[1]`：History  / Since before British rule, Socotra had been part of the Mahra Sultanate, and remained so after Mahra became part of Aden Protectorate. With the independence of South Yemen in 1967, the archipelago was attached to the Aden Governorate, despite its distance. In 2004, it was moved to the Hadhramaut Governorate. Since December 2013, it has been a governorate of its own.
    中文释义：补充早期Mahra/Aden及2004转入Hadhramaut的历程。。

## Somalia（英文锚点 27358）

语言：ar, en, so；类型：country；状态：excerpt_screened_no_clear_difference。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## South Africa（英文锚点 17416221）

语言：en；类型：country；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## South Georgia and the South Sandwich Islands（英文锚点 27380）

语言：en, es；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：西文在导语提升阿方声索显著性，英文导语突出英国行政分类；仅为信息布局/侧重差异，不意味着英文全文无声索。（置信标记：medium_preliminary）
  - `en/Q27380.json`，`article[0]`：South Georgia and the South Sandwich Islands (SGSSI) is a British Overseas Territory in the southern Atlantic Ocean. It is a remote and inhospitable collection of islands, consisti
    中文释义：称英国海外领土。。
  - `es/Q239198.json`，`article[0]`：administrado por el Reino Unido y reclamado por Argentina, que comprende a la totalidad del archipiélago de las Georgias del Sur y del archipiélago de las Sándwich del Su
    中文释义：导语同时强调英国管理与阿根廷声索。。

## South Korea（英文锚点 27019）

语言：en, ja, ko, ru, zhs, zht；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：英文使用Sea of Japan，中国文使用“东海（日本海）”，存在同一海域命名排列差异。三语都描述韩国位于朝鲜半岛南部；地名差不能自动等同国家主权观点冲突。（置信标记：medium）
  - `en/Q27019.json`，`article[0]`：the Sea of Japan
    中文释义：日本海。
  - `zhs/Q3121.json`，`article[0]`：东边是东海（日本海）
    中文释义：东边为东海（日本海）。

- **事实互补**：英语摘录侧重地理和分治历史，日语摘录给经济和产业背景，俄语给2022年人口估计；这些是摘录层面的互补，不从不同段落的选材推断整个语言版本偏见。（置信标记：medium）
  - `en/Q27019.json`，`article[0]`：It constitutes the southern part of the Korean Peninsula
    中文释义：构成朝鲜半岛南部。
  - `ja/Q4585754.json`，`article[1]`：2020年における国内総生産 (GDP) は世界第10位
    中文释义：2020年GDP世界第10位。
  - `ru/Q2821.json`，`article[1]`：население, по оценке 2022 года — более 51 миллиона человек
    中文释义：按2022年估计人口超过5100万。

## South Sudan（英文锚点 32350676）

语言：ar, en, sw；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：三语均述2011独立；斯瓦希里语补充公投98.83%，英语明确独立日期，阿语补充迁都计划。属于同一过程互补。（置信标记：medium）
  - `en/Q32350676.json`，`article[1]`：9 July 2011
    中文释义：2011年7月9日。。
  - `sw/Q34294.json`，`article[1]`：(98.83%)
    中文释义：98.83%。。
  - `ar/Q342661.json`，`article[0]`：تغيير العاصمة إلى رامشيل
    中文释义：将首都迁往拉姆塞尔。。

## Southern Patagonian Ice Field（英文锚点 4793454）

语言：en, es；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：两者给智利14200/阿根廷2600km²，西语追加边界仍待共同勘定。英语第二大“极区外”与西语全球第三/非极地大陆性等表述口径不同，不应直接当数值矛盾。（置信标记：medium）
  - `en/Q4793454.json`，`article[1]`：The Southern Patagonia Ice Field extends from parallels 48° 15′ S to 51° 30′ S for approximately , and has an approximate area of / , of which 14,200 km2 belong to Chile and 2,600 km
    中文释义：。
  - `es/Q302694.json`，`article[1]`：Se extiende de norte a sur a lo largo de 350 km, desde los 48º20' S hasta los 51º30' S. Tiene una extensión de 16 800 km², de los cuales 14. 200 km² pertenecen a Chile y 2.600 km² 
    中文释义：。

## Spain（英文锚点 26667）

语言：ar, en, es, pt；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：已阅各文均可并存地描述西班牙制度/地理，细节互补；不因阿文或葡文语言来源推断其否认西方管辖。（置信标记：medium_preliminary）
  - `en/Q26667.json`，`article[0]`：Ceuta and Melilla in Africa. The country's mainland is bordered to the south by Gibraltar; to the so
    中文释义：列非洲的休达、梅利利亚自治市。。
  - `pt/Q785.json`，`article[0]`：fronteira terrestre com um país africano (Marrocos). Várias pequenas ilhas no mar de Alborão também fazem parte do território espanhol. A Espanha continental é limitada a
    中文释义：补充因此与摩洛哥有陆界。。
  - `es/Q972.json`，`article[0]`：diecisiete comunidades autónomas, formadas a su vez por cincuenta provincias; y dos ciudades autónomas.
    中文释义：补充17自治区、50省、2自治市结构。。

## Spratly Islands（英文锚点 27401）

语言：en, ms, tl, vi, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **实体范围／清洗风险**：越南语专门指出国际Spratly Islands定义范围未清楚确定、各国理解不同。比较面积、岛礁数、声索覆盖前应先对齐集合范围，而不能把名称相同视为同一组岛礁。英文导语也承认争议群岛并说明组成。（置信标记：high）
  - `vi/Q1421.json`，`article[1]`：Ở cấp độ quốc tế, phạm vi của khái niệm Spratly Islands vẫn chưa được xác định rõ và đang trong vòng tranh cãi. Ở cấp độ quốc gia cũng có các cách hiểu khác nhau. Tuy Đài Loan, Trung Quốc và Việt Nam trên danh nghĩa đều tuyên bố chủ quyền đối với toàn bộ quần đảo, nhưng khái niệm quần đảo Nam Sa trong nhận thức của Đài Loan và Trung Quốc là bao hàm toàn bộ các thực thể địa lý nằm bên tro
    中文释义：Spratly Islands国际定义范围不清、各国理解也不同。。
  - `en/Q27401.json`，`article[0]`：The Spratly Islands (; ; Malay, ; ) are a disputed archipelago in the South China Sea. Composed of islands, islets, cays, and more than 100 reefs, sometimes grouped in submerged old atolls, the archipelago lies off the coasts of the Philippines, Malaysia, and southern Vietnam. Named after the 19th-century British whaling captain Richard S
    中文释义：争议群岛，包含岛、沙洲和超过100个礁等组成。。

- **数字／时间候选差异**：马来语750个地貌单元、中文230多个岛洲礁沙滩、他加禄语约100个小岛，统计对象和海域范围可能不同。中文面积约90万平方公里、马来语超过42.5万也需先统一空间定义，不能直接作为事实互斥或民族立场证据。简繁同源只算一个独立版本。（置信标记：medium）
  - `ms/Q15822.json`，`article[0]`：terdiri daripada 750 terumbu (Shoal), Palil (Islet), atol, pulau karang
    中文释义：由750个浅滩、小岛、环礁和珊瑚岛等构成。
  - `zhs/Q23119.json`，`article[0]`：由230多个岛、洲、礁、沙和滩组成
    中文释义：由230多个岛、洲、礁、沙和滩组成。
  - `tl/Q19331.json`，`article[0]`：mahigit-kumulang 100 maliliit na pulo
    中文释义：约100个小岛。

- **措辞／归因／命名差异**：英语以争议群岛定义；他加禄语在介绍争议的同一段直接称其为Palawan的一部分。此为行政归属叙述与归因框架差异；他加禄语也承认多方声索，不能说它完全隐去争议。（置信标记：high）
  - `en/Q27401.json`，`article[0]`：are a disputed archipelago in the South China Sea
    中文释义：是南海中的争议群岛。
  - `tl/Q19331.json`，`article[0]`：Bahagi ito ng Palawan
    中文释义：它是巴拉望的一部分。

## State of Palestine（英文锚点 241405）

语言：ar, en, iw；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **实体范围／清洗风险**：希伯来语导语把对象描述为巴勒斯坦人希望建立的国家并讨论自治能力，英阿语以巴勒斯坦国现有国家地位开篇。既有国家地位框架差异，也可能是国家/建国概念条目范围不一致，需实体与文体审查后再作立场判断。（置信标记：medium）
  - `iw/Q641143.json`，`article[0]`：מדינה פלסטינית או "מדינת פלסטין" (בערבית: دَوْلَة فِلَسْطِين، "דַוְלת פִלַסטין" או دَوْلَة فِلَسْطِينِيَّة "דַוְלה פִלַסטִינִיה") מוכרת בתור מדינה ששואפים להקים חלק ניכר מהפלסטינים
    中文释义：。
  - `en/Q241405.json`，`article[0]`：Palestine (, ), officially the State of Palestine (), is a state located in the Southern Levant region of Western Asia. Officially governed by the Palestine Liberation Organization
    中文释义：。
  - `ar/Q47022.json`，`article[0]`：فِلَسْطِين (رسميًا: دَوْلَةُ فِلَسْطِين) هي بحكم القانون دولة ذات سيادة في غرب آسيا، وتحكم رسميًا من قبل منظمة التحرير الفلسطينية وتطالب بالضفة الغربية وقطاع غزة. ومع ذلك، احتلت إس
    中文释义：。

## Stung Treng province（英文锚点 203867）

语言：en, km；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英语给1904法属老挝与柬埔寨的省份交换，柬语导语给原名和行政区。所审片段可以互补；未充分审查全部柬语正文以认定历史遗漏或倾向。（置信标记：medium）
  - `en/Q203867.json`，`article[4]`：In 1904 French Laos traded the province to the French Protectorate of Cambodia
    中文释义：1904年法属老挝把该省交换给法属柬埔寨。。
  - `km/Q2784.json`，`article[0]`：ខេត្តមួយនៅចុងខាងជើងនៃប្រទេសកម្ពុជា
    中文释义：位于柬埔寨北端的省份。。

## Sudan（英文锚点 27421）

语言：ar, en；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：阿语2022年人口约4800万、面积1861484；英文2022年人口4570万、面积1886068。是需要核对估计来源、统计时点与地域口径的数值差异，不直接推断偏见。（置信标记：high）
  - `ar/Q3711.json`，`article[0]`：48 مليون نسمة (تقدير 2022) وتبلغ مساحتها 1,861,484
    中文释义：2022年估计人口4800万、面积1861484。
  - `en/Q27421.json`，`article[0]`：45.7 million people as of 2022 and occupies 1,886,068 square kilometres
    中文释义：2022年人口4570万、面积1886068平方公里。

## Suriname（英文锚点 26828）

语言：en, fr, nl；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英语概述苏里南人口来源和海岸分布，荷语补充1667–1954殖民、其后王国成员至1975独立，以及与圭亚那/法属圭亚那边界争端；法语共同确认1975独立。这些是历史制度和邻界资料互补。（置信标记：medium）
  - `nl/Q1535547.json`，`article[0]`：Suriname, officieel de Republiek Suriname, is een republiek aan de noordkust van Zuid-Amerika met als hoofdstad Paramaribo. Het land was van 1667 tot 1954 een kolonie van Nederland en daarna een land binnen het Koninkrijksverband. Op 25 november 1975 werd Suriname onafhankelijk. De Surinaamse bevolking bestaat uit meerdere etnische groepen waarvan er geen een absolute meerderhe
    中文释义：1667–1954荷兰殖民地，其后王国成员，1975独立。。
  - `fr/Q8703.json`，`article[0]`：Le Suriname (parfois également orthographié Surinam), en forme longue la république du Suriname (en  et ), est un pays d'Amérique du Sud (appelé Guyane néerlandaise jusqu'à son indépendance en 1975).
    中文释义：1975独立以前称荷属圭亚那。。

## Susta territory（英文锚点 63470708）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Sveta Gera（英文锚点 15300936）

语言：en, hr, sl；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：各语都承认山顶边界/军事设施争议。斯洛文尼亚语明确标记山顶点在克方，克语写设施被斯军占据；山顶点与营房不是同一位置，不应误标为直接矛盾。（置信标记：medium）
  - `sl/Q158493.json`，`article[0]`：Sama točka vrha
    中文释义：山顶这一点本身。。
  - `hr/Q167068.json`，`article[0]`：sporni vojni objekt
    中文释义：有争议的军事设施。。
  - `en/Q15300936.json`，`article[0]`：the summit is subject to a border dispute
    中文释义：山顶存在边界争议。。

## Swains Island（英文锚点 1683516）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Syria（英文锚点 7515849）

语言：ar, en, iw, tr；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：阿语邻国列表使用“巴勒斯坦”，英、土语使用“以色列”。是命名/政治地理框架差异，不能仅凭名称决定边界真值或整种语言态度。（置信标记：high）
  - `ar/Q187029.json`，`article[0]`：وغربًا فلسطين، ولبنان
    中文释义：西面为巴勒斯坦、黎巴嫩。
  - `en/Q7515849.json`，`article[0]`：Israel and Lebanon to the southwest
    中文释义：西南为以色列和黎巴嫩。
  - `tr/Q8673.json`，`article[0]`：güneybatıda İsrail ve Lübnan
    中文释义：西南为以色列和黎巴嫩。

- **摘录未见明确差异**：两份导言均确认叙利亚国家身份与中东位置；本次有限摘录未识别明确立场冲突，不表示全文相同。（置信标记：medium）
  - `en/Q7515849.json`，`article[0]`：officially the Syrian Arab Republic
    中文释义：正式名称为阿拉伯叙利亚共和国。
  - `iw/Q410.json`，`article[0]`：הרפובליקה הערבית הסורית
    中文释义：阿拉伯叙利亚共和国。

## Taiwan（英文锚点 25734）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Tajikistan（英文锚点 30108）

语言：en, ky, tg, uz, zhs, zht；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：乌兹别克语人口8486300明确2014年，英语9750065为另一次估计，不能将不同年份人口值视为矛盾。（置信标记：medium）
  - `uz/Q3273.json`，`article[0]`：Tojikiston (), Tojikiston Respublikasi (tojikcha. Ҷумҳурии Тоҷикистон) — Oʻrta Osiyoning janubi-sharqida joylashgan davlat. Maydoni 143.100 ming km². Aholisi 8,486,300 kishi (2014)
    中文释义：。
  - `en/Q30108.json`，`article[0]`：Tajikistan (, ; , ; ), officially the Republic of Tajikistan (), is a landlocked country in Central Asia. It has an area of  and an estimated population of 9,750,065 people. Its ca
    中文释义：。

## Tannu Uriankhai（英文锚点 1242201）

语言：en, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：中文增加历史朝代背景，英语给出近现代地理对应，两者所阅内容不构成相反当前主权判定。（置信标记：medium_preliminary）
  - `en/Q1242201.json`，`article[0]`：Tannu Uriankhai (, ; , ; ) was a historical region of the Mongol Empire (and its principal successor, the Yuan dynasty) and, later, the Qing dynasty. The territory of Tannu Uriankhai largely corresponds to the modern-day Tuva Republic of the Russian Federation, neighboring areas in Russia, and a sma
    中文释义：历史区域大致对应今俄罗斯图瓦及周边。。
  - `zht/Q26055.json`，`article[1]`：唐努烏梁海地區於漢代時有漢人活動跡象，唐朝以前，唐努烏梁海先後為匈奴、鮮卑、突厥等政權的統治區域。唐代爲都播地，前期隸屬安北都護府管轄。西遼統治時稱謙州。元朝屬嶺北行省，稱益蘭州。明代時先屬瓦剌部，再歸於東蒙古（韃靼）和喀爾喀阿拉坦汗統治。清代稱爲唐努烏梁海。清末，大批俄羅斯移民進入唐努烏梁海。
    中文释义：补充历史政权序列与清末俄罗斯移民。。

## Tanzania（英文锚点 30118）

语言：en, sw；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英斯语邻国列表基本相合；斯语补面积947303平方公里和水域比例，英语补人类起源考古。未见明确立场矛盾。（置信标记：medium）
  - `en/Q30118.json`，`article[0]`：a country in East Africa
    中文释义：东非国家。。
  - `sw/Q1191.json`，`article[1]`：947,303
    中文释义：947303。。

## Tashigang, Himachal Pradesh（英文锚点 677214）

语言：en, hi；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：两语均把Tashigang置于印度Himachal Pradesh；英语另以“according to some maps”归因有/无争议地图差异，印地语补充行政称谓Up Mohal及交通。只能确认摘录细节互补，不能据短文没有提争议就认定故意回避。（置信标记：medium）
  - `en/Q677214.json`，`article[1]`：Claims  / According to some maps, the territory is disputed between India and China, while in others it is not.
    中文释义：某些地图显示有印中争议，其他地图则没有。。
  - `hi/Q1251622.json`，`article[0]`：ताशीगंग (Tashigang), जिसे प्रशासनिक स्रोतों में अप मोहाल ताशीगंग (Up Mohal Tashigang) भी कहा जाता है, भारत के हिमाचल प्रदेश राज्य के किन्नौर ज़िले में स्थित एक गाँव है। यह सतलुज नदी की घटी में स्थित है, हालांकि स्पीति नदी भी समीप बहती है। यह तिब्बत की सीमा के बहुत पास है।
    中文释义：行政名Up Mohal Tashigang，位于印度Himachal Pradesh的Kinnaur。。

## Thailand（英文锚点 30128）

语言：en, km, lo, ms, my, th；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：面积的微小差别与人口不同需核对统计年份/口径；多个语言首段地理框架一致，不能把数字更新差异当作立场偏差。（置信标记：medium_preliminary）
  - `km/Q5402.json`，`article[1]`：ប្រទេសថៃជាប់លំដាប់ទី ៥០ ខាងផ្ទៃដីដោយមានក្រឡាផ្ទៃសរុប ៥១៣,១១៥ គម២ និងមានប្រជាជនច្រើនលំដាប់ទី ២០ នៃពិភពលោកគឺមានប្រមាណ ៦៧ លាននាក់។ ថៃជាប្រទេសឧស្សាហកម្មថ្មី មានប្រាក់ចំណូលមូលដ្ឋានបានមកពីវិស័យឧស្សាហកម្មនិងសេវាកម្ម។ ថៃមានទីកន្លែងទេសចរណ៍
    中文释义：高棉语面积513115平方公里、人口约6700万。。
  - `th/Q936.json`，`article[0]`：513,120 ตารางกิโลเมตร และมีประชากรมากเป็นอันดับที่ 20 ของโลก คือ ประมาณ 70 ล้านคน มีอาณาเขตติดต่อกับประเทศพม่าทางทิศเหนือและตะวันตก ประเทศลาวทางทิศเหนือและตะวัน
    中文释义：泰语面积513120平方公里、人口约7000万。。

## Three Pagodas Pass（英文锚点 644158）

语言：en, th；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英泰均定位于泰缅边境、同两地连接；泰语给282米高度及宗教传播路线，英文补充三塔与省徽命名。不是相互排他的领土归属。（置信标记：medium）
  - `th/Q332672.json`，`article[0]`：มีความสูง 282 เมตรเหนือระดับน้ำทะเล
    中文释义：海拔282米。
  - `en/Q644158.json`，`article[1]`：These three chedis appear in the provincial seal of Kanchanaburi Province
    中文释义：三塔出现在北碧府府徽上。

## Tibet（英文锚点 31516）

语言：dz, en, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：英语导语以1951annexation及PRC管理叙述；中文将藏区/藏文化圈分为安多、康、卫藏，并区分西藏自治区与更广传统范围。既有历史词语差异也有范围不等，比较归属应先限定文化区/自治区/历史政府管辖区；简繁同源。（置信标记：high）
  - `en/Q31516.json`，`article[0]`：Since the 1951 annexation of Tibet by the People's Republic of China
    中文释义：自1951年中华人民共和国吞并西藏以来的管理叙述。。
  - `zhs/Q1087435.json`，`article[2]`：中华人民共和国所说的「西藏」指的是西藏自治区，而传统的西藏范围包括目前受印度控制但中国声称拥有主权的藏南（与现印度管辖的阿鲁纳恰尔邦大部分重合），基本相当于清中后期和民国时期由拉萨政府所管辖的整个区域。西藏自治区以外的青海、甘肃、四川和云南四省藏族聚居区合称“四省藏区”。
    中文释义：中文区分西藏自治区与传统西藏范围。。

- **证据不足**：宗喀语Tibet文件article为空，无法完成跨语言正文比较。英文单方摘录不能用来推断宗喀语立场或沉默。（置信标记：medium）
  - `en/Q31516.json`，`article[0]`：is a region in Asia
    中文释义：西藏是亚洲的一片地区。

## Tigri Area（英文锚点 39436935）

语言：en, nl；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：两文均称1969以来由圭亚那控制，但争端起始分别约1840与1871。可能对应勘界和新河发现等不同事件，列时间候选，不能直接作为同事件矛盾。（置信标记：high）
  - `en/Q39436935.json`，`article[0]`：since around 1840
    中文释义：大约自1840年以来。。
  - `nl/Q680036.json`，`article[1]`：sinds 1871 betwist
    中文释义：自1871年以来有争议。。
  - `nl/Q680036.json`，`article[1]`：sindsdien wordt het Tigri-gebied vanuit Guyana bestuurd.
    中文释义：此后由圭亚那管理。。

## Tokelau（英文锚点 30148）

语言：en；类型：country；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Tonga（英文锚点 30158）

语言：en, to；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：英文171岛、45有人居住；汤加语176岛、52有人居住。统计年份和岛屿/居住定义未对齐，标为数值候选，不认定立场。（置信标记：high）
  - `en/Q30158.json`，`article[0]`：171 islands – of which 45 are inhabited
    中文释义：171岛，其中45岛有人居住。
  - `to/Q1585.json`，`article[0]`：ha motu 'e 176
    中文释义：176个岛。
  - `to/Q1585.json`，`article[0]`：Ko e motu fakakātoa 'e 52 'oku lolotonga nofo'i.
    中文释义：现有52个岛有人居住。。

## Trans-Karakoram Tract（英文锚点 2127184）

语言：en, hi, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：存在关于巴方实际控制的明确历史命题张力：英语明确1947以来从未由巴基斯坦控制，印地语称1948被巴控制后1963赠予中国；中文侧重边界协议确认与放弃要求。需外部史料复核，不能先判谁对。（置信标记：high）
  - `en/Q2127184.json`，`article[0]`：the Shaksgam tract was never under the control of Pakistan since 1947
    中文释义：1947年以来沙克斯干地区从未在巴基斯坦控制下。。
  - `hi/Q194025.json`，`article[0]`：१९४८ में पाकिस्तान ने अपने नियंत्रण में ले लिया।
    中文释义：1948年巴基斯坦将其置于控制下。。
  - `zhs/Q628340.json`，`article[0]`：标志着巴基斯坦放弃了对此地区的领土要求。
    中文释义：意味着巴基斯坦放弃对此地领土要求。。

## Tromelin Island（英文锚点 30178）

语言：en, fr；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **摘录未见明确差异**：英法导语均明确法国管理、毛里求斯声索；该核心命题一致，地理/生态背景可互补，不支持语言必有不同主权观点。（置信标记：medium）
  - `en/Q30178.json`，`article[0]`：Tromelin Island (; , ), once called the Isle of Sand, is a low, flat island in the Indian Ocean about  north of Réunion and about  east of Madagascar. Tromelin is administered as p
    中文释义：。
  - `fr/Q1874245.json`，`article[0]`：Lîle Tromelin est une île administrée par la France et forme partie des îles Éparses de l'océan Indien qui est rattaché aux Terres australes et antarctiques françaises. L'île est r
    中文释义：。

## Tuffah（英文锚点 22080314）

语言：ar, en；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **实体范围／清洗风险**：阿英文本同样指加沙城Tuffah街区，但本项目相应查询的声索方是黎巴嫩/叙利亚，属于检索主题错配。两语内部并无由此确立的归属冲突；应排除为跨语言国家立场偏差证据。（置信标记：high）
  - `ar/Q1200145.json`，`article[0]`：حي التفاح أحد احياء مدينة غزة ،  تعود هذه التسمية لكثرة أشجار التفاح التي كانت تنتشر في هذا الحى وهو
    中文释义：Tuffah是加沙城街区。。
  - `en/Q22080314.json`，`article[0]`：Tuffah (, translation: "the Apple") is a district of Gaza City, located northeast of the Old City and is divided into eastern and western halves. Prior to its expansion and the dem
    中文释义：Tuffah是加沙城旧城东北街区。。

## Tumen River（英文锚点 182595）

语言：en, ko, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：韩语称入海海域为东海，英中称日本海；这是地名体系差异。江源表述还存在中文天池与韩语东麓红土水的范围/支流定义候选，需水文学核对，不将其直接归为立场。（置信标记：medium）
  - `ko/Q34313.json`，`article[0]`：동해로 유입되는 강
    中文释义：流入东海的河流。
  - `en/Q182595.json`，`article[0]`：flowing into the Sea of Japan
    中文释义：流入日本海。
  - `zhs/Q96652.json`，`article[0]`：发源于长白山东南部的长白山天池
    中文释义：中文给出的江源表述。

## Turkey（英文锚点 11125639）

语言：ar, el, en, tr；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：两种导言对跨洲位置基本相合；阿拉伯语摘录另给出民族比例，英语所摘历史段以早期文明为主。只能称摘录层面的信息互补，不声称英语全文未提供比例。（置信标记：medium）
  - `en/Q11125639.json`，`article[0]`：is a transcontinental country
    中文释义：是一个跨洲国家。
  - `ar/Q6994.json`，`article[0]`：ما يقرب من 70 إلى 80 في المائة من مواطني الدولة يُعرفون أنفسهم بأنهم أتراك
    中文释义：约70%至80%的公民自认为土耳其人。

## Táliga（英文锚点 12915900）

语言：en, es, pt；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：西语导语直接称西班牙市镇，葡语导语同步注明葡萄牙声索，英语并列西班牙行政状态与葡方的法理声索；是主张显著性差异，不凭导语判断西语全文完全不提。（置信标记：medium）
  - `es/Q496234.json`，`article[0]`：Táliga (en portugués, Talega)  es un municipio español, perteneciente a la provincia de Badajoz (comunidad autónoma de Extremadura). Según el INE, en 2019 contaba con una población
    中文释义：。
  - `pt/Q135049.json`，`article[0]`：Talega ou Nossa Senhora da Assunção de Talega  é um município da Espanha (reclamado por Portugal; ver Questão de Olivença), na comarca de Llanos de Olivenza, província de Badajoz, 
    中文释义：。
  - `en/Q12915900.json`，`article[0]`：Táliga () or Talega () is a Spanish town and municipality located near the border with Portugal, in the province of Badajoz, in the Spanish autonomous community of Extremadura. Por
    中文释义：。

## Uganda（英文锚点 31816）

语言：en, sw；类型：country；状态：excerpt_screened_no_clear_difference。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Ukatny Island（英文锚点 49595901）

语言：en, ru；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：英语用现在时称争议岛，俄语用1990年代曾是争端对象，提示状态时点/更新差异；须阅读协议和修订日期再判是否事实冲突。（置信标记：high）
  - `en/Q49595901.json`，`article[2]`：Ukatnyy is a disputed island.
    中文释义：乌卡特内是一座争议岛。。
  - `ru/Q8577742.json`，`article[1]`：В 1990-е годы был предметом пограничного диспута
    中文释义：在1990年代曾是边界争端对象。。

## Ukraine（英文锚点 31750）

语言：en, ru, uk；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英俄乌导语都视为欧洲国家；俄乌两文用不同区域口径（东欧兼中欧/东欧）并不自动冲突，俄文也明确约18%被占。归属与战争叙事需具体段落而非语言判定。（置信标记：medium）
  - `ru/Q732.json`，`article[4]`：Россией фактически было оккупировано около 18 % территории Украины.
    中文释义：俄罗斯实际占领乌克兰约18%领土。。
  - `uk/Q643.json`，`article[0]`：держава, яка розташована у Східній Європі
    中文释义：位于东欧的国家。。

## Umm al Maradim Island（英文锚点 3580213）

语言：ar, en；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：两语均放于科威特南部海界；阿语保留长1.5公里宽540米，英文对应尺寸字段为空但补充珠母贝。清洗数值空缺不应当成语言立场缺失。（置信标记：medium）
  - `ar/Q35664.json`，`article[0]`：طولها كيلو متر ونصف، وعرضها 540 مترا
    中文释义：长1.5公里、宽540米。
  - `en/Q3580213.json`，`article[1]`：Pearl oysters breed around the island's seabed.
    中文释义：岛周围海床繁殖珠母贝。。

## Ungar-Too（英文锚点 66539592）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## United Arab Emirates（英文锚点 69328）

语言：ar, en, fa；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：阿文历史命名与英/波斯文联邦制度介绍互补，没有在首部发现独立的领土归属冲突。（置信标记：medium_preliminary）
  - `ar/Q739601.json`，`article[0]`：قبل 1971 كانت دولة الإمارات العربية المتحدة معروفة باسم الإمارات المتصالحة أو ساحل عُمان، في إشارة إلى هدنة في القرن 19 بين المملكة المتحدة والعديد من شيوخ العرب كما تم استخدام اسم ساحل القراصنة في إشارة إلى الإمارات في المنطقة من
    中文释义：补充1971年前停战诸酋长国/阿曼海岸名称。。
  - `fa/Q6233.json`，`article[1]`：امارات متحدهٔ عربی یک پادشاهی انتخابی از همبستگی هفت امارت است که شامل ابوظبی (پایتخت)، عجمان، دبی، فجیره، رأس‌الخیمه، شارجه، و ام‌القیوین می‌شود. هر امارت توسط یک امیر اداره می‌شود که این امیران مجلس عالی اتحاد را تشکیل می‌دهند؛ امیر ابوظبی همیشه رئیس امارات متحدهٔ عرب
    中文释义：说明七酋长国、酋长与联邦机构。。
  - `en/Q69328.json`，`article[1]`：The United Arab Emirates is an elective monarchy formed from a federation of seven emirates, consisting of Abu Dhabi (the capital), Ajman, Dubai, Fujairah, Ras Al Khaimah, Sharjah and Umm Al Quwain. Each emirate is gover
    中文释义：同样说明七酋长国的选举君主制。。

## United Kingdom（英文锚点 31717）

语言：da, en, es, fr, is；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **摘录未见明确差异**：丹麦语标题虽是Storbritannien，但首句明确完整联合王国国名；两者都包含北爱尔兰，并非本例中的大不列颠岛/英国错配。未发现明确立场差异。（置信标记：medium）
  - `en/Q31717.json`，`article[0]`：The United Kingdom of Great Britain and Northern Ireland
    中文释义：大不列颠及北爱尔兰联合王国。
  - `da/Q1894.json`，`article[0]`：officielt Det Forenede Kongerige Storbritannien og Nordirland
    中文释义：正式名称为大不列颠及北爱尔兰联合王国。

## United States（英文锚点 3434750）

语言：en, es, ht；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：三语均描述美国联邦及50州；英语补充联邦区、海外领地、原住民保留地，海地克里奥尔语解释48州连续、阿拉斯加和夏威夷分离。是行政结构细节互补，不是相互排斥的国家范围判断。（置信标记：medium）
  - `en/Q3434750.json`，`article[0]`：The United States of America (U.S.A. or USA), commonly known as the United States (U.S. or US) or America, is a country primarily located in North America. It consists of 50 states, a federal district, five major unincorporated territories, nine Minor Outlying Islands, and 326 Indian reservations. The United States is the world's third-largest country by bot
    中文释义：50州、联邦区、海外领地及原住民保留地。。
  - `ht/Q15.json`，`article[1]`：Etazini se yon peyi ki divize an 50 mòso ke yo rele Eta. 48 nan 50 mòso ki fè Lèsetazini yo kole youn ak lòt, ant Oseyan Atlantik kote solèy leve e Oseyan Pasifik kote solèy kouche, epi nan Nò li gen fwontyè ak Kanada e nan Sid fwontyè ak Meksik. De dènye Eta yo se Alaska ki sitiye nan nòdwès Kanada e Awayi, yon ti zil ki nan mitan Oseyan Pasifik.
    中文释义：50州中48州相邻，其余为阿拉斯加和夏威夷。。

## Uruguay（英文锚点 31843）

语言：en, es, pt；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：西语给行政区19省125市镇与国际组织，葡语给人口/蒙得维的亚都市圈，英文与葡文均叙述殖民历史。属于国家结构和人口信息互补。（置信标记：medium）
  - `es/Q6216.json`，`article[1]`：diecinueve departamentos y 125 municipios
    中文释义：19省、125市镇。
  - `pt/Q1873.json`，`article[1]`：fundada pelos portugueses em janeiro de 1680
    中文释义：由葡萄牙人于1680年1月建立。

## Uzbekistan（英文锚点 31853）

语言：en, ky, ru, tg, uz；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：俄文与乌兹别克语均给约3600万人并有2022日期，吉尔吉斯语给33639900且导语未给年份，属于统计更新候选。面积448924与448978也需口径核验。（置信标记：medium）
  - `ru/Q3640.json`，`article[0]`：36 006 008
    中文释义：36006008。。
  - `ky/Q1551.json`，`article[1]`：33 639 900
    中文释义：33639900。。
  - `uz/Q793.json`，`article[0]`：448,978 km2
    中文释义：448978平方公里。。

- **事实互补**：首都及中亚国家位置一致；塔吉克语摘录另给2017年人口与语言，英语历史段给古代居民。不同主题细节可互补，没有在所引句中识别边界归属冲突。（置信标记：medium）
  - `en/Q31853.json`，`article[0]`：Its capital and largest city is Tashkent
    中文释义：首都及最大城市为塔什干。
  - `tg/Q1913.json`，`article[1]`：аз 32 миллион зиёдтар мардум зиндагонӣ мекунад (2017)
    中文释义：有超过3200万人居住（2017年）。

## Vanuatu（英文锚点 32443）

语言：en, fr；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：不同族群层次与不同时段的定居信息可互补；不将简略“首先居住”与复杂迁徙史自动判为互斥种族叙事。（置信标记：medium_preliminary）
  - `en/Q32443.json`，`article[1]`：Vanuatu was first inhabited by Melanesian people. The first Europeans to visit the islands were a Spanish expedition led by Portuguese navigator Fernandes de Queirós, who arrived on the largest island
    中文释义：首先介绍美拉尼西亚人与1606欧洲探险。。
  - `fr/Q9413.json`，`article[1]`：Peuplé à partir de  av. J.-C. par des Austronésiens porteurs de la civilisation Lapita, l'archipel accueille, quelques siècles plus tard, des Mélanésiens venus des archipels de Nouvelle-Guinée. Le profil génétique du Vanuatu résulte essentiellement du métissage entre ces deux populations, austronésienne et mélanésienne, déployé 
    中文释义：详细介绍拉皮塔南岛人与后续美拉尼西亚人口混合。。

## Venezuela（英文锚点 32374）

语言：en, es；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英语记述委内瑞拉对圭亚那Esequiba声索，西语补充声索面积159542平方公里和Zona en Reclamación名称。二者都将其归因为委内瑞拉政府主张，不因西语更详细就直接判其认可该主张。（置信标记：medium）
  - `en/Q32374.json`，`article[1]`：The Venezuelan government maintains a claim against Guyana to Guayana Esequiba.
    中文释义：委内瑞拉政府维持对Guayana Esequiba的声索。。
  - `es/Q1353806.json`，`article[1]`：Posee una extensión territorial de 916 445 km². El territorio continental limita al norte con el mar Caribe y el océano Atlántico, al oeste con Colombia, al sur con Brasil y por el este con Guyana. Con este último país, el Estado venezolano mantiene una reclamación sobre 159 542 km² de territorio al oeste del río Esequibo, esta área es conocida como Guayana Esequiba o Zona en Reclamación. Por sus espacios marítimos, 
    中文释义：委内瑞拉维持159542平方公里声索，称Guayana Esequiba或声索区。。

## Vietnam（英文锚点 202354）

语言：en, ms, tl, vi, zhs, zht；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：越文历史摘录使用从北方侵略战争的视角，中文同一历史概述强调汉朝统治及文化输入，英文同时使用annexed与文化影响。这是历史叙述重点和归因差异，不足以判定事实互斥；简繁为同源。（置信标记：medium）
  - `vi/Q151863.json`，`article[1]`：các cuộc chiến tranh xâm lược từ phương Bắc
    中文释义：来自北方的侵略战争。
  - `zhs/Q1715.json`，`article[1]`：在此期间，中国文化大量输入越南。
    中文释义：该时期中国文化大量输入越南。。
  - `en/Q202354.json`，`article[1]`：The Han dynasty annexed Northern and Central Vietnam under Chinese rule from 111 BC
    中文释义：汉朝自公元前111年起吞并越南北部和中部并置于中国统治下。

- **数字／时间候选差异**：英语约9900万、他加禄语9620万，可能是人口估计年份不同。不能把人口快照差异直接视为领土政治立场或同时间事实错误。（置信标记：medium）
  - `en/Q202354.json`，`article[0]`：population of 99 million
    中文释义：人口9900万。
  - `tl/Q193387.json`，`article[0]`：populasyon nitong nasa 96.2 milyon
    中文释义：其人口约9620万。

## Vila Real（英文锚点 24719598）

语言：en, es, pt；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **实体范围／清洗风险**：三个语言文件都描述葡萄牙北部Vila Real城市，可能不是数据集所指西葡边界争议对象；此前Controller参考与该城位置不同属于主题/参考错配，不能解读为三语言观点一致证明某方主权。（置信标记：medium）
  - `en/Q24719598.json`，`article[0]`：Vila Real () is the capital and largest city of the Vila Real District, in the North region, Portugal. It is also the seat of the Douro intermunicipal community and of the Trás-os-
    中文释义：。
  - `es/Q432258.json`，`article[0]`：Vila Real  es una ciudad portuguesa, capital del distrito homónimo, situada en la región de Trás-os-Montes (Norte). Se localiza en el límite de la Terra Quente, cerca de la sierra 
    中文释义：。
  - `pt/Q21907.json`，`article[0]`：Vila Real é uma cidade portuguesa e capital da sub-região do Douro, pertencendo à região do Norte e ao distrito de Vila Real.
    中文释义：。

## Vila Thomaz Albornoz（英文锚点 70065164）

语言：en, pt；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：两文所阅主要信息一致，只是段落切分/信息位置不同，属于可对齐的同事实，不构成新观点。（置信标记：medium_preliminary）
  - `en/Q70065164.json`，`article[0]`：1985, on land ceded by rancher Thomaz Albornoz, to mark the Brazilian presence in the area.
    中文释义：补充1985年建立以标示巴西存在。。
  - `pt/Q5011710.json`，`article[1]`：A vila Albornoz foi instalada em 1985, em terras cedidas pelo estancieiro Thomaz Albornoz, para marcar a presença brasileira na área.
    中文释义：葡语第二段给出相同建立背景。。

## Vozrozhdeniya Island（英文锚点 2633156）

语言：en, ru, uz；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：两语均明确前岛屿在乌兹别克斯坦和哈萨克斯坦之间分割；俄语具体南北行政区、2001–2009/2010–2014/2015后半岛状态，英语补充苏联生物武器试验点与水体退缩。是地理演变与历史细节互补。（置信标记：medium）
  - `en/Q2633156.json`，`article[0]`：Rebirth Island (; , Vozrojdenie araly; ) was an island in the Aral Sea. The former island's territory is split between Uzbekistan and Kazakhstan. In 1954, the Soviet Union constructed a biological weapons test site called Aralsk-7 there and on the neighbouring Komsomolskiy Island, which also no longer exists.
    中文释义：原岛分属乌兹别克斯坦与哈萨克斯坦，1954年建生物武器试验场。。
  - `ru/Q203253.json`，`article[0]`：О́стров Возрожде́ния — бывший остров (в 2001—2009, в 2010—2014 и с 2015 года — полуостров) в юго-западной части Аральского моря. Территория бывшего острова после распада СССР разделена между двумя государствами: южная часть принадлежит Узбекистану (Муйнакский район Республики Каракалпакстан), северная часть бывшего острова входит в Казахстан (Аральский район Кызылординской области и Актюбинская область).
    中文释义：记载不同年份半岛状态、南北两国行政区划。。

- **数字／时间候选差异**：英语按咸海干涸后的现状称昔日岛屿并说明分属两国；乌兹别克语摘录仍称咸海中的岛并定位卡拉卡尔帕克。可能包含地貌阶段、范围或旧资料差异，应核查修订/事件时间，而非直接归因于国家立场。（置信标记：medium）
  - `en/Q2633156.json`，`article[0]`：was an island in the Aral Sea
    中文释义：曾经是咸海中的岛屿。
  - `en/Q2633156.json`，`article[0]`：The former island's territory is split between Uzbekistan and Kazakhstan.
    中文释义：昔日岛屿的领土分属乌兹别克斯坦与哈萨克斯坦。
  - `uz/Q449013.json`，`article[0]`：Orol dengizining markaziy qismidagi orol. Qoraqalpogʻiston Respublikasi hududida.
    中文释义：咸海中部的岛屿，位于卡拉卡尔帕克斯坦共和国境内。

## Wadi Halfa Salient（英文锚点 23158592）

语言：ar, en；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：两语均区分1899政治界和1902行政界；英语导语另写当前埃及控制，阿语史段写1902苏丹行政管理。不同时间与权利层级可互补，不该机械判成相反主权。（置信标记：high）
  - `en/Q23158592.json`，`article[0]`：The area is currently controlled by Egypt.
    中文释义：目前由埃及控制。。
  - `ar/Q7799372.json`，`article[1]`：وضع هذه المنطقة تحت الإدارة السودانية.
    中文释义：使该地区置于苏丹行政管理之下。。

## Wake Island（英文锚点 33189）

语言：en；类型：territory_or_related_geography；状态：single_version_or_empty_alias_not_crosslanguage_reviewed。

未在已阅摘录中确认明确差异，或仅有单一/空别名版本；不作全文无偏差结论。

## Wakhan Corridor（英文锚点 416272）

语言：en, fa, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：历史外交成因与文化交通功能是互补命题；导语侧重点不能直接推为不同主权立场。（置信标记：medium_preliminary）
  - `en/Q416272.json`，`article[1]`：The corridor was formed after an 1893 agreement between Mortimer Durand of British Raj and Emir Abdur Rahman Khan of Afghanistan, creating the Durand Line. This narrow strip acted as a buffer zone between the Russian Empire and the British Empire (the regions of Russian Turkestan, now in Tajikistan, and the part of British India now in Pakistan and
    中文释义：补充1893英阿协议与帝国间缓冲带。。
  - `zht/Q520657.json`，`article[0]`：古絲綢之路的一部分，也是華夏文明與印度文明交流的重要通道。是帕米爾高原的八帕之一。
    中文释义：突出古丝路及中华与印度文明交流。。

- **事实互补**：两篇说明中英俄势力之间的缓冲走廊；英语摘录给1893年协议，波斯语给约350公里长及8至40公里宽。时间与尺度细节互补，没有据此确认立场相反。（置信标记：medium）
  - `en/Q416272.json`，`article[1]`：formed after an 1893 agreement
    中文释义：在1893年协议之后形成。
  - `fa/Q4278097.json`，`article[0]`：طول دالان واخان حدود ۳۵۰ کیلومتر است و عرض آن از حداقل ۸ تا حداکثر ۴۰ کیلومتر تغییر می‌کند
    中文释义：瓦罕走廊约长350公里，宽8至40公里。

## West Bank（英文锚点 33209）

语言：ar, en, iw；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：希伯来语使用犹太-撒马利亚名称，且明确归因“以色列认为争议地、国际社会认为占领”；英语以巴勒斯坦领土及以军占领描述。名字、法律术语与归因不同，双方实际控制信息并非自动冲突。（置信标记：medium）
  - `iw/Q7293.json`，`article[0]`：הטריטוריה הנקראת בישראל יהודה ושומרון (בראשי תיבות: יו"ש או איו"ש), ומוכרת גם בשם הגדה המערבית (בערבית: الضِّفَّة الْغَرْبِيَّة, אַ־צִּֿפָה אַלְ־עַֿרְבִּיָּה; באנגלית: West Bank), 
    中文释义：。
  - `en/Q33209.json`，`article[0]`：The West Bank (, ; , ) is a landlocked territory near the coast of the Mediterranean in Western Asia that forms the main bulk of the Palestinian territories. It is bordered by Jord
    中文释义：。

## Yalu River（英文锚点 49559）

语言：en, ko, zhs, zht；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：英中韩均涉及鸭绿江/Amnok名称，但分别给出高句丽地名、鸭头水色说及对该说的质疑等多种词源。是竞争性词源解释候选，应保留归因，不当作主权立场。中文另提供河口航道与岛屿归属细节。（置信标记：medium）
  - `en/Q49559.json`，`article[1]`：Name / The Korean name Amnok (압록,鴨綠) is most likely derived from ancient Koreanic language of Goguryeo. In the record of Goguryeo in Samguk Sagi, the place name, Western Amnok valley (서압록곡,西鴨淥谷) appears, and this is an example of indicating that this was originally a place name used for this river by Goguryeo at that time.
    中文释义：朝鲜名称可能源自高句丽古韩语地名。。
  - `ko/Q33800.json`，`article[1]`：명칭  / 압록강이라는 이름은 그 한자만 두고 보면 '오리녹색'을 의미하는데, 1060년 송나라에서 편찬된 〈고구려전(高句麗傳)〉에 "물빛이 오리의 머리 색과 같아 압록수라 불린다(色若鴨頭 號鴨淥水)"라고 기록되어 있다. 그러나 이에 대해서는 이백의 시 양양가(襄陽歌) 중 "요간한수압두록(遙看漢水鴨頭綠, 멀리 보이는 한수는 오리의 머리처럼 푸르다.)"에서 연상해 멋대로 해석한 것이라는 견해가 유력하다.
    中文释义：记录鸭头颜色词源，同时指出有学说认为是对诗句联想的解释。。
  - `zhs/Q54463.json`，`article[1]`：名称  / 古称𬇙水，汉朝称为马訾水，唐朝始称鸭绿江（隋唐时期𬇙水为大同江），因其江水清澈，关于鸭绿江其名的来历主要流行着两种说法：一说因江水颜色似鸭头之色而得名（唐朝杜佑《通典》）；二说因上游地区有鸭江和绿江两条支流汇入，故合而为一，并称为“鸭绿江”。另有源自满语的说法（满语称为Yalu ula，意为“边界之江”）。史书记载建州卫女真常年生活在婆猪江畔（鸭绿江支流）。
    中文释义：列出鸭头水色、支流合名和满语边界之江等来源说法。。

## Yaradullu（英文锚点 18922232）

语言：az, en；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：阿塞拜疆语写法定行政归属，英语另加事实控制属亚美尼亚；应标注de jure/de facto互补，而不是直接认定两语互相否认。需结合文档修订时间理解当前状态。（置信标记：high）
  - `az/Q107443.json`，`article[0]`：Azərbaycan Respublikasının Ağstafa rayonunun inzibati ərazi vahidində kənd.
    中文释义：阿塞拜疆共和国阿格斯塔法区的村庄。。
  - `en/Q18922232.json`，`article[0]`：de facto under the control of Armenia
    中文释义：事实上处于亚美尼亚控制之下。。

## Yemen（英文锚点 350939）

语言：ar, en, so；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：阿语给2020年人口与岛屿，英文给与厄立特里亚、吉布提、索马里海界，索马里语给首都与基本邻国。没有据摘录确认相反领土立场，索马里语仍需母语审校。（置信标记：medium）
  - `ar/Q1369.json`，`article[0]`：ولدى اليمن أكثر من مائتي جزيرة
    中文释义：也门有两百多个岛屿。
  - `en/Q350939.json`，`article[0]`：shares maritime borders with Eritrea, Djibouti and Somalia.
    中文释义：与厄立特里亚、吉布提和索马里有海上边界。。

## Yukhari Askipara（英文锚点 6252076）

语言：az, en, hy；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **措辞／归因／命名差异**：三文分别突出占领、实际控制、现行政地理和遗产；属于可观察框架差异，不将历史人口称谓直接作当代主权裁定。（置信标记：medium_preliminary）
  - `az/Q90266.json`，`article[1]`：Tarixi  / Kənd 8 iyun 1992-cı ildən Ermənistan Silahlı Qüvvələrinin işğalı altındadır  / Kənd ərazisində çoxlu tarixi abidələr var: Şəkər qalası, Qatır körpüsü, Kazım körpüsü və s.
    中文释义：称1992年6月8日起处亚美尼亚武装占领。。
  - `en/Q6252076.json`，`article[0]`：currently under control by Armenia and surrounded by the Tavush Province of Armenia. The exclave has been under control by Armenian forces since the First Nagorno-Karabakh War which also included fighting in Qazakh. Toda
    中文释义：称阿塞拜疆飞地村庄，目前亚美尼亚控制。。
  - `hy/Q857556.json`，`article[0]`：Վերին Ոսկեպար՝ նախկին բնակավայր Հայաստանի Տավուշի մարզի արևելքում։ Մինչև 19-րդ դարը բնակեցված է եղել հայերով, իսկ դրանից հետո՝ մինչև ԽՍՀՄ փլուզումը՝ թուրքերով։ Հարուստ է վաղ միջնադարյան և միջնադարյան հայկական պատմամշակութային հուշարձաններով։ 
    中文释义：首述亚美尼亚塔武什原聚落和亚美尼亚文化遗产。。

## Zambia（英文锚点 34415）

语言：en, sn, sw；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **数字／时间候选差异**：绍纳语导语仍将Edgar Lungu列为总统；英语正文明确2021年8月24日Hakainde Hichilema就职。这是文档更新不同步的时间事实候选，不推断政治立场，也不据未充分核验的绍纳语方位词判断地理冲突。（置信标记：high）
  - `sn/Q4452.json`，`article[0]`：Mutungamiri wenyika iyi ndiva Edgar Lungu.
    中文释义：该国领导人为Edgar Lungu。。
  - `en/Q34415.json`，`article[52]`：On 24 August 2021, Hakainde Hichilema was sworn in as the new President of Zambia
    中文释义：2021年8月24日Hichilema宣誓就任赞比亚新总统。。

## Zaporizhzhia Oblast（英文锚点 494936）

语言：en, ru, uk；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：所阅三种语言对法理行政归属一致，英文补充2022以后事实控制；不根据俄/乌导语未出现战争而推断全文回避。（置信标记：medium_preliminary）
  - `en/Q494936.json`，`article[1]`：This oblast is an important part of Ukraine's industry and agriculture. Most of the area of the oblast has been under Russian military occupation since the 2022 Russian invasion of Ukraine, including all of the coast, although the capital and the majority of the population remains under Ukrainian administration.
    中文释义：说明俄罗斯军事占领大部地区但首府及多数人口仍乌方管理。。
  - `ru/Q21048.json`，`article[0]`：Запоро́жская о́бласть () — административно-территориальная единица Украины, расположенная на юге страны, в нижнем течении Днепра.
    中文释义：称乌克兰行政区。。
  - `uk/Q3168.json`，`article[0]`：Запорі́зька о́бласть (Запоріжжя) — адміністративна одиниця на півдні України. Утворена 10 січня 1939 року шляхом поділу Дніпропетровської області. Розташована на південному сході України, займає переважно лівобережну частину басейну нижньої течії річки Дніпро.
    中文释义：称乌克兰行政单位并给设立时间。。

## Zimbabwe（英文锚点 34399）

语言：en, sn；类型：country；状态：excerpt_screened_with_evidence_or_caveats。

- **证据不足**：绍纳语起始含指向Masvingo/2008选举的导航句，随后有国家定义；导语须跳过导航清洗后比较。初筛不足以判定立场差异。（置信标记：medium）
  - `sn/Q2131.json`，`article[0]`：Hona zveMasvingo eZimbabwe. / Kana uchitsvaga zvakawanda nezvokuvhota gore ra2008, ona nyaya iyi.
    中文释义：。
  - `en/Q34399.json`，`article[0]`：Zimbabwe (), officially the Republic of Zimbabwe, is a landlocked country in Southern Africa, between the Zambezi and Limpopo Rivers, bordered by South Africa to the south, Botswan
    中文释义：。

## plazas de soberanía（英文锚点 297276）

语言：ar, en, es；类型：territory_or_related_geography；状态：excerpt_screened_with_evidence_or_caveats。

- **事实互补**：三语均区分历史major/minor plazas与现代主要指岛礁、通常不含休达梅利利亚的用法。属历史名称范围互补，不能把这组现有导语直接标为西/阿归属观点相反。（置信标记：medium）
  - `en/Q297276.json`，`article[1]`：Historically, a distinction was made between the so-called "major places of sovereignty", comprising the autonomous cities of Ceuta and Melilla, and the "minor places of sovereignty", referring to a number of islands (and a small peninsula) along the coast. In the present, the term refers mainly to the latter.
    中文释义：历史major含Ceuta/Melilla，当前主要指minor。。
  - `ar/Q891711.json`，`article[0]`：بلاثاس دي سوبيرانيا  وتعني («مواقع السيادة»)، وكان تسمى سابقاً (شمال أفريقيا الإسبانية) أو (أفريقيا الإسبانية) هي حالياً الأراضي الإسبانية في شمال أفريقيا على الحدود مع المغرب، ما عدا مدن الحكم الذاتي لمدينتي سبتة ومليلية.
    中文释义：现代西班牙北非领土，但不包括Ceuta/Melilla自治城市。。
  - `es/Q45549.json`，`article[0]`：Plazas de soberanía es el término histórico con el que se denominan desde el  a los territorios españoles situados en el norte de África, en contraposición a las áreas que constituían el protectorado español de Marruecos. En la actualidad, esta nomenclatura sigue utilizándose para la identificación de las islas y peñones frente a la costa norte de Marruecos, pero no para referirse a las ciudades autónomas de Ceuta y Melilla, que sin emb
    中文释义：当前通常指摩洛哥近岸岛礁，而不含两自治城市。。

