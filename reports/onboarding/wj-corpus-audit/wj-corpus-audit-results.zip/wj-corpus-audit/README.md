# WJ 全量跨语言审计结果包

先读REPORT.md与FIELD_MAPPING.md。全部原始文件和段落做结构/关联检查；内容为全主题导语与关键词摘录初筛，关键案例补查完整段落，不是多语专家全文偏见裁定。所有引用均附路径/paragraph_index并经精确子串校验。候选实体按metadata和标题/导语对齐，非全球Wikidata验证。

用浏览器打开viewer.html，可离线搜索主题、原文、中文解释和语言并筛选类型。完整逐项清单在ALL_TOPICS.md、all_topic_reviews.json及all_findings.csv；原文全部段落可查paragraphs.jsonl。源码未修改、未新增模型推理。原始WJ_data.zip不重复打包，可从REPORT来源下载并比对SHA。
