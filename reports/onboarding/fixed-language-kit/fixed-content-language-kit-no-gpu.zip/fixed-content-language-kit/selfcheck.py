"""CPU-only functional tests. Synthetic fixtures NEVER represent model results."""
import copy
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from common import KIT, load, save, digest, freeze, messages

base = load(KIT / 'data/base.json')
unique = {d['doc_key']: d for ds in base['evidence_by_territory'].values() for d in ds}
draft = [{'doc_key': k, 'target_language': lang, 'source_sha256': digest(d['text']),
          'source_text': d['text'], 'translation': 'SYNTHETIC TEST ONLY: '+d['text'],
          'reviewed': True, 'reviewed_by': 'selfcheck-fixture'}
         for k, d in unique.items() for lang in ['zh', 'ru']]
frozen = freeze(base, draft)
assert len(frozen['records']) == len(base['queries'])
for r in frozen['records']:
    assert len(r['variants']['en']) == len(r['variants']['zh']) == len(r['variants']['ru'])
    assert r['variants']['en'] == [d['text'] for d in r['documents']]
bad = copy.deepcopy(draft)
bad[0]['reviewed'] = False
try:
    freeze(base, bad)
except AssertionError:
    pass
else:
    raise AssertionError('Unreviewed translations were accepted')
bad = copy.deepcopy(draft)
bad[0]['source_sha256'] = 'invalid'
try:
    freeze(base, bad)
except AssertionError:
    pass
else:
    raise AssertionError('Stale source hashes were accepted')
with tempfile.TemporaryDirectory(prefix='fixed-language-selfcheck-') as name:
    root = Path(name)
    for f in ['score.py', 'common.py']:
        shutil.copy(KIT / f, root / f)
    shutil.copytree(KIT / 'vendor', root / 'vendor')
    save(root / 'data/frozen.json', frozen)
    sha = digest((root / 'data/frozen.json').read_bytes())
    save(root / 'data/frozen.lock.json', {'sha256': sha})
    for model in ['llama', 'qwen']:
        out = root / 'results' / model
        save(out / 'config.json', {'frozen_sha256': sha, 'qids': [q['qid'] for q in base['queries']]})
        answers = []
        for q in base['queries']:
            choice = q['controller'] if q['controller'] != 'Unknown' else q['claimants'][0]
            for lang in ['en', 'zh', 'ru', 'no_ir']:
                answers.append(dict(q, evidence_language=lang, canonical_choice=choice, input_tokens=1))
        (out / 'answers.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in answers))
    result = subprocess.run([sys.executable, str(root / 'score.py'), '--results', str(root / 'results'),
                             '--bootstrap', '100'], capture_output=True, text=True)
    assert result.returncode == 0, result.stdout + result.stderr
    report = load(root / 'results/analysis.json')
    for v in report['models'].values():
        assert all(p['flip_rate_query_weighted'] == 0 for p in v['language_pairs'])
        assert all(m['official_CS']['status'] == 'passed' for m in v['metrics_by_evidence_language'].values())
print(json.dumps({'CPU_selfcheck': 'passed', 'checks': [
    'paired document identities and counts', 'unreviewed/stale translation rejection',
    'official CS on synthetic fixtures', 'zero-flip fixture and paired analysis'],
    'not_tested_here': ['RTX4090 execution', 'real translations', '7B/8B generation'],
    'warning': 'Synthetic fixture output is not an experimental finding'}, indent=2))
