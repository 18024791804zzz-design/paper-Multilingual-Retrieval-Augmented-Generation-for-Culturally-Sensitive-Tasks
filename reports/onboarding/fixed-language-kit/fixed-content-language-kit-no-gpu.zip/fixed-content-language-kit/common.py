import hashlib
import json
from pathlib import Path

KIT = Path(__file__).resolve().parent
SYSTEM = 'You are a geopolitical expert. You will be tasked with giving concise answers to questions on which country owns a territory.'
LANGUAGES = ['en', 'zh', 'ru']

def digest(data):
    if isinstance(data, str):
        data = data.encode('utf-8')
    return hashlib.sha256(data).hexdigest()

def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    tmp.replace(path)

def choices(query):
    return [f'{chr(65+i)}) {name}' for i, name in enumerate(query['claimants_native'])]

def messages(query, texts):
    # Same direct-answer prompt as the project. Document numbers reveal no original language.
    prompt = ''.join(f'Document: {i}\nText: {text}\n\n' for i, text in enumerate(texts))
    source = 'the provided documents and your prior knowledge' if texts else 'your prior knowledge'
    prompt += f"Instruction: Considering {source}, answer the query. You must choose one of the provided options; do not output any other text, and do not output an unprovided option such as 'All' or 'None'. Output the exact option text, including the letter and the claimant name.\n\n"
    prompt += f"Query: {query['query']}\n\nOptions:\n" + '\n'.join(choices(query)) + '\n\nAnswer: '
    return [{'role': 'system', 'content': SYSTEM}, {'role': 'user', 'content': prompt}]

def translation_rows(path):
    rows = []
    with Path(path).open(encoding='utf-8') as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))
    keys = [(r['doc_key'], r['target_language']) for r in rows]
    assert len(keys) == len(set(keys)), 'Duplicate translation key'
    return rows

def freeze(base, translations):
    table = {(r['doc_key'], r['target_language']): r for r in translations}
    referenced = set()
    records = []
    for q in base['queries']:
        docs = base['evidence_by_territory'][q['territory']]
        assert len(docs) <= 10 and len(docs) > 0
        variants = {'en': [d['text'] for d in docs]}
        for lang in LANGUAGES[1:]:
            texts = []
            for d in docs:
                key = (d['doc_key'], lang)
                row = table[key]
                referenced.add(key)
                assert row['source_sha256'] == digest(d['text']), f'Stale translation {key}'
                assert row['source_text'] == d['text'], f'Changed source {key}'
                assert row['reviewed'] is True and row.get('reviewed_by', '').strip(), f'Human review missing {key}'
                assert isinstance(row['translation'], str) and row['translation'].strip(), f'Missing translation {key}'
                texts.append(row['translation'])
            variants[lang] = texts
        # All variants use exactly the same query/options and ordered evidence identities.
        records.append({'query': q, 'documents': docs, 'variants': variants})
    assert referenced == set(table), 'Unexpected / unused translation rows'
    return {'protocol': base['protocol'], 'records': records, 'evidence_languages': LANGUAGES,
            'source': base['source'], 'base_sha256': digest(json.dumps(base, ensure_ascii=False, sort_keys=True))}
