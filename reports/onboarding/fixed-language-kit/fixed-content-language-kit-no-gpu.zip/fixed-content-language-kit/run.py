"""One GPU / one model. Original project free-prefix candidate selection, cached."""
import argparse
import json
import os
import resource
import time
from pathlib import Path
from common import KIT, load, save, digest, choices, messages

p = argparse.ArgumentParser()
p.add_argument('--model', choices=['llama', 'qwen'], required=True)
p.add_argument('--out', type=Path, required=True)
p.add_argument('--conditions', nargs='+', choices=['en', 'zh', 'ru', 'no_ir'], default=['en', 'zh', 'ru', 'no_ir'])
p.add_argument('--max-input-tokens', type=int, default=8192)
p.add_argument('--limit-queries', type=int)
p.add_argument('--preflight-only', action='store_true')
p.add_argument('--validate-cache', action='store_true')
p.add_argument('--reference-no-cache', action='store_true', help='Original full-prefix forwards; slower fallback')
a = p.parse_args()
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, set_seed

assert torch.cuda.is_available() and torch.cuda.is_bf16_supported()
torch.set_num_threads(8)
torch.backends.cuda.matmul.allow_tf32 = False
torch.backends.cudnn.allow_tf32 = False
set_seed(4321)
raw = (KIT / 'data/frozen.json').read_bytes()
assert digest(raw) == load(KIT / 'data/frozen.lock.json')['sha256'], 'Frozen input changed'
frozen = json.loads(raw)
spec = load(KIT / 'models.json')[a.model]
path = Path(os.environ['EXP_ROOT']) / 'models' / spec['directory']
assert load(path / 'experiment_download.json') == spec, 'Unverified model revision'
tok = AutoTokenizer.from_pretrained(path, local_files_only=True)
records = frozen['records']
if a.limit_queries:
    records = records[:a.limit_queries]
jobs = []
for record in records:
    q = record['query']
    candidates = []
    for c in choices(q):
        ids = tok(c, add_special_tokens=False).input_ids
        eot = tok.convert_tokens_to_ids('<|eot_id|>')
        if eot is not None:
            ids += [eot]
        assert len(ids) <= 50, f'Candidate exceeds fixed 50-step scoring budget: {q["qid"]}'
        candidates.append(ids)
    for lang in a.conditions:
        texts = [] if lang == 'no_ir' else record['variants'][lang]
        ms = messages(q, texts)
        ids = tok.apply_chat_template(ms, add_generation_prompt=True, return_tensors='pt', add_special_tokens=True)
        assert ids.shape[1] <= a.max_input_tokens, f'Context too long; do not truncate: {q["qid"]}/{lang} {ids.shape[1]}'
        jobs.append((record, lang, ms, ids, candidates))
a.out.mkdir(parents=True, exist_ok=True)
save(a.out / 'preflight.json', {'model': spec, 'queries': len(records), 'jobs': len(jobs),
    'max_input_tokens_observed': max(j[3].shape[1] for j in jobs),
    'input_tokens': [{'qid': j[0]['query']['qid'], 'condition': j[1], 'tokens': j[3].shape[1]} for j in jobs]})
if a.preflight_only:
    print('Tokenizer/context preflight passed; model not loaded.')
    raise SystemExit(0)

config = {'frozen_sha256': digest(raw), 'model': spec, 'dtype': 'bfloat16', 'attention': 'sdpa',
          'selection': 'project_free_prefix_50_literal_eot_no_length_normalization',
          'log_softmax_dtype': 'float32', 'use_KV_cache': not a.reference_no_cache,
          'steps': 50, 'seed': 4321, 'do_sample': False,
          'max_input_tokens': a.max_input_tokens, 'conditions': a.conditions,
          'qids': [r['query']['qid'] for r in records], 'torch': torch.__version__,
          'runner_sha256': digest(Path(__file__).read_bytes()),
          'common_sha256': digest((KIT / 'common.py').read_bytes())}
config_path = a.out / 'config.json'
if config_path.exists():
    assert load(config_path) == config, 'Configuration changed; use a NEW output directory'
else:
    save(config_path, config)
answers_path = a.out / 'answers.jsonl'
done = {}
if answers_path.exists():
    for line in answers_path.read_text().splitlines():
        if line.strip():
            row = json.loads(line)
            key = (row['qid'], row['evidence_language'])
            assert key not in done
            done[key] = row

t0 = time.perf_counter()
model = AutoModelForCausalLM.from_pretrained(path, local_files_only=True,
        torch_dtype=torch.bfloat16, device_map={'': 0}, low_cpu_mem_usage=True,
        attn_implementation='sdpa').eval()
torch.cuda.synchronize()
load_seconds = time.perf_counter() - t0
assert max(j[3].shape[1] for j in jobs) + 50 <= model.config.max_position_embeddings

def forward_scores(ids, steps, cached=True):
    current = ids.to('cuda')
    past = None
    probs, generated = [], []
    with torch.inference_mode():
        for _ in range(steps):
            out = model(input_ids=current, past_key_values=past if cached else None,
                        use_cache=cached, logits_to_keep=1, return_dict=True)
            lp = torch.log_softmax(out.logits[:, -1, :].float(), dim=-1)
            nxt = lp.argmax(-1, keepdim=True)
            probs.append(lp.squeeze(0).cpu().numpy())
            generated.append(nxt.item())
            if cached:
                past = out.past_key_values
                current = nxt
            else:
                current = torch.cat([current, nxt], dim=-1)
            del out, lp
    del past
    return probs, generated

def candidate_scores(probs, candidates):
    # The candidate tokens are evaluated on the SAME freely generated prefix,
    # as in the project. This is NOT teacher-forced candidate likelihood.
    return [float(sum(float(probs[i][token]) for i, token in enumerate(ids))) for ids in candidates]

if a.validate_cache:
    assert not a.reference_no_cache, 'Choose validation or reference fallback'
    # Shortest RAG prompt, all 50 steps. Report numerical deviations on this GPU.
    job = min((j for j in jobs if j[1] != 'no_ir'), key=lambda j: j[3].shape[1])
    ref, rt = forward_scores(job[3], 50, False)
    got, gt = forward_scores(job[3], 50, True)
    rs, gs = candidate_scores(ref, job[4]), candidate_scores(got, job[4])
    delta = max(abs(x-y) for x, y in zip(rs, gs))
    ok = rt == gt and delta <= 0.1 and int(np.argmax(rs)) == int(np.argmax(gs))
    save(a.out / 'cache_validation.json', {'qid': job[0]['query']['qid'], 'condition': job[1],
         'tokens_identical': rt == gt, 'score_max_error': delta, 'score_tolerance': 0.1,
         'reference_scores': rs, 'cached_scores': gs, 'passed': ok})
    assert ok, 'BF16 cache comparison failed; inspect before main run. Do not silently change the protocol.'
    del ref, got

for record, lang, ms, ids, candidates in jobs:
    q = record['query']
    key = (q['qid'], lang)
    if key in done:
        continue
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    t = time.perf_counter()
    probs, generated = forward_scores(ids, 50, not a.reference_no_cache)
    scores = candidate_scores(probs, candidates)
    index = int(np.argmax(scores))
    torch.cuda.synchronize()
    elapsed = time.perf_counter() - t
    row = dict(q, model=a.model, evidence_language=lang,
        canonical_choice=q['claimants'][index], claimant_ind=index,
        selected_option=choices(q)[index], candidate_scores=scores,
        raw_generated=tok.decode(generated, skip_special_tokens=False),
        messages=ms, input_tokens=ids.shape[1], generated_tokens=50,
        document_keys=[] if lang == 'no_ir' else [d['doc_key'] for d in record['documents']],
        top_k_language_counts={} if lang == 'no_ir' else {lang: len(record['documents'])},
        generation_seconds=elapsed, peak_cuda_allocated_GiB=torch.cuda.max_memory_allocated()/2**30,
        peak_cuda_reserved_GiB=torch.cuda.max_memory_reserved()/2**30,
        process_peak_RSS_GiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/2**20)
    with answers_path.open('a', encoding='utf-8') as f:
        f.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + '\n')
        f.flush()
        os.fsync(f.fileno())
    done[key] = row
    print(json.dumps({'model': a.model, 'qid': q['qid'], 'language': lang,
                      'answer': row['canonical_choice'], 'seconds': round(elapsed, 2),
                      'peak_GPU_GiB': row['peak_cuda_reserved_GiB']}, ensure_ascii=False), flush=True)
    del probs
save(a.out / 'run_report.json', {'model': a.model, 'load_seconds_this_invocation': load_seconds,
    'completed_jobs': len(done), 'expected_jobs': len(jobs), 'failures': 0,
    'sum_generation_seconds_including_resumed_rows': sum(r['generation_seconds'] for r in done.values()),
    'process_peak_RSS_GiB': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/2**20})
