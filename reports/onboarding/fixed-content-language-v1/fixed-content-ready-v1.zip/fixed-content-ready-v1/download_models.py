import argparse
import json
import os
from pathlib import Path
from huggingface_hub import snapshot_download

p = argparse.ArgumentParser()
p.add_argument('--models', nargs='+', choices=['llama', 'qwen', 'translator'], default=['llama', 'qwen'])
p.add_argument('--workers', type=int, default=2)
a = p.parse_args()
kit = Path(__file__).resolve().parent
root = Path(os.environ['EXP_ROOT'])
specs = json.loads((kit / 'models.json').read_text())
for name in a.models:
    spec = specs[name]
    target = root / 'models' / spec['directory']
    patterns = ['*.json', 'tokenizer.*', '*.txt', '*.tiktoken', '*.bpe', 'sentencepiece.bpe.model']
    patterns += ['pytorch_model.bin'] if name == 'translator' else ['*.safetensors']
    print(f'Downloading {spec["repo"]}@{spec["revision"]} to {target}', flush=True)
    snapshot_download(repo_id=spec['repo'], revision=spec['revision'],
                      local_dir=str(target), allow_patterns=patterns,
                      max_workers=a.workers)
    (target / 'experiment_download.json').write_text(json.dumps(spec, indent=2))
    print(f'Completed {name}', flush=True)
