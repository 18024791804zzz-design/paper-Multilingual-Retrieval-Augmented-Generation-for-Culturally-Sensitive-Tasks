#!/usr/bin/env bash
# Set EXP_ROOT to a directory on the persistent DATA disk before sourcing.
: "${EXP_ROOT:?First export EXP_ROOT=/your/data/disk/fixed-language-rag}"
export EXP_ROOT
export HF_HOME="$EXP_ROOT/cache/huggingface"
export HF_HUB_CACHE="$HF_HOME/hub"
export XDG_CACHE_HOME="$EXP_ROOT/cache"
export TORCH_HOME="$EXP_ROOT/cache/torch"
export PIP_CACHE_DIR="$EXP_ROOT/cache/pip"
export TMPDIR="$EXP_ROOT/tmp"
export TOKENIZERS_PARALLELISM=false
export PYTHONDONTWRITEBYTECODE=1
export CUBLAS_WORKSPACE_CONFIG=:4096:8
mkdir -p "$EXP_ROOT" "$HF_HOME" "$TORCH_HOME" "$PIP_CACHE_DIR" "$TMPDIR" "$EXP_ROOT/models" "$EXP_ROOT/results" "$EXP_ROOT/logs"
