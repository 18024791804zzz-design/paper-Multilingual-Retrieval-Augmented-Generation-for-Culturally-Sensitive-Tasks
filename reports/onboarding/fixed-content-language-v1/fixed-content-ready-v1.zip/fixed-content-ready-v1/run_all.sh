#!/usr/bin/env bash
set -euo pipefail
KIT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
source "$KIT_DIR/env.sh"
source "$EXP_ROOT/venv/bin/activate"
export HF_HUB_OFFLINE=1
export HF_DATASETS_OFFLINE=1
for EXP_MODEL in llama qwen; do
  python "$KIT_DIR/run.py" --model "$EXP_MODEL" --out "$EXP_ROOT/results/fixed-language-v1/$EXP_MODEL" --validate-cache
done
python "$KIT_DIR/score.py" --results "$EXP_ROOT/results/fixed-language-v1"
