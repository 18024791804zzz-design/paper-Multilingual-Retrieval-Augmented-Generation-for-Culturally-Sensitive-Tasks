"""Check local metadata, tokenizers and safetensors structure without loading weights.

No internet required. Checks are structural, not cryptographic verification of
every tensor value, and do not establish that GPU inference will succeed.
"""
import argparse
import json
import os
from pathlib import Path
from safetensors import safe_open
from transformers import AutoConfig, AutoTokenizer
from common import KIT, load, save, messages

p = argparse.ArgumentParser()
p.add_argument('--models', nargs='+', choices=['llama', 'qwen'], default=['llama', 'qwen'])
a = p.parse_args()
root = Path(os.environ['EXP_ROOT'])
specs = load(KIT / 'models.json')
base = load(KIT / 'data/base.json')
report = {'GPU_inference_performed': False, 'models': {}}
for name in a.models:
    spec = specs[name]
    path = root / 'models' / spec['directory']
    assert load(path / 'experiment_download.json') == spec, 'Model snapshot marker differs'
    config = AutoConfig.from_pretrained(path, local_files_only=True)
    assert config.model_type == {'llama': 'llama', 'qwen': 'qwen2'}[name]
    tok = AutoTokenizer.from_pretrained(path, local_files_only=True)
    assert tok.chat_template, 'Chat template is missing'
    index = load(path / 'model.safetensors.index.json')
    weight_map = index['weight_map']
    filenames = sorted(set(weight_map.values()))
    total_bytes, checked_tensors = 0, 0
    for filename in filenames:
        shard = path / filename
        assert shard.is_file(), f'Missing weight shard: {shard}'
        with safe_open(shard, framework='pt', device='cpu') as f:
            expected = {key for key, value in weight_map.items() if value == filename}
            assert set(f.keys()) == expected, f'Weight index mismatch: {filename}'
            checked_tensors += len(expected)
        total_bytes += shard.stat().st_size
    samples = []
    for q in base['queries']:
        docs = [d['text'] for d in base['evidence_by_territory'][q['territory']]]
        ids = tok.apply_chat_template(messages(q, docs), add_generation_prompt=True,
                                     tokenize=True, add_special_tokens=True)
        assert ids and min(ids) >= 0 and max(ids) < config.vocab_size
        samples.append({'qid': q['qid'], 'input_tokens_English_evidence': len(ids)})
    report['models'][name] = {'status': 'passed', 'revision': spec['revision'],
        'model_type': config.model_type, 'weight_shards': len(filenames),
        'checked_tensor_headers': checked_tensors, 'weight_files_GiB': total_bytes/2**30,
        'tokenizer_queries_checked': len(samples),
        'max_input_tokens_English_evidence': max(s['input_tokens_English_evidence'] for s in samples),
        'scope': 'Metadata/header/tokenization checks only; full tensor values and GPU execution not verified'}
save(root / 'models_cpu_verification.json', report)
print(json.dumps(report, ensure_ascii=False, indent=2))
