import json
import numpy as np
import torch

assert torch.cuda.is_available(), "CUDA unavailable: inspect host driver/container GPU allocation"
assert torch.cuda.is_bf16_supported(), "BF16 unavailable on this GPU/driver"
x = torch.arange(4, dtype=torch.float32)
assert np.array_equal(torch.from_numpy(x.numpy()).numpy(), np.arange(4, dtype=np.float32))
with torch.inference_mode():
    a = torch.randn(256, 256, device="cuda", dtype=torch.bfloat16)
    b = a @ a.T
torch.cuda.synchronize()
print(json.dumps({"torch": torch.__version__, "wheel_cuda": torch.version.cuda,
                  "GPU": torch.cuda.get_device_name(0), "bf16": True,
                  "tensor_numpy_roundtrip": "passed", "GPU_matmul": "passed"}, indent=2))
