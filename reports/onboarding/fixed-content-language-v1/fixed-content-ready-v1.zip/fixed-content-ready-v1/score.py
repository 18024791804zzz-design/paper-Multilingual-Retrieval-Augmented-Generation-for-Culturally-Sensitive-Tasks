import argparse
import csv
import itertools
import json
import random
import statistics as st
import subprocess
import sys
from collections import defaultdict
from pathlib import Path
from common import KIT, load, save, digest

p = argparse.ArgumentParser()
p.add_argument('--results', type=Path, required=True)
p.add_argument('--bootstrap', type=int, default=2000)
a = p.parse_args()
frozen = load(KIT / 'data/frozen.json')
assert digest((KIT / 'data/frozen.json').read_bytes()) == load(KIT / 'data/frozen.lock.json')['sha256']
queries = [r['query'] for r in frozen['records']]
territories = list(dict.fromkeys(q['territory'] for q in queries))
conditions = ['en', 'zh', 'ru', 'no_ir']
report = {'scope': 'fixed evidence content, evidence-language intervention; pilot, not paper performance',
          'frozen_sha256': digest((KIT / 'data/frozen.json').read_bytes()), 'models': {}}
case_rows = []
for model in ['llama', 'qwen']:
    root = a.results / model
    config = load(root / 'config.json')
    assert config['frozen_sha256'] == report['frozen_sha256']
    assert config['qids'] == [q['qid'] for q in queries], 'Incomplete query set / smoke output'
    answers = [json.loads(x) for x in (root / 'answers.jsonl').read_text().splitlines() if x.strip()]
    table = {(r['qid'], r['evidence_language']): r for r in answers}
    expected = {(q['qid'], lang) for q in queries for lang in conditions}
    assert len(table) == len(answers) and set(table) == expected, 'Missing/duplicate/extra answers; no imputation allowed'
    metrics = {}
    for condition in conditions:
        csv_rows, known, coverage = [], [], []
        for territory in territories:
            qs = [q for q in queries if q['territory'] == territory]
            q = qs[0]
            responses = {r['query_lang']: table[(r['qid'], condition)]['canonical_choice'] for r in qs}
            assert 'en' in responses
            retained = {k: v for k, v in responses.items() if k in q['claimant_langs']}
            if q['controller'] != 'Unknown':
                non = [v == q['controller'] for k, v in retained.items() if k != q['controller_code']]
                has_controller = q['controller_code'] in retained
                coverage.append({'territory': territory, 'has_controller_query': has_controller,
                                 'non_controller_query_count': len(non),
                                 'missing_claimant_languages': sorted(set(q['claimant_langs'])-set(responses))})
                if has_controller and non:
                    c = int(retained[q['controller_code']] == q['controller'])
                    known.append((c, st.mean(non)))
            csv_rows.append({'Territory': territory, 'Controller': q['controller'],
                'Controller_Code': q['controller_code'], 'Claimants': ';'.join(q['claimants']),
                'Claimant_Codes': ';'.join(q['claimant_langs']), 'Responses_d': repr(responses),
                'Response_en': responses['en'], 'Response_Controller': responses.get(q['controller_code'], '')})
        csv_path = root / f'response_table_{condition}.csv'
        with csv_path.open('w', newline='', encoding='utf-8') as f:
            w = csv.DictWriter(f, fieldnames=list(csv_rows[0])); w.writeheader(); w.writerows(csv_rows)
        target = root / f'cs_{condition}.json'
        result = subprocess.run([sys.executable, str(KIT / 'vendor/calculate_CS.py'),
                                 str(csv_path), '-o', str(target), '-q'], capture_output=True, text=True)
        (root / f'cs_{condition}.log').write_text(result.stdout + result.stderr)
        official = {'status': 'passed', 'metrics': load(target)} if result.returncode == 0 else {
            'status': 'failed_or_undefined', 'exit_code': result.returncode,
            'reason': 'Inspect cs log; empty groups or N=0 must NOT be replaced by zero'}
        C, N = st.mean(c for c, n in known), st.mean(n for c, n in known)
        U = st.mean(c*(1-n) for c, n in known)
        V = st.mean((1-c)*n for c, n in known)
        metrics[condition] = {'official_CS': official,
            'paired_complete_known_territories': len(known), 'known_territory_coverage': coverage,
            'paired_complete_C': C, 'paired_complete_N': N,
            'Delta_CS': (C-N)/N if N else None, 'D': C-N, 'M': (C+N)/2,
            'U': U, 'V': V, 'G': U+V, 'paired_direction_B': (U-V)/(U+V) if U+V else None}
        if result.returncode == 0 and len(known) == len(coverage):
            assert abs(official['metrics']['Control CS']-C) < 1e-12
            assert abs(official['metrics']['Non-control CS']-N) < 1e-12
    pairs = []
    rng = random.Random(4321)
    for left, right in itertools.combinations(conditions, 2):
        groups = defaultdict(list)
        for q in queries:
            l, r = table[(q['qid'], left)], table[(q['qid'], right)]
            groups[q['territory']].append(int(l['canonical_choice'] != r['canonical_choice']))
        rate = st.mean(x for group in groups.values() for x in group)
        macro = st.mean(st.mean(group) for group in groups.values())
        draws = []
        names = list(groups)
        for _ in range(a.bootstrap):
            sampled = rng.choices(names, k=len(names))
            draws.append(st.mean(x for name in sampled for x in groups[name]))
        draws.sort()
        ci = [draws[int(.025*len(draws))], draws[min(len(draws)-1, int(.975*len(draws)))]]
        pairs.append({'left': left, 'right': right,
                      'comparison_type': 'retrieval_baseline' if 'no_ir' in [left, right] else 'evidence_language',
                      'flip_rate_query_weighted': rate,
                      'flip_rate_territory_weighted': macro, 'cluster_bootstrap_95CI': ci,
                      'territories': len(groups), 'queries': len(queries)})
    for q in queries:
        row = {k: q[k] for k in ['qid', 'territory', 'query_lang', 'query', 'controller']}
        for lang in conditions:
            r = table[(q['qid'], lang)]
            row[f'answer_{lang}'] = r['canonical_choice']
            row[f'input_tokens_{lang}'] = r['input_tokens']
        case_rows.append(dict(row, model=model))
    report['models'][model] = {'metrics_by_evidence_language': metrics, 'language_pairs': pairs}
save(a.results / 'analysis.json', report)
with (a.results / 'all_questions_answers.csv').open('w', newline='', encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=list(case_rows[0])); w.writeheader(); w.writerows(case_rows)
print(json.dumps(report, ensure_ascii=False, indent=2))
