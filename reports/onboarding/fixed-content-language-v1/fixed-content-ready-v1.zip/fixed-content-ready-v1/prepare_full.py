"""Optional: construct full 720-query inputs from the original borderlines.zip.

Run in a SEPARATE copy of this kit: this replaces that copy's pilot base/drafts.
Downloads native query Arrow data only, not executable dataset loader code.
"""
import argparse
import csv
import io
import json
from pathlib import Path
from zipfile import ZipFile
from datasets import Dataset
from huggingface_hub import hf_hub_download
from common import KIT, save, digest

p = argparse.ArgumentParser()
p.add_argument('--zip', type=Path, required=True)
p.add_argument('--native-revision', required=True, help='Pinned commit of manestay/borderlines dataset')
p.add_argument('--replace-pilot', action='store_true')
a = p.parse_args()
assert a.replace_pilot, 'Use a separate kit copy, then pass --replace-pilot'
assert not (KIT / 'data/frozen.json').exists(), 'Already frozen; make a new experiment copy'
countries = {r['Country']: r['Lang_Code'] for r in json.loads((KIT / 'data/countries.json').read_text())}
with ZipFile(a.zip) as z:
    rows = list(csv.DictReader(io.StringIO(z.read('data/queries.tsv').decode()), delimiter='\t'))
    docs = json.loads(z.read('data/all_docs.json'))
    hrows = list(csv.DictReader(io.StringIO(z.read('data/control/openai/qlang/control_query_hits.tsv').decode()), delimiter='\t'))
assert len(rows) == 720, 'Unexpected query archive version'
natives = {}
for lang in sorted({r['language'] for r in rows} - {'en'}):
    path = hf_hub_download('manestay/borderlines', f'queries/{lang}/data-00000-of-00001.arrow',
                           repo_type='dataset', revision=a.native_revision)
    natives[lang] = {r['QueryID']: r for r in Dataset.from_file(path)}
queries = []
evidence = {}
for r in rows:
    lang = r['language']
    qid = r['territory'].replace(' ', '_') + '_' + lang
    claimants = r['Claimants'].split(';')
    names = claimants if lang == 'en' else natives[lang][qid]['Claimants_Native']
    assert len(names) == len(claimants)
    if lang != 'en':
        assert ' '.join(natives[lang][qid]['Query_Native'].split()) == ' '.join(r['query_text'].split())
    for i, name in enumerate(names):
        assert f'{chr(65+i)}) {name}' in r['query_text']
    codes = list(dict.fromkeys(countries[c] for c in claimants))
    queries.append({'qid': qid, 'raw_query_id': r['query_id'], 'territory': r['territory'],
        'query': r['query_text'], 'query_lang': lang, 'claimants': claimants,
        'claimants_native': names, 'claimant_langs': codes, 'controller': r['Controller'],
        'controller_code': countries.get(r['Controller'], '')})
    if lang == 'en':
        hits = sorted((h for h in hrows if h['query_id'] == r['query_id']), key=lambda h: int(h['rank']))[:10]
        assert hits and all(h['doc_lang'] == 'en' for h in hits)
        evidence[r['territory']] = [{'doc_key': 'en/'+h['doc_id'], 'pid': h['doc_id'],
            'language': 'en', 'rank': int(h['rank']), 'score': float(h['score']),
            'text': docs['en'][h['doc_id']]} for h in hits]
assert len(evidence) == 251
base = {'protocol': 'FixedContent-EvidenceLanguage-v1 full720; same settings as pilot',
    'source': {'archive_sha256': digest(a.zip.read_bytes()), 'native_dataset_revision': a.native_revision},
    'queries': queries, 'evidence_by_territory': evidence}
save(KIT / 'data/base.json', base)
unique = {d['doc_key']: d for ds in evidence.values() for d in ds}
drafts = [{'doc_key': k, 'source_sha256': digest(d['text']), 'source_text': d['text'],
    'target_language': lang, 'translation': '', 'reviewed': False,
    'reviewed_by': '', 'review_notes': ''} for k, d in unique.items() for lang in ['zh', 'ru']]
(KIT / 'data/translations.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False)+'\n' for r in drafts))
save(KIT / 'data/stats.json', {'queries': len(queries), 'territories': len(evidence),
    'unique_paragraphs': len(unique), 'translation_units': len(drafts),
    'paragraph_slots': sum(len(ds) for ds in evidence.values()),
    'English_source_words': sum(len(d['text'].split()) for d in unique.values())})
print({'queries': len(queries), 'territories': len(evidence), 'unique_source_paragraphs': len(unique),
       'translation_units': len(drafts), 'note': 'Audit completeness before freeze; no model inference performed'})
