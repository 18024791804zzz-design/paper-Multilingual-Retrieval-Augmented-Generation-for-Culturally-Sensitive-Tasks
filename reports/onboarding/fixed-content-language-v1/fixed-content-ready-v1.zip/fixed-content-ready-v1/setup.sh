#!/usr/bin/env bash
set -euo pipefail
NO_GPU=0
if [[ "${1:-}" == "--no-gpu" ]]; then
  NO_GPU=1
  shift
fi
if [[ $# -ne 0 ]]; then
  echo "Usage: bash setup.sh [--no-gpu]" >&2
  exit 2
fi
KIT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
source "$KIT_DIR/env.sh"
PYTHON_BIN="${PYTHON_BIN:-python3}"
"$PYTHON_BIN" -c 'import sys; assert (3,10)<=sys.version_info[:2]<=(3,12), "Use Python 3.10, 3.11 or 3.12"'
"$PYTHON_BIN" -m venv "$EXP_ROOT/venv"
source "$EXP_ROOT/venv/bin/activate"
python -m pip install --no-cache-dir --upgrade 'pip==25.0.1'
python -m pip install --no-cache-dir 'torch==2.6.0' --index-url "${TORCH_INDEX_URL:-https://download.pytorch.org/whl/cu124}"
python -m pip install --no-cache-dir -c "$KIT_DIR/constraints.txt" -r "$KIT_DIR/requirements-experiment.txt"
python -m pip check
python "$KIT_DIR/cpu_check.py" --require-cuda-build
python -m pip freeze > "$EXP_ROOT/environment.freeze.txt"
if [[ "$NO_GPU" == 1 ]]; then
  echo "No-GPU preparation complete. GPU/BF16 execution checks are deferred."
else
  python "$KIT_DIR/gpu_check.py"
  nvidia-smi > "$EXP_ROOT/nvidia-smi.txt"
fi
df -h "$EXP_ROOT"
