"""Draft translations with an independent MT model; human approval stays mandatory."""
import argparse
import json
import os
from pathlib import Path
from common import KIT, load, translation_rows

p = argparse.ArgumentParser()
p.add_argument('--file', type=Path, default=KIT / 'data/translations.jsonl')
p.add_argument('--device', choices=['cpu', 'cuda'], default='cuda')
a = p.parse_args()
import torch
from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

spec = load(KIT / 'models.json')['translator']
path = Path(os.environ['EXP_ROOT']) / 'models' / spec['directory']
tok = AutoTokenizer.from_pretrained(path, src_lang='eng_Latn', local_files_only=True)
model = AutoModelForSeq2SeqLM.from_pretrained(path,
                torch_dtype=torch.float32 if a.device == 'cpu' else torch.float16,
                local_files_only=True).to(a.device).eval()
codes = {'zh': 'zho_Hans', 'ru': 'rus_Cyrl'}
rows = translation_rows(a.file)
errors = []
for row in rows:
    if row.get('translation'):
        continue  # Never overwrite a translated / reviewed entry.
    inp = tok(row['source_text'], return_tensors='pt', truncation=False)
    # NLLB was trained with relatively short segments. Long passages require
    # sentence-aligned manual/external translation, not silent truncation.
    if inp.input_ids.shape[1] > 512:
        errors.append({'doc_key': row['doc_key'], 'language': row['target_language'],
                       'reason': 'source_over_512_tokens_use_manual_sentence_aligned_translation'})
        continue
    inp = {k: v.to(a.device) for k, v in inp.items()}
    with torch.inference_mode():
        output = model.generate(**inp, forced_bos_token_id=tok.convert_tokens_to_ids(codes[row['target_language']]),
                                do_sample=False, num_beams=1, max_new_tokens=1024)
    ids = output[0].tolist()
    if ids[-1] != tok.eos_token_id:
        errors.append({'doc_key': row['doc_key'], 'language': row['target_language'], 'reason': 'target_missing_EOS'})
        continue
    row['translation'] = tok.decode(ids, skip_special_tokens=True)
    row['translation_method'] = spec['repo'] + '@' + spec['revision']
    # An MT output is a draft, NOT a semantic equivalence certificate.
    row['reviewed'] = False
    row['reviewed_by'] = ''
    tmp = a.file.with_suffix('.tmp')
    tmp.write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in rows), encoding='utf-8')
    tmp.replace(a.file)
    print(row['doc_key'], row['target_language'], flush=True)
(a.file.parent / 'translation_errors.json').write_text(json.dumps(errors, ensure_ascii=False, indent=2))
print(json.dumps({'drafts': sum(bool(r.get('translation')) for r in rows), 'need_external_translation': len(errors),
                  'human_review_still_required': True}, indent=2))
