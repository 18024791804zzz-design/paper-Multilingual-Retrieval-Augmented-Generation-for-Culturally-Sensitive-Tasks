"""No-GPU environment check; intentionally does not instantiate large models."""
import argparse
import json
import numpy as np
import torch
import transformers

p = argparse.ArgumentParser()
p.add_argument('--require-cuda-build', action='store_true')
a = p.parse_args()
assert np.__version__ == '1.26.4', 'Unexpected NumPy version'
assert transformers.__version__ == '4.49.0', 'Unexpected Transformers version'
if a.require_cuda_build:
    assert torch.__version__.split('+')[0] == '2.6.0', 'Expected PyTorch 2.6.0'
    assert torch.version.cuda is not None, 'Install CUDA wheel now for later GPU use'
array = np.array([1, 2, 3], dtype=np.float32)
assert np.array_equal(torch.from_numpy(array).numpy(), array)
x = torch.tensor([[1., 2.], [3., 4.]])
assert torch.equal(x @ x, torch.tensor([[7., 10.], [15., 22.]]))
print(json.dumps({'torch': torch.__version__, 'wheel_cuda': torch.version.cuda,
    'cuda_available_now': torch.cuda.is_available(), 'numpy': np.__version__,
    'transformers': transformers.__version__, 'CPU_matmul': 'passed',
    'tensor_numpy_roundtrip': 'passed',
    'note': 'No GPU is required here; CUDA/BF16 model execution is not tested.'}, indent=2))
