import argparse
from common import KIT, load, save, translation_rows, freeze, digest

p = argparse.ArgumentParser()
p.add_argument('--freeze', action='store_true')
a = p.parse_args()
base = load(KIT / 'data/base.json')
rows = translation_rows(KIT / 'data/translations.jsonl')
print({'queries': len(base['queries']), 'territories': len(base['evidence_by_territory']),
       'translation_rows': len(rows), 'filled': sum(bool(r.get('translation')) for r in rows)})
if a.freeze:
    result = freeze(base, rows)
    save(KIT / 'data/frozen.json', result)
    save(KIT / 'data/frozen.lock.json', {'sha256': digest((KIT / 'data/frozen.json').read_bytes())})
    print('Frozen successfully. Changing translations now requires a new output directory / experiment.')
