import json
from pathlib import Path
B=Path('/workspace/paper-aligned-pilot');n=0;secs=0;fail=0;parts=[]
for name in ['llama','qwen']:
 f=B/f'validation_{name}.json'
 if f.exists():
  d=json.loads(f.read_text());print(name,'validation',len(d['cases']),'cases',d['passed'])
for f in sorted(B.glob('round*/*/*/run_report.json')):
 d=json.loads(f.read_text());n+=d['queries'];secs+=d['generation_seconds'];fail+=d['failure_count'];parts.append({'round':d['round'],'mode':d['retrieval_mode'],'model':f.parent.name,'completed':d['queries'],'seconds':round(d['generation_seconds'],1),'peak_rss_gib':round(d['peak_rss_gib'],2)})
print(json.dumps({'completed':n,'expected':540,'failures':fail,'inference_seconds':secs,'runs':parts},ensure_ascii=False))
if (B/'orchestrate_error.txt').exists():print((B/'orchestrate_error.txt').read_text())

job=json.loads((B/'job.json').read_text())
proc=Path('/proc')/str(job['orchestrator_pid'])/'cmdline'
alive=proc.exists() and b'paper-aligned-pilot/orchestrate.py' in proc.read_bytes()
print(json.dumps({'job_running':alive,'complete':(B/'COMPLETE').exists(),'log':job['log']}))
