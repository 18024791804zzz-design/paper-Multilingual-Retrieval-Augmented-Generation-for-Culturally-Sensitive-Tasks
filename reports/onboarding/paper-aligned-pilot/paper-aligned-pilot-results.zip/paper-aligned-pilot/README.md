# Paper-aligned small-model pilot

This is a subset experiment, not a reproduction of full-paper performance.
Models: local Llama-3.2-1B-Instruct and Qwen2.5-1.5B-Instruct. CPU float32, 4 threads, temperature 0, seed 4321. Each of three new rounds has 10 territories / 30 queries per model per mode (no_ir, qlang, rel_langs): 540 answers total. Both models and all modes receive exactly the same questions and native option order within each round.

Sampling is metadata-only, frozen before inference, fresh relative to the previous three pilot cohorts. All available archive queries for every selected territory are retained: a complete MRS (all claimant languages plus English). Each round retains two territories with 2 queries, six with 3, and two with 4: exactly 30 queries. This approximates original MRS size frequencies (26%,55%,16%), while omitting size-1 and size-6 territories. Additional eligibility requires the controller language and at least two claimant-language responses for evaluable CS groups, and nonempty precomputed hits in both retrieval modes. Known/unknown territory counts are 6/4, 6/4, 7/3: 19/11 across rounds approximates original 161/90. This only approximates original composition and does not reproduce the entire language-count or geographic distribution. A seeded candidate shuffle and first feasible backtracking solution satisfy the size and controller strata; distinct claimant sets within known/unknown groups and at most two known territories per controller are required. All prior 30 pilot territories are excluded uniformly; no new model outcomes enter selection. Final selection requires every claimant language plus English to exist; all archive queries for each chosen territory are retained. Per-round protocols record the pools and seeds.

Retrieval uses supplied borderlines.zip precomputed openai hits, ranked as supplied. qlang uses query language; rel_langs uses global ranking over relevant claimant languages plus English. At most 10 hits, no padding or language quota, no relevance annotation filter. English reads control/openai rather than the incomplete en folder. Inputs preserve all document IDs, text, languages, scores, and rank; language_distribution.json records final top-k languages. no_ir supplies no documents.

Answer selection matches generation/generation.py: freely generate a greedy 50-token trajectory, score each native option with that trajectory's per-position log probabilities, choose the first maximum. This is the repository algorithm; it is not teacher-forced candidate likelihood. The unmodified repository scoring helper is imported directly. Literal <|eot_id|> handling is retained, including Qwen's absent token (no substituted EOS). KV cache and last-position logits reduce redundant computation. Before full runs, per-model validation on metadata-selected draft inputs (archived under draft_equal_mrs3/round1; validation answers are not used to select production questions; one query also occurs in the final production set) compares original and cache token trajectories, all-vocabulary log probabilities, candidate sums and selected option: all 50 steps for English no_ir; all candidate-consumed positions for a metadata-selected non-English top10 input. Tolerance 1e-3 for scores and log probabilities; exact selected index and generated tokens are required. Production margins <=0.002 receive an original full-prefix candidate-position fallback. Each answer records scores, selected canonical/native country, raw diagnostic generation, tokens, full prompt, IDs, languages, timing and process peak RSS. Raw prose may differ from the scored choice; the scored candidate is used for CS, as in the source implementation.

Official evaluation uses the unchanged repository CSV adapter and vendored upstream BorderLines calculate_CS.py. No invalid answer is silently converted into the first candidate. Undefined Delta CS (zero non-control denominator), if encountered, is retained as an official error and reported separately from defined diagnostic metrics.

All scripts, inputs, metadata, results and logs live outside the repository. baseline_integrity.json records repository file hashes and old experiment hashes. No source or requirements changes are authorized or made.

Commands (from any directory):
```bash
PY=/workspace/.venvs/bordirlines/bin/python
export PYTHONDONTWRITEBYTECODE=1
# Preparation is already frozen: do not regenerate selection during inference.
$PY /workspace/paper-aligned-pilot/preflight.py
$PY /workspace/paper-aligned-pilot/validate.py --model llama
$PY /workspace/paper-aligned-pilot/validate.py --model qwen
$PY /workspace/paper-aligned-pilot/run_model.py --model llama
$PY /workspace/paper-aligned-pilot/run_model.py --model qwen
```
Workers checkpoint atomically after each query and resume existing prefixes. Do not run model workers simultaneously on this CPU: reported timings assume sequential execution.

Protocol v2 refines MRS-size composition before any production inference. The earlier all-size-3 metadata draft is preserved under draft_equal_mrs3 and supplies the correctness-validation cases. No draft model outcomes enter production sampling. Process peak RSS is cumulative within one model worker, not an isolated per-query memory measurement.

The production MRS-size distribution is 20% size-2 / 60% size-3 / 20% size-4 (original 26.3% / 55.4% / 15.9%). The controller ratio is 19/30 known (63.3%, original 64.1%). Final claimant-count composition is recorded in composition_audit.json; original frequencies are approximately 72.9% two-claimant / 23.9% three-claimant, with remaining larger claimant sets. Geography and exact language frequencies are not matched. See composition_audit.json.

Protocol v3 coverage audit: the frozen first round passes all claimant-language coverage. Before any inference for rounds 2/3, their cohorts were reselected using the same fixed size/controller strata and seeded metadata procedure, additionally excluding incomplete claimant-language coverage. The discarded pre-inference drafts are in draft_missing_languages. Correctness checks and their answers do not influence selection; the final set happens to include Ungar-Too_uz, also used for cache validation.
