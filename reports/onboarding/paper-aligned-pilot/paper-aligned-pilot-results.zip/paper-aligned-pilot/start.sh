#!/usr/bin/env bash
set -euo pipefail
while kill -0 150305 2>/dev/null; do sleep 5; done
export PYTHONDONTWRITEBYTECODE=1
exec /workspace/.venvs/bordirlines/bin/python /workspace/paper-aligned-pilot/orchestrate.py
