import json,random,hashlib
from pathlib import Path
from collections import Counter
from io import BytesIO
from zipfile import ZipFile
import pandas as pd
import numpy as np
import requests
from datasets import Dataset,DatasetDict
import sys
round_no=int(sys.argv[1]); B=Path('/workspace/paper-aligned-pilot')/f'round{round_no}'; B.mkdir(exist_ok=True);OLD=Path('/workspace/cs-pilot');S=Path('/workspace/real-data-validation')
q=pd.read_csv(S/'data/queries.tsv',sep='\t');countries=Dataset.from_file(str(OLD/'countries.arrow'));codes={r['Country']:r['Lang_Code'] for r in countries}
old={s['territory'] for folder in [OLD,Path('/workspace/retrieval-resample'),Path('/workspace/retrieval-resample-round3')]+[Path('/workspace/paper-aligned-pilot')/f'round{x}' for x in range(1,round_no)] for s in json.loads((folder/'selection.json').read_text())}
z=ZipFile(S/'bordirlines.zip');cache={}
def hits(lang,mode,qid):
 folder='control' if lang=='en' else lang
 member=f'data/{folder}/openai/{mode}/{folder}_query_hits.tsv'
 if member not in z.namelist():return pd.DataFrame()
 if member not in cache:cache[member]=pd.read_csv(BytesIO(z.read(member)),sep='\t')
 return cache[member][cache[member].query_id==qid].sort_values('rank').head(10)
pool={False:[],True:[]}
for _,r in q[q.language=='en'].iterrows():
 if r.territory in old:continue
 cs=r.Claimants.split(';');av=set(q[q.territory==r.territory].language)
 if any(c not in codes for c in cs):continue
 # Round1 was already frozen and independently passed this coverage check.
 if round_no>1 and set(codes[c] for c in cs)-av:continue
 ctrl=codes.get(r.Controller);unk=r.Controller=='Unknown'
 langs=['en']+sorted(av-{'en'})
 retained=av & set(codes[c] for c in cs)
 if len(av) not in (2,3,4) or len(retained)<2 or (not unk and (ctrl not in retained or not(retained-{ctrl}))):continue
 ids=[q[(q.territory==r.territory)&(q.language==l)].iloc[0].query_id for l in langs]
 if any(len(hits(l,m,i))==0 for l,i in zip(langs,ids) for m in ['qlang','rel_langs']):continue
 pool[unk].append({'territory':r.territory,'controller':r.Controller,'claimants':cs,'claimant_codes':[codes[c] for c in cs],'languages':langs,'query_ids':ids})
seed=20261021+round_no; rng=random.Random(seed)
candidates=pool[False]+pool[True];rng.shuffle(candidates)
slots=[2,2,4,4]+[3]*6; target_known=[6,6,7][round_no-1]
def solve(pos,chosen,known,controllers,signatures):
 if pos==len(slots):return chosen if known==target_known else None
 if known>target_known or known+len(slots)-pos<target_known:return None
 for s in candidates:
  if len(s['languages'])!=slots[pos] or s in chosen:continue
  k=s['controller']!='Unknown';sig=(k,tuple(sorted(s['claimants'])))
  if sig in signatures or (k and controllers[s['controller']]>=2):continue
  # Sort positions within each size stratum to avoid permutation repeats.
  if chosen and len(chosen[-1]['languages'])==slots[pos] and candidates.index(s)<=candidates.index(chosen[-1]):continue
  co=controllers.copy();co[s['controller']]+=int(k)
  result=solve(pos+1,chosen+[s],known+int(k),co,signatures|{sig})
  if result is not None:return result
 return None
selection=solve(0,[],0,Counter(),set());assert selection is not None
(B/'selection.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2))
(B/'selection_protocol.json').write_text(json.dumps({'seed':seed,'eligible_pool_counts':{str(k):len(v) for k,v in pool.items()},'rule':'Protocol v3: metadata-only sampling; exclude all prior pilot territories and earlier new rounds. Complete MRS: every claimant language plus English must be present in selected queries (round1 frozen cohort independently verified; rounds2/3 enforce eligibility before shuffle), per round size strata 2x2 + 6x3 + 2x4 = 30 queries / 10 territories (approximate original MRS sizes 26/55/16 percent). Known/unknown counts 6/4,6/4,7/3 approximate original 161/90 ratio. Seeded shuffled candidates, first backtracking solution satisfying size and controller strata; distinct claimant sets within known/unknown groups, at most two territories per known controller. Evaluable claimant/control language groups required, and nonempty archived hits in both modes; take min(10, available). No model outcomes used. Excludes original MRS sizes 1 and 6; not population-representative.','old_territories_excluded':sorted(old),'selected':selection},ensure_ascii=False,indent=2))
print('Frozen new territories:',[(s['territory'],s['languages']) for s in selection],flush=True)
languages=sorted({l for s in selection for l in s['languages']});native={};sources=[]
for lang in languages:
 if lang=='en':continue
 roots=[Path('/workspace/paper-aligned-pilot/draft_equal_mrs3')/f'round{x}' for x in range(1,4)]+[OLD,Path('/workspace/retrieval-resample'),Path('/workspace/retrieval-resample-round3')]+[Path('/workspace/paper-aligned-pilot')/f'round{x}' for x in range(1,round_no+1)]
 f=next((root/f'{lang}.arrow' for root in roots if (root/f'{lang}.arrow').exists()),B/f'{lang}.arrow')
 url=f'https://huggingface.co/datasets/manestay/borderlines/resolve/main/queries/{lang}/data-00000-of-00001.arrow'
 if not f.exists():
  res=requests.get(url,timeout=30);res.raise_for_status();f.write_bytes(res.content)
 native[lang]={r['QueryID']:r for r in Dataset.from_file(str(f))}
 sources.append({'url':url,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
docs=json.loads((S/'data/all_docs.json').read_text());base=[]
for s in selection:
 for lang,rawid in zip(s['languages'],s['query_ids']):
  r=q[q.query_id==rawid].iloc[0];qid=s['territory'].replace(' ','_')+'_'+lang
  names=s['claimants'] if lang=='en' else native[lang][qid]['Claimants_Native']
  if lang!='en':assert ' '.join(native[lang][qid]['Query_Native'].split())==' '.join(r.query_text.split()),qid
  assert len(names)==len(s['claimants'])
  for i,name in enumerate(names):assert f'{chr(65+i)}) {name}' in r.query_text,(qid,name)
  base.append({'qid':qid,'raw_query_id':rawid,'territory':s['territory'],'query':r.query_text,'query_lang':lang,'claimants':s['claimants'],'claimants_native':names,'claimant_langs':s['claimant_codes'],'controller':s['controller'],'controller_code':codes.get(s['controller'],'')})
meta=B/'evaluation_metadata';meta.mkdir(exist_ok=True)
Dataset.from_list([{'Territory':s['territory'],'Claimants':s['claimants'],'Controller':s['controller'],'Query':next(i['query'] for i in base if i['territory']==s['territory'] and i['query_lang']=='en')} for s in selection]).save_to_disk(str(meta/'territories'))
countries.save_to_disk(str(meta/'countries'))
DatasetDict({l:Dataset.from_list([{'QueryID':i['qid'],'Query_Native':i['query'],'Claimants_Native':i['claimants_native']} for i in base if i['query_lang']==l]) for l in languages}).save_to_disk(str(meta/'queries'))
archive_sha=hashlib.sha256((S/'bordirlines.zip').read_bytes()).hexdigest()
for mode in ['qlang','rel_langs','no_ir']:
 root=B/mode;root.mkdir(exist_ok=True);rows=[];dist=[]
 for item in base:
  hs=[]
  if mode!='no_ir':
   for _,h in hits(item['query_lang'],mode,item['raw_query_id']).iterrows():
    assert h.doc_lang in set(item['claimant_langs'])|{'en'}
    if mode=='qlang':assert h.doc_lang==item['query_lang']
    hs.append({'pid':h.doc_id,'language':h.doc_lang,'rank':int(h['rank']),'score':float(np.float32(h.score)),'text':docs[h.doc_lang][h.doc_id]})
  rows.append(dict(item,hits=hs));ls=[h['language'] for h in hs]
  dist.append({'qid':item['qid'],'query_lang':item['query_lang'],'document_count':len(hs),'document_ids':[h['pid'] for h in hs],'top_k_languages_in_rank_order':ls,'language_counts':dict(Counter(ls)),'distinct_languages':len(set(ls)),'multilingual_top_k':len(set(ls))>=2,'same_query_language_documents':ls.count(item['query_lang'])})
 data=json.dumps(rows,ensure_ascii=False,indent=2,allow_nan=False);(root/'inputs.json').write_text(data)
 manifest={'mode':mode,'queries_per_model':30,'territories':10,'n_hits':0 if mode=='no_ir' else 10,'inputs_sha256':hashlib.sha256(data.encode()).hexdigest(),'source_archive_sha256':archive_sha,'metadata_sources':sources,'aggregate_document_language_counts':dict(Counter(l for d in dist for l in d['top_k_languages_in_rank_order'])),'multilingual_top10_queries':sum(d['multilingual_top_k'] for d in dist),'single_language_top10_queries':sum(d['distinct_languages']==1 for d in dist)}
 (root/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));(root/'language_distribution.json').write_text(json.dumps(dist,ensure_ascii=False,indent=2))
 for name in ['selection.json','evaluation_metadata']:(root/name).symlink_to(B/name,target_is_directory=name=='evaluation_metadata')
 print(mode,manifest['aggregate_document_language_counts'],flush=True)
