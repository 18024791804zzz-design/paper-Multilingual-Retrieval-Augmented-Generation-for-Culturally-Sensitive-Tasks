import os,sys,json,time,subprocess
from pathlib import Path
B=Path('/workspace/paper-aligned-pilot');py='/workspace/.venvs/bordirlines/bin/python'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
def run(script,args,log):
 with (B/log).open('a') as f:
  p=subprocess.run([py,str(B/script),*args],stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError(f'{script} {args} failed: see {log}')
# Llama validation is already running externally; wait for its parent process to finish.
for name in ['llama','qwen']:
 f=B/f'validation_{name}.json'
 if not f.exists() or len(json.loads(f.read_text())['cases'])!=2 or not json.loads(f.read_text())['passed']:
  run('validate.py',['--model',name],f'validation_{name}.log')
assert all(json.loads((B/f'validation_{n}.json').read_text())['passed'] for n in ['llama','qwen'])
for name in ['llama','qwen']:run('run_model.py',['--model',name],f'run_{name}.log')
for r in range(1,4):
 for mode in ['no_ir','qlang','rel_langs']:
  # Official scorer undefined metrics must not prevent recording other completed modes.
  with (B/f'evaluation_round{r}_{mode}.log').open('w') as f:
   subprocess.run([py,str(B/'evaluate.py'),'--round',str(r),'--mode',mode],stdout=f,stderr=subprocess.STDOUT)
run('finalize.py',[],'finalize.log')
(B/'COMPLETE').write_text(time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
