from pathlib import Path
p=Path('/workspace/retrieval-resample-round3/evaluate.py').read_text()
p=p.replace("p.add_argument('--mode'", "p.add_argument('--round',type=int,required=True);p.add_argument('--mode'")
p=p.replace("B=Path('/workspace/retrieval-resample-round3')/args.mode", "B=Path('/workspace/paper-aligned-pilot')/f'round{args.round}'/args.mode")
p=p.replace("metrics['Consistency CS unk rows']==5", "metrics['Consistency CS unk rows']==sum(s['controller']=='Unknown' for s in selected)")
p=p.replace('native generate(), not full-paper reproduction', 'original-code candidate scoring with validated KV-cache optimization; complete available MRS, top10; not full-paper reproduction')
p=p.replace("    models[name]=entry\n", "    models[name]=entry\n")
# Keep official failure visible; compute independent diagnostics separately downstream.
Path('/workspace/paper-aligned-pilot/evaluate.py').write_text(p)
