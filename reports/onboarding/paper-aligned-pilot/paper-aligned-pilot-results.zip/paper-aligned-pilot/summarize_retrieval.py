import json
from pathlib import Path
from collections import Counter
B=Path('/workspace/paper-aligned-pilot');result=[]
for r in range(1,4):
 for mode in ['no_ir','qlang','rel_langs']:
  rows=json.loads((B/f'round{r}'/mode/'language_distribution.json').read_text());c=Counter(l for x in rows for l in x['top_k_languages_in_rank_order']);n=sum(c.values())
  result.append({'round':r,'mode':mode,'queries':len(rows),'total_docs':n,'min_documents':min(x['document_count'] for x in rows),'max_documents':max(x['document_count'] for x in rows),'multilingual_queries':sum(x['multilingual_top_k'] for x in rows),'english_doc_fraction':c['en']/n if n else None,'language_counts':dict(c)})
(B/'retrieval_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps([x for x in result if x['mode']=='rel_langs']))
