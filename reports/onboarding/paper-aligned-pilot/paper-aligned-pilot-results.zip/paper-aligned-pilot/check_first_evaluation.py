import os,subprocess,sys,json
from pathlib import Path
os.environ.update(HF_HOME='/workspace/.cache/huggingface',HF_HUB_OFFLINE='1',HF_DATASETS_OFFLINE='1',PYTHONDONTWRITEBYTECODE='1')
B=Path('/workspace/paper-aligned-pilot/round1/no_ir');out=B/'llama';repo=Path('/workspace/paper-Multilingual-Retrieval-Augmented-Generation-for-Culturally-Sensitive-Tasks');py=sys.executable
cmds=[('csv_adapter',[py,str(repo/'generation/gen_response_table.py'),'-i',str(out/'generation.json'),'-o',str(out/'response_table.csv'),'-dd',str(B/'evaluation_metadata'),'-q']),('official_cs',[py,'/workspace/.onboarding/bordirlines/vendor/BorderLines/calculate_CS.py',str(out/'response_table.csv'),'-o',str(out/'cs_metrics.json'),'-q'])]
for name,cmd in cmds:
 p=subprocess.run(cmd,cwd=repo/'generation',capture_output=True,text=True);(out/f'{name}.log').write_text(p.stdout+p.stderr);print(name,p.returncode)
 if p.returncode:print(p.stdout+p.stderr);break
if (out/'cs_metrics.json').exists():print((out/'cs_metrics.json').read_text())
