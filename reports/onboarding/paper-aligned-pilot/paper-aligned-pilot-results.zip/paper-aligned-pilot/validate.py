from engine import *
import argparse
p=argparse.ArgumentParser();p.add_argument('--model',required=True);a=p.parse_args()
tok,model,load_seconds=load(a.model);cases=[]
# Freeze two validation cases before inference: first English no_ir (full 50 steps),
# shortest non-English top10 input (all candidate-relevant positions).
items=json.loads((ROOT/'round1/qlang/inputs.json').read_text())
english=next(x for x in items if x['query_lang']=='en');english=dict(english,hits=[])
retrieval=min((x for x in items if x['query_lang']!='en'),key=lambda x:inputs(tok,x,'qlang')[0].shape[1])
for mode,item,full50 in [('no_ir',english,True),('qlang',retrieval,False)]:
 ids,messages,choices=inputs(tok,item,mode);lens=lengths(tok,choices);assert max(lens)<=50
 n=50 if full50 else max(lens);print(json.dumps({'start':item['qid'],'mode':mode,'steps':n,'input_tokens':ids.shape[1]}),flush=True)
 t=time.perf_counter();ref,rt=original.generate_next_tokens(ids,model,num_tokens=n);ref_seconds=time.perf_counter()-t
 t=time.perf_counter();got,gt=cached(ids,model,n);cache_seconds=time.perf_counter()-t
 rs=score(ref,choices,tok);gs=score(got,choices,tok)
 errs=[float(np.max(np.abs(x-y))) for x,y in zip(ref,got)]
 passed=rt==gt and max(abs(x-y) for x,y in zip(rs,gs))<=1e-3 and max(errs)<=1e-3 and int(np.argmax(rs))==int(np.argmax(gs))
 cases.append({'qid':item['qid'],'mode':mode,'input_tokens':ids.shape[1],'steps':n,'all_50_steps_checked':full50,'candidate_lengths':lens,'choices':choices,'reference_scores':rs,'cached_scores':gs,'max_logprob_error':max(errs),'candidate_score_max_error':max(abs(x-y) for x,y in zip(rs,gs)),'all_generated_tokens_equal':rt==gt,'reference_choice':int(np.argmax(rs)),'cached_choice':int(np.argmax(gs)),'reference_seconds':ref_seconds,'cached_seconds':cache_seconds,'speedup':ref_seconds/cache_seconds,'passed':passed,'messages':messages,'document_ids':[h['pid'] for h in item['hits']]})
 atomic(ROOT/f'validation_{a.model}.json',{'model':a.model,'eot_id':tok.convert_tokens_to_ids('<|eot_id|>'),'score_atol':1e-3,'all_vocab_logprob_atol':1e-3,'selection_rule':'First English no_ir and shortest non-English full top10 qlang, selected using input metadata only. no_ir checks all50; retrieval checks every position consumed by any candidate.','cases':cases,'passed':all(x['passed'] for x in cases)})
 print(json.dumps({k:v for k,v in cases[-1].items() if k not in ['messages']}),flush=True)
 assert passed,'Cache validation failed: do not launch experiment'
