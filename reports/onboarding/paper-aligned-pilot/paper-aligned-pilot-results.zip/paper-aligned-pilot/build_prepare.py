from pathlib import Path
p=Path('/workspace/retrieval-resample-round3/prepare.py').read_text()
p=p.replace("B=Path('/workspace/retrieval-resample-round3')", "import sys\nround_no=int(sys.argv[1]); B=Path('/workspace/paper-aligned-pilot')/f'round{round_no}'; B.mkdir(exist_ok=True)")
p=p.replace("[OLD,Path('/workspace/retrieval-resample')]", "[OLD,Path('/workspace/retrieval-resample'),Path('/workspace/retrieval-resample-round3')]+[Path('/workspace/paper-aligned-pilot')/f'round{x}' for x in range(1,round_no)]")
p=p.replace('.head(5)', '.head(10)')
a=p.index(' non=list(');b=p.index(" pool[unk].append",a)
p=p[:a]+''' ctrl=codes.get(r.Controller);unk=r.Controller=='Unknown'
 langs=['en']+sorted(av-{'en'})
 retained=av & set(codes[c] for c in cs)
 if len(av)!=3 or len(retained)<2 or (not unk and (ctrl not in retained or not(retained-{ctrl}))):continue
 ids=[q[(q.territory==r.territory)&(q.language==l)].iloc[0].query_id for l in langs]
 if any(len(hits(l,m,i))==0 for l,i in zip(langs,ids) for m in ['qlang','rel_langs']):continue
'''+p[b:]
p=p.replace('rng=random.Random(20261021)', 'seed=20261021+round_no; rng=random.Random(seed)')
p=p.replace('if len(group)==5:break', 'if len(group)==([6,6,7][round_no-1] if not unk else [4,4,3][round_no-1]):break')
p=p.replace('assert len(group)==5', 'assert len(group)==([6,6,7][round_no-1] if not unk else [4,4,3][round_no-1])')
p=p.replace("'seed':20261021", "'seed':seed")
p=p.replace("'rule':'Exclude all twenty territories from rounds 1 and 2; metadata-only seeded shuffle in known/unknown strata; first five distinct claimant sets each; at most two territories per known controller; en plus two non-English claimant languages, including controller language; require both archived retrieval modes top5. No model output used.'", "'rule':'Fresh territories, exclude all previous pilot territories and earlier new rounds. Exactly three archive queries per territory: all are retained (complete available MRS). Metadata-only seeded shuffle within known/unknown strata, distinct claimant sets, at most two known territories per controller. Known/unknown counts 6/4,6/4,7/3. This approximates original controller ratio but conditions on MRS size 3, not the full original language-count distribution. Require evaluable language groups and nonempty archived hits; take min(10, available). No outcomes used.'")
a=p.index(" f=OLD/f'{lang}.arrow'");b=p.index(" native[lang]",a)
p=p[:a]+''' roots=[OLD,Path('/workspace/retrieval-resample'),Path('/workspace/retrieval-resample-round3')]+[Path('/workspace/paper-aligned-pilot')/f'round{x}' for x in range(1,round_no+1)]
 f=next((root/f'{lang}.arrow' for root in roots if (root/f'{lang}.arrow').exists()),B/f'{lang}.arrow')
 url=f'https://huggingface.co/datasets/manestay/borderlines/resolve/main/queries/{lang}/data-00000-of-00001.arrow'
 if not f.exists():
  res=requests.get(url,timeout=30);res.raise_for_status();f.write_bytes(res.content)
'''+p[b:]
p=p.replace("else 5", "else 10").replace('top5','top10')
Path('/workspace/paper-aligned-pilot/prepare.py').write_text(p)
