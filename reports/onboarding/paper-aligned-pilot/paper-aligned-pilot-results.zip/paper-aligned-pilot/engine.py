import os,sys,json,time,hashlib,resource
from pathlib import Path
from types import SimpleNamespace
os.environ.update(HF_HOME='/workspace/.cache/huggingface',HF_HUB_OFFLINE='1',HF_DATASETS_OFFLINE='1',PYTHONDONTWRITEBYTECODE='1')
sys.dont_write_bytecode=True
ROOT=Path('/workspace/paper-aligned-pilot');REPO=Path('/workspace/paper-Multilingual-Retrieval-Augmented-Generation-for-Culturally-Sensitive-Tasks')
sys.path[:0]=[str(REPO/'generation'),str(REPO)]
import torch,numpy as np
from transformers import AutoTokenizer,AutoModelForCausalLM,set_seed
import generation as original
from generation_lib import get_user_prompt_direct,get_multiple_choice
from data_lib import SYSTEM_PROMPT
original.args=SimpleNamespace(temperature=0.0,citation=False)
PATHS={'llama':'/workspace/models/Llama-3.2-1B-Instruct','qwen':'/workspace/models/Qwen2.5-1.5B-Instruct'}
def load(name):
 torch.set_num_threads(4);set_seed(4321);t=time.perf_counter()
 tok=AutoTokenizer.from_pretrained(PATHS[name],local_files_only=True)
 model=AutoModelForCausalLM.from_pretrained(PATHS[name],local_files_only=True,torch_dtype=torch.float32,device_map='cpu').eval()
 return tok,model,time.perf_counter()-t

def inputs(tok,item,mode):
 messages=[{'role':'system','content':SYSTEM_PROMPT},{'role':'user','content':get_user_prompt_direct([h['text'] for h in item['hits']],item,mode!='no_ir')}]
 ids=tok.apply_chat_template(messages,add_generation_prompt=True,return_tensors='pt',add_special_tokens=True)
 return ids,messages,get_multiple_choice(item['claimants_native'])
def lengths(tok,choices):
 return [len(tok(c,add_special_tokens=False).input_ids)+(tok.convert_tokens_to_ids('<|eot_id|>') is not None) for c in choices]
def cached(ids,model,steps=50):
 current=ids;past=None;probs=[];tokens=[]
 with torch.inference_mode():
  for _ in range(steps):
   out=model(input_ids=current,past_key_values=past,use_cache=True,return_dict=True,logits_to_keep=1)
   past=out.past_key_values;lp=torch.log_softmax(out.logits[:,-1,:],dim=-1)
   probs.append(lp.squeeze(0).cpu().numpy());current=lp.argmax(-1,keepdim=True);tokens.append(current.item());del out,lp
 del past
 return probs,tokens

def score(probs,choices,tok):return [float(x) for x in original.calculate_log_probabilities_for_candidates(probs,choices,tok)]
def atomic(path,value):
 tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False));tmp.replace(path)
