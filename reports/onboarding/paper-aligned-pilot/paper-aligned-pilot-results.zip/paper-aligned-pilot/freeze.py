import json,hashlib
from pathlib import Path
B=Path('/workspace/paper-aligned-pilot')
files=list(B.glob('*.py'))+list(B.glob('round*/*/inputs.json'))+list(B.glob('round*/selection*.json'))
files+=[Path('/workspace/paper-Multilingual-Retrieval-Augmented-Generation-for-Culturally-Sensitive-Tasks/generation')/f for f in ['generation.py','generation_lib.py','data_lib.py','gen_response_table.py']]
files+=[Path('/workspace/.onboarding/bordirlines/vendor/BorderLines/calculate_CS.py')]
(B/'frozen_protocol_hashes.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
(B/'model_fingerprints.json').write_bytes(Path('/workspace/three-round-comparison/model_fingerprints.json').read_bytes())
print('Frozen',len(files),'scripts/protocol/input files; model hashes copied from previously verified same local checkpoints')
