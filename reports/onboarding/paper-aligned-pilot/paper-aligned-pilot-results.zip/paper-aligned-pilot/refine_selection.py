from pathlib import Path
import shutil
B=Path('/workspace/paper-aligned-pilot')
# Archive the metadata-only first draft; no production predictions exist.
archive=B/'draft_equal_mrs3';archive.mkdir(exist_ok=True)
for r in range(1,4):
 assert not list((B/f'round{r}').glob('*/*/answers.json'))
 shutil.move(str(B/f'round{r}'),str(archive/f'round{r}'))
p=(B/'prepare.py').read_text().replace('len(av)!=3','len(av) not in (2,3,4)')
a=p.index('rng=random.Random') if 'rng=random.Random' in p else p.index('seed=20261021')
# Keep the preassigned seed declaration, replace the old per-stratum selection loop.
a=p.index('seed=20261021');b=p.index("(B/'selection.json')",a)
p=p[:a]+'''seed=20261021+round_no; rng=random.Random(seed)
candidates=pool[False]+pool[True];rng.shuffle(candidates)
slots=[2,2,4,4]+[3]*6; target_known=[6,6,7][round_no-1]
def solve(pos,chosen,known,controllers,signatures):
 if pos==len(slots):return chosen if known==target_known else None
 if known>target_known or known+len(slots)-pos<target_known:return None
 for s in candidates:
  if len(s['languages'])!=slots[pos] or s in chosen:continue
  k=s['controller']!='Unknown';sig=(k,tuple(sorted(s['claimants'])))
  if sig in signatures or (k and controllers[s['controller']]>=2):continue
  # Sort positions within each size stratum to avoid permutation repeats.
  if chosen and len(chosen[-1]['languages'])==slots[pos] and candidates.index(s)<=candidates.index(chosen[-1]):continue
  co=controllers.copy();co[s['controller']]+=int(k)
  result=solve(pos+1,chosen+[s],known+int(k),co,signatures|{sig})
  if result is not None:return result
 return None
selection=solve(0,[],0,Counter(),set());assert selection is not None
'''+p[b:]
start=p.index("'rule':");end=p.index(",'old_territories_excluded'",start)
p=p[:start]+"'rule':'Protocol v2: metadata-only sampling; exclude all prior pilot territories and earlier new rounds. Complete available MRS, per round size strata 2x2 + 6x3 + 2x4 = 30 queries / 10 territories (approximate original MRS sizes 26/55/16 percent). Known/unknown counts 6/4,6/4,7/3 approximate original 161/90 ratio. Seeded shuffled candidates, first backtracking solution satisfying size and controller strata; distinct claimant sets within known/unknown groups, at most two territories per known controller. Evaluable claimant/control language groups required, and nonempty archived hits in both modes; take min(10, available). No model outcomes used. Excludes original MRS sizes 1 and 6; not population-representative.'"+p[end:]
# Reuse metadata downloaded for the draft too.
p=p.replace("roots=[OLD,", "roots=[Path('/workspace/paper-aligned-pilot/draft_equal_mrs3')/f'round{x}' for x in range(1,4)]+[OLD,")
(B/'prepare.py').write_text(p)
