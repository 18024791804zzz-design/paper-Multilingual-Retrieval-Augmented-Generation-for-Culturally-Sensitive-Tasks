from engine import *
rows=[]
for name in PATHS:
 tok=AutoTokenizer.from_pretrained(PATHS[name],local_files_only=True)
 for r in range(1,4):
  for mode in ['qlang','rel_langs','no_ir']:
   data=json.loads((ROOT/f'round{r}'/mode/'inputs.json').read_text());assert len(data)==30
   for item in data:
    ids,_,choices=inputs(tok,item,mode);lens=lengths(tok,choices)
    assert max(lens)<=50,(name,item['qid'],lens)
    assert ids.shape[1]<min(tok.model_max_length,32768),(name,item['qid'],ids.shape)
    rows.append({'model':name,'round':r,'mode':mode,'qid':item['qid'],'input_tokens':ids.shape[1],'candidate_lengths':lens,'document_count':len(item['hits'])})
atomic(ROOT/'preflight.json',{'passed':True,'num_model_queries':len(rows),'max_input_tokens':max(x['input_tokens'] for x in rows),'max_candidate_tokens':max(max(x['candidate_lengths']) for x in rows),'rows':rows})
print('Passed',len(rows),'maximum input',max(x['input_tokens'] for x in rows),'candidate tokens',max(max(x['candidate_lengths']) for x in rows))
