import json,hashlib,subprocess
from pathlib import Path
B=Path('/workspace/paper-aligned-pilot');repo=Path('/workspace/paper-Multilingual-Retrieval-Augmented-Generation-for-Culturally-Sensitive-Tasks')
f=B/'baseline_integrity.json'
if not f.exists():
 tracked=subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0')
 data={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),'git_status':subprocess.check_output(['git','status','--porcelain'],cwd=repo).decode(),'repository_files':{p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in tracked if p and (repo/p).is_file()},'old_results':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for root in ['cs-pilot','retrieval-comparison','retrieval-resample','retrieval-resample-round3','three-round-comparison','three-round-pooled'] for p in (Path('/workspace')/root).rglob('*.json')}}
 assert not data['git_status'];f.write_text(json.dumps(data,indent=2))
print('Integrity snapshot exists',len(json.loads(f.read_text())['repository_files']))
