import json
from pathlib import Path
from collections import Counter
import pandas as pd
B=Path('/workspace/paper-aligned-pilot');q=pd.read_csv('/workspace/real-data-validation/data/queries.tsv',sep='\t');en=q[q.language=='en'];allsel=[];rounds=[]
for r in range(1,4):
 s=json.loads((B/f'round{r}/selection.json').read_text());allsel+=s
 for x in s:
  av=set(q[q.territory==x['territory']].language)
  assert set(x['languages'])==av==set(x['claimant_codes'])|{'en'},x
 rounds.append({'round':r,'known':sum(x['controller']!='Unknown' for x in s),'unknown':sum(x['controller']=='Unknown' for x in s),'territories':10,'queries':sum(len(x['languages']) for x in s),'mrs_size_counts':dict(Counter(len(x['languages']) for x in s)),'claimant_count_counts':dict(Counter(len(x['claimants']) for x in s))})
assert len({x['territory'] for x in allsel})==30
report={'protocol_version':3,'full_claimant_language_plus_english_coverage':True,'original':{'territories':len(en),'queries':len(q),'known':int(sum(en.Controller!='Unknown')),'unknown':int(sum(en.Controller=='Unknown')),'mrs_size_counts':dict(Counter(q.groupby('territory').size())),'claimant_count_counts':dict(Counter(en.Claimants.str.split(';').str.len()))},'selected':{'territories':30,'queries':90,'known':sum(x['controller']!='Unknown' for x in allsel),'unknown':sum(x['controller']=='Unknown' for x in allsel),'mrs_size_counts':dict(Counter(len(x['languages']) for x in allsel)),'claimant_count_counts':dict(Counter(len(x['claimants']) for x in allsel))},'rounds':rounds,'note':'Metadata-only refinements. Round1 was frozen before production, and passed full coverage. Rounds2/3 were reselected before any inference in those rounds to exclude missing claimant-language queries. No model outcomes used; previous drafts retained for audit.'}
(B/'composition_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report['selected']))
for name in ['llama','qwen']:
 p=B/f'validation_{name}.json';d=json.loads(p.read_text());d.pop('independent_validation_cohort',None);d['selection_independent_of_validation_outputs']=True;d['production_overlap_qids']=[x['qid'] for x in d['cases'] if any(x['qid']==i['qid'] for r in range(1,4) for i in json.loads((B/f'round{r}/qlang/inputs.json').read_text()))];p.write_text(json.dumps(d,ensure_ascii=False,indent=2))
