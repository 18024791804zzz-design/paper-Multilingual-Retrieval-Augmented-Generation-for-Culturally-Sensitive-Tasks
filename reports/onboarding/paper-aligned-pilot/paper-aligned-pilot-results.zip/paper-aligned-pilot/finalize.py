from pathlib import Path
from engine import ROOT,REPO,atomic
import csv,hashlib,json,subprocess,statistics,shutil,math
from itertools import combinations
from collections import Counter

def metrics(rows):
 known=[x for x in rows if x['controller']!='Unknown']
 def avg(xs):return statistics.mean(xs) if xs else None
 control=avg([x['control'] for x in known if x['control'] is not None]);non=avg([x['noncontrol'] for x in known if x['noncontrol'] is not None])
 return {'KB CS':avg([x['kb'] for x in known]),'Control CS':control,'Non-control CS':non,'Delta CS':(control-non)/non if non and control is not None else None,'Delta CS unnormalized':control-non if non is not None and control is not None else None,'Consistency CS all':avg([x['cst'] for x in rows if x['cst'] is not None]),'Consistency CS unk':avg([x['cst'] for x in rows if x['controller']=='Unknown' and x['cst'] is not None])}
allrows=[];summary=[];qa=[];languages=[]
for r in range(1,4):
 for mode in ['no_ir','qlang','rel_langs']:
  B=ROOT/f'round{r}'/mode;selection=json.loads((B/'selection.json').read_text());items=json.loads((B/'inputs.json').read_text())
  for d in json.loads((B/'language_distribution.json').read_text()):languages.append(dict(d,round=r,mode=mode))
  for model in ['llama','qwen']:
   out=B/model;answers=json.loads((out/'answers.json').read_text());assert len(answers)==30 and all(x['success'] for x in answers)
   amap={x['qid']:x for x in answers};qa.extend(answers);rows=[]
   for s in selection:
    prefix=s['territory'].replace(' ','_');a={l:amap[f'{prefix}_{l}']['canonical_choice'] for l in s['languages']};retained={l:v for l,v in a.items() if l!='en' or 'en' in s['claimant_codes']};controller=s['controller'];code=next(x['controller_code'] for x in items if x['territory']==s['territory']);pairs=list(combinations(retained.values(),2));non=[v==controller for l,v in retained.items() if l!=code]
    row={'round':r,'mode':mode,'model':model,'territory':s['territory'],'controller':controller,'controller_code':code,'responses':a,'retained_responses':retained,'cst_pairs':len(pairs),'cst_equal_pairs':sum(x==y for x,y in pairs),'cst':statistics.mean(x==y for x,y in pairs) if pairs else None,'kb':a['en']==controller if controller!='Unknown' else None,'control':retained[code]==controller if controller!='Unknown' and code in retained else None,'noncontrol':statistics.mean(non) if controller!='Unknown' and non else None};rows.append(row)
   diagnostic=metrics(rows);atomic(out/'independent_metrics.json',diagnostic);atomic(out/'territory_metrics.json',rows);allrows.extend(rows)
   passed=(out/'cs_metrics.json').exists()
   if passed:
    official=json.loads((out/'cs_metrics.json').read_text())
    for k,v in diagnostic.items():assert math.isclose(official[k],v,abs_tol=1e-12),(r,mode,model,k,official[k],v)
   report=json.loads((out/'run_report.json').read_text());summary.append(dict(round=r,mode=mode,model=model,official_status='passed' if passed else 'failed_see_official_cs.log',**diagnostic,seconds=report['generation_seconds'],peak_rss_gib=report['peak_rss_gib'],success_count=report['success_count']))
for mode in ['no_ir','qlang','rel_langs']:
 for model in ['llama','qwen']:
  subset=[x for x in allrows if x['mode']==mode and x['model']==model];pooled=metrics(subset);summary.append(dict(round='pooled',mode=mode,model=model,official_status='independently_pooled_from_territories',**pooled))
  entries=[x for x in summary if x['round'] in [1,2,3] and x['mode']==mode and x['model']==model]
  macro={k:statistics.mean([x[k] for x in entries]) if all(x[k] is not None for x in entries) else None for k in pooled}
  summary.append(dict(round='macro_mean',mode=mode,model=model,official_status='arithmetic_mean_of_three_rounds',**macro))
atomic(ROOT/'summary.json',summary);atomic(ROOT/'all_questions_and_answers.json',qa);atomic(ROOT/'all_territory_metrics.json',allrows);atomic(ROOT/'all_language_distributions.json',languages)
columns=['round','mode','model','official_status','KB CS','Control CS','Non-control CS','Delta CS','Delta CS unnormalized','Consistency CS all','Consistency CS unk','seconds','peak_rss_gib','success_count']
with (ROOT/'summary.csv').open('w') as f:
 w=csv.DictWriter(f,columns);w.writeheader();w.writerows(summary)
# Frozen inference/selection scripts and inputs must remain unchanged.
protocol=json.loads((ROOT/'frozen_protocol_hashes.json').read_text())
protocol_changed=[p for p,h in protocol.items() if not Path(p).is_file() or hashlib.sha256(Path(p).read_bytes()).hexdigest()!=h]
assert not protocol_changed,protocol_changed
# Repository and previous outputs must be byte-identical to the start of this experiment.
baseline=json.loads((ROOT/'baseline_integrity.json').read_text());changed=[]
for p,h in baseline['repository_files'].items():
 if not (REPO/p).is_file() or hashlib.sha256((REPO/p).read_bytes()).hexdigest()!=h:changed.append(str(REPO/p))
for p,h in baseline['old_results'].items():
 if not Path(p).is_file() or hashlib.sha256(Path(p).read_bytes()).hexdigest()!=h:changed.append(p)
status=subprocess.check_output(['git','status','--porcelain'],cwd=REPO).decode();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO).decode().strip()
atomic(ROOT/'integrity_check.json',{'passed':not changed and not status and head==baseline['head'],'changed_files':changed,'git_status':status,'head':head,'repository_files_checked':len(baseline['repository_files']),'old_result_files_checked':len(baseline['old_results']),'frozen_protocol_files_checked':len(protocol)});assert not changed and not status and head==baseline['head']
(ROOT/'disk_space.txt').write_text(subprocess.check_output(['df','-h','/workspace']).decode())
lines=['# Results','', 'New independent cohorts; complete available MRS; max top10; original candidate scoring with validated cache. These are small-model subset results, not full-paper performance.','', '| Round | Model | Mode | KB | Control | Non-control | Delta | CST all | CST unknown | Official status |','|---|---|---|---:|---:|---:|---:|---:|---:|---|']
for x in summary:
 vals=['undefined' if x[k] is None else f'{x[k]*100:.2f}%' for k in ['KB CS','Control CS','Non-control CS','Delta CS','Consistency CS all','Consistency CS unk']]
 lines.append('| '+' | '.join([str(x['round']),x['model'],x['mode'],*vals,x['official_status']])+' |')
lines+=['','Pooled metrics use 30 territory records per model/mode, with 19 known and 11 unknown. Macro means give each round equal weight; KB/Control/Non-control and CST unknown have different denominators across rounds, so macro and pooled may differ. Delta is recomputed after pooling Control and Non-control, not averaged as if additive.','', 'All 540 questions, prompts, raw generated text, selected native/canonical answers, candidate scores, IDs and language distributions are saved in all_questions_and_answers.json and per-run files. Raw generated text is diagnostic: the scored choice is used for evaluation.','', 'Source and requirements unchanged. See integrity_check.json. Old pilot results remain unchanged. Sampling and scoring changed relative to the old pilots, so old-versus-new differences cannot be attributed solely to top-k or question changes.']

# Paired comparisons: identical questions/parameters, only supplied retrieval mode changes.
paired=[]
for model in ['llama','qwen']:
 lines+=['',f'## {model}: paired retrieval comparison','']
 for base,target in [('no_ir','qlang'),('no_ir','rel_langs'),('qlang','rel_langs')]:
  b=next(x for x in summary if x['round']=='pooled' and x['model']==model and x['mode']==base)
  t=next(x for x in summary if x['round']=='pooled' and x['model']==model and x['mode']==target)
  differences={k:(t[k]-b[k]) if b[k] is not None and t[k] is not None else None for k in metrics([])}
  bs={(x['round'],x['territory']):x for x in allrows if x['model']==model and x['mode']==base}
  ts={(x['round'],x['territory']):x for x in allrows if x['model']==model and x['mode']==target}
  improved=sum(ts[k]['cst']>bs[k]['cst'] for k in bs);worse=sum(ts[k]['cst']<bs[k]['cst'] for k in bs)
  ba={(x['round'],x['qid']):x['canonical_choice'] for x in qa if x['model']==model and x['retrieval_mode']==base}
  ta={(x['round'],x['qid']):x['canonical_choice'] for x in qa if x['model']==model and x['retrieval_mode']==target}
  changed=sum(ta[k]!=v for k,v in ba.items())
  paired.append({'model':model,'base':base,'target':target,'pooled_metric_differences':differences,'cst_territories_improved':improved,'cst_territories_worse':worse,'cst_territories_unchanged':30-improved-worse,'changed_query_answers':changed,'paired_queries':len(ba)})
  fmt=lambda v:'undefined' if v is None else f'{v*100:+.2f} percentage points'
  lines.append(f"- {target} versus {base}: KB {fmt(differences['KB CS'])}; CST all {fmt(differences['Consistency CS all'])}; CST unknown {fmt(differences['Consistency CS unk'])}. CST improves/worsens/is unchanged for {improved}/{worse}/{30-improved-worse} territories. Selected answers change on {changed}/{len(ba)} identical queries.")
  if differences['KB CS'] is not None and differences['Consistency CS all'] is not None and differences['KB CS']*differences['Consistency CS all']<0:
   lines.append('  Controller agreement and cross-language consistency move in opposite directions here; these measure different properties and should not be treated as interchangeable accuracy metrics.')
 for mode in ['no_ir','qlang','rel_langs']:
  ds=[x['Delta CS'] for x in summary if x['round'] in [1,2,3] and x['model']==model and x['mode']==mode]
  text=', '.join('undefined' if x is None else f'{x*100:.2f}%' for x in ds)
  lines.append(f'- {mode}: round-wise normalized Delta CS = {text}. A zero non-control denominator remains undefined; invariance across a small sample is not proof that the questions determine invariance.')
lines+=['','## Interpretation limits','','Retrieval-mode comparisons within this new experiment are paired. Previous pilots changed sampling, top-k and answer-selection implementation relative to this experiment, so comparisons with those pilots are not a controlled estimate of any single factor. No statistical significance or generalization to larger models is established. KB/Control/Non-control measure agreement with the supplied Controller annotation; CST measures equality of selected countries across claimant languages, not correctness.','', 'Each round retains every available archive language for each selected territory; size-2/3/4 and controller strata approximate original composition, while geographic and exact language frequencies remain unmatched. rel_langs permits multilingual candidates but applies no per-language quota in the final global top10.']
atomic(ROOT/'paired_retrieval_effects.json',paired)

(ROOT/'RESULTS.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'answers':len(qa),'official_successes':sum(x['official_status']=='passed' for x in summary),'integrity':'passed'}))

# Export an artifact after all metrics, answers and integrity checks exist.
import zipfile
archive=ROOT.parent/'paper-aligned-pilot-results.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(ROOT.rglob('*')):
  if not f.is_file() or '__pycache__' in f.parts or any(part.startswith('draft_') for part in f.parts):continue
  z.write(f,Path(ROOT.name)/f.relative_to(ROOT))
print('Archive:',archive,archive.stat().st_size,'bytes')
