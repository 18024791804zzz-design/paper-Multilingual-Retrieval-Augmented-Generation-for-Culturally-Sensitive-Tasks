from engine import *
import argparse,traceback
import transformers
p=argparse.ArgumentParser();p.add_argument('--model',required=True);a=p.parse_args()
assert json.loads((ROOT/'preflight.json').read_text())['passed']
assert all(json.loads((ROOT/f'validation_{n}.json').read_text())['passed'] for n in PATHS)
tok,model,load_seconds=load(a.model)
for r in range(1,4):
 for mode in ['no_ir','qlang','rel_langs']:
  B=ROOT/f'round{r}'/mode;out=B/a.model;out.mkdir(exist_ok=True);items=json.loads((B/'inputs.json').read_text());sha=hashlib.sha256((B/'inputs.json').read_bytes()).hexdigest()
  answers=json.loads((out/'answers.json').read_text()) if (out/'answers.json').exists() else []
  assert [x['qid'] for x in answers]==[x['qid'] for x in items[:len(answers)]]
  for item in items[len(answers):]:
   row={k:v for k,v in item.items() if k!='hits'};row.update(model=a.model,retrieval_mode=mode,round=r,document_ids=[h['pid'] for h in item['hits']],document_languages=[h['language'] for h in item['hits']])
   print(json.dumps({'start':item['qid'],'model':a.model,'round':r,'mode':mode},ensure_ascii=False),flush=True)
   try:
    ids,messages,choices=inputs(tok,item,mode);row.update(messages=messages,formatted_prompt=tok.apply_chat_template(messages,tokenize=False,add_generation_prompt=True),input_tokens=ids.shape[1],candidates=choices,candidate_token_lengths=lengths(tok,choices))
    t=time.perf_counter();probs,tokens=cached(ids,model,50);scores=score(probs,choices,tok);del probs
    ordered=sorted(scores,reverse=True);margin=ordered[0]-ordered[1] if len(ordered)>1 else None
    fallback=False
    if margin is not None and margin<=0.002:
     # Borderline cache rankings are checked against the original full-prefix implementation.
     n=max(row['candidate_token_lengths']);ref,_=original.generate_next_tokens(ids,model,num_tokens=n);ref_scores=score(ref,choices,tok);del ref
     row['cached_candidate_scores']=scores;row['reference_candidate_scores']=ref_scores;scores=ref_scores;fallback=True
    elapsed=time.perf_counter()-t;ind=scores.index(max(scores));decoded=tok.decode(tokens,skip_special_tokens=False);raw=decoded.split(tok.eos_token,1)[0] if tok.eos_token else decoded
    row.update(generation_seconds=elapsed,generated_token_ids=tokens,new_tokens=len(tokens),raw_response=raw,candidate_scores=scores,candidate_score_margin=margin,reference_fallback=fallback,claimant_ind=ind,choice=choices[ind],canonical_choice=item['claimants'][ind],success=True,failure_reason=None,peak_rss_gib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2)
   except Exception as exc:
    row.update(success=False,claimant_ind=-1,failure_reason=f'{type(exc).__name__}: {exc}',traceback=traceback.format_exc())
   answers.append(row);atomic(out/'answers.json',answers)
   gen={x['qid']:{'query':x['query'],'choice':x['choice'],'raw_response':x['raw_response'],'claimant_ind':x['claimant_ind'],'doc_ids':x['document_ids']} for x in answers if x['success']};atomic(out/'generation.json',gen)
   report={'round':r,'retrieval_mode':mode,'model':PATHS[a.model],'queries':len(answers),'expected_queries':30,'success_count':sum(x['success'] for x in answers),'failure_count':sum(not x['success'] for x in answers),'inputs_sha256':sha,'load_seconds':load_seconds,'generation_seconds':sum(x.get('generation_seconds',0) for x in answers),'peak_rss_gib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,'device':'cpu','dtype':'float32','threads':4,'seed':4321,'forced_steps':50,'temperature':0,'decoding':'Original free-generated-prefix 50-position candidate scoring; same unmodified candidate-score helper; KV cache, last-position logits only. Original literal <|eot_id|> rule. Small score margins fallback to full-prefix reference. Raw generation is diagnostic; selected candidate is authoritative.','transformers':transformers.__version__,'torch':torch.__version__,'reference_fallback_count':sum(x.get('reference_fallback',False) for x in answers)}
   atomic(out/'run_report.json',report)
   print(json.dumps({'model':a.model,'round':r,'mode':mode,'progress':len(answers),'qid':item['qid'],'choice':row.get('canonical_choice'),'seconds':row.get('generation_seconds'),'success':row['success']},ensure_ascii=False),flush=True)
   if not row['success']:raise RuntimeError(row['failure_reason'])
