from pathlib import Path
import json,shutil
B=Path('/workspace/paper-aligned-pilot')
for r in [2,3]:
 root=B/f'round{r}';assert not list(root.glob('*/*/answers.json'))
 archive=B/'draft_missing_languages';archive.mkdir(exist_ok=True)
 shutil.move(str(root),str(archive/f'round{r}'))
p=B/'prepare.py';s=p.read_text().replace(" if any(c not in codes for c in cs):continue", " if any(c not in codes for c in cs):continue\n # Round1 was already frozen and independently passed this coverage check.\n if round_no>1 and set(codes[c] for c in cs)-av:continue")
s=s.replace('Protocol v2:', 'Protocol v3:').replace('Complete available MRS,', 'Complete MRS: every claimant language plus English must be present in selected queries (round1 frozen cohort independently verified; rounds2/3 enforce eligibility before shuffle),')
p.write_text(s)
