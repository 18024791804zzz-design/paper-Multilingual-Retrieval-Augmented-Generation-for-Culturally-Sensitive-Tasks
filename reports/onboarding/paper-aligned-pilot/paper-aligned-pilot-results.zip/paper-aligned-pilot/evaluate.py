"""Invoke unchanged repository CSV adapter and upstream official CS scorer."""
import os
os.environ.setdefault('HF_HOME','/workspace/.cache/huggingface')
os.environ['HF_HUB_OFFLINE']='1';os.environ['HF_DATASETS_OFFLINE']='1';os.environ['PYTHONDONTWRITEBYTECODE']='1'
import argparse
import csv
import ast
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys

p=argparse.ArgumentParser();p.add_argument('--round',type=int,required=True);p.add_argument('--mode',choices=['qlang','rel_langs','no_ir'],required=True);args=p.parse_args()
B=Path('/workspace/paper-aligned-pilot')/f'round{args.round}'/args.mode
REPO=Path('/workspace/paper-Multilingual-Retrieval-Augmented-Generation-for-Culturally-Sensitive-Tasks')
official=Path('/workspace/.onboarding/bordirlines/vendor/BorderLines/calculate_CS.py')
inputs=json.loads((B/'inputs.json').read_text())
sha=hashlib.sha256((B/'inputs.json').read_bytes()).hexdigest()
models={}
all_answers=[]
for name in ['llama','qwen']:
    folder=B/name
    report=json.loads((folder/'run_report.json').read_text())
    assert report['inputs_sha256']==sha
    answers=json.loads((folder/'answers.json').read_text())
    assert [r['qid'] for r in answers]==[r['qid'] for r in inputs]
    all_answers.extend(answers)
    if report['failure_count']:
        # The original CSV adapter silently maps unparseable answers to index 0.
        # Do not allow that fallback to masquerade as valid model predictions.
        models[name]={'status':'blocked_invalid_answers','run_report':report,'reason':'Official evaluation not run because its CSV adapter substitutes the first claimant for invalid answers.'}
        continue
    csv_path=folder/'response_table.csv'
    commands=[('csv_adapter',[sys.executable,str(REPO/'generation/gen_response_table.py'),'-i',str(folder/'generation.json'),'-o',str(csv_path),'-dd',str(B/'evaluation_metadata'),'-q']),('official_cs',[sys.executable,str(official),str(csv_path),'-o',str(folder/'cs_metrics.json'),'-q'])]
    outcomes=[]
    for label,command in commands:
        result=subprocess.run(command,cwd=REPO/'generation',capture_output=True,text=True,timeout=120)
        (folder/f'{label}.log').write_text(result.stdout+result.stderr)
        outcomes.append({'step':label,'exit_code':result.returncode})
        if result.returncode:break
        if label=='csv_adapter':
            # Verify the unchanged adapter preserved canonical answer indices.
            table=list(csv.DictReader(csv_path.open()))
            selected=json.loads((B/'selection.json').read_text())
            assert len(table)==len(selected)==10
            by_qid={r['qid']:r for r in answers}
            for csv_row,territory in zip(table,selected):
                name_prefix=territory['territory'].replace(' ','_')
                expected={lang:by_qid[f'{name_prefix}_{lang}']['canonical_choice'] for lang in territory['languages']}
                assert ast.literal_eval(csv_row['Responses_d'])==expected,territory['territory']
                assert csv_row['Response_en']==expected['en']
                assert csv_row['Controller']==territory['controller']
    entry={'run_report':report,'commands':outcomes,'status':'passed' if len(outcomes)==2 and outcomes[-1]['exit_code']==0 else 'failed'}
    if entry['status']=='passed':
        metrics=json.loads((folder/'cs_metrics.json').read_text())
        assert metrics['num_queries']==30 and metrics['num_territories']==10
        assert metrics['Consistency CS unk rows']==sum(s['controller']=='Unknown' for s in selected) and metrics['Consistency CS all rows']==10
        for key in ['KB CS','Control CS','Non-control CS','Delta CS','Consistency CS all','Consistency CS unk']:
            assert math.isfinite(metrics[key]),(name,key)
        entry['metrics']=metrics
    models[name]=entry
    print(name,json.dumps(entry,ensure_ascii=False,indent=2))

by_model={name:{r['qid']:r for r in json.loads((B/name/'answers.json').read_text())} for name in ['llama','qwen']}
columns=['qid','raw_query_id','territory','query_lang','query','controller','controller_code','claimants','claimants_native','document_ids','llama_raw_response','llama_canonical_choice','llama_success','llama_seconds','qwen_raw_response','qwen_canonical_choice','qwen_success','qwen_seconds']
with (B/'questions_and_answers.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader()
    for item in inputs:
        row={k:item[k] for k in ['qid','raw_query_id','territory','query_lang','query','controller','controller_code']}
        for key in ['claimants','claimants_native']:row[key]=json.dumps(item[key],ensure_ascii=False)
        row['document_ids']=json.dumps([h['pid'] for h in item['hits']])
        for name in ['llama','qwen']:
            answer=by_model[name][item['qid']]
            row[f'{name}_raw_response']=answer.get('raw_response','')
            row[f'{name}_canonical_choice']=answer.get('canonical_choice','')
            row[f'{name}_success']=answer['success']
            row[f'{name}_seconds']=answer.get('generation_seconds','')
        writer.writerow(row)
comparison={'scope':'A metadata-stratified ten-territory pilot with 30 identical query/passage inputs per model; original-code candidate scoring with validated KV-cache optimization; complete available MRS, top10; not full-paper reproduction. No representativeness or statistical significance claim.','inputs_sha256':sha,'models':models}
for item in inputs:
    l=by_model['llama'][item['qid']];q=by_model['qwen'][item['qid']]
    assert l['messages']==q['messages'] and l['document_ids']==q['document_ids'],item['qid']
comparison['paired_input_messages_and_document_orders_verified']=True
(B/'comparison.json').write_text(json.dumps(comparison,ensure_ascii=False,indent=2,allow_nan=False))
raise SystemExit(0 if all(e['status']=='passed' for e in models.values()) else 1)
