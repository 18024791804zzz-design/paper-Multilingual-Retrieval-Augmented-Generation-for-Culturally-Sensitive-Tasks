#!/usr/bin/env bash
set -euo pipefail

export EXP_ROOT=/root/autodl-tmp/fixed-language-rag
export KIT="$EXP_ROOT/fixed-content-ready-v1"

export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export PYTHONUNBUFFERED=1
export HF_HUB_OFFLINE=1
export HF_DATASETS_OFFLINE=1

source "$KIT/env.sh"

RESULT_ROOT="$EXP_ROOT/results/fixed-language-v1-reference"

for EXP_MODEL in llama qwen; do
  "$EXP_ROOT/venv/bin/python" "$KIT/run.py" \
    --model "$EXP_MODEL" \
    --out "$RESULT_ROOT/$EXP_MODEL" \
    --reference-no-cache
done

"$EXP_ROOT/venv/bin/python" "$KIT/score.py" \
  --results "$RESULT_ROOT"
